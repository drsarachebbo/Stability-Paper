# Core Python code for the manuscript revision

This directory contains the latest Python scripts available for the analyses
added or substantially revised during peer review. The scripts are archived
under their original filenames so that they can be matched unambiguously to
the manuscript outputs.

## Python environment

Use Python 3.10 or newer. Install the packages listed in `requirements.txt`.
The NetCDF input files are not included in this archive.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
```

## Included scripts

| Script | Manuscript output or analysis |
|---|---|
| `scripts/make_supplementary_maps_s1_s2_v10_corsica.py` | Main Figure 1 (permanent-grassland fraction and Variable minus Fixed spatial differences) and Supplementary Figure S1 (absolute Variable-trait maps). It also writes the aggregated permanent-grassland fractions on the ORCHIDEE grid. The output filename still calls the four-panel map “Figure S2” because the map was promoted to the main manuscript after the script was written. |
| `scripts/paired_fixed_variable_spatial_analysis.py` | Paired within-cell Variable minus Fixed analysis, spatial-block bootstrap confidence intervals, block-size sensitivity, cell-level results, and Supplementary Figure S2 violin plots. |
| `scripts/independent_period_npp_stability_autoselected_final.py` | Concurrent and independent-period NPP–stability analyses; AICc plus fivefold spatially blocked cross-validation; spatial-block confidence intervals; NPP-quartile sensitivity; residual Moran’s I and distance correlograms; Supplementary Figures S11–S14; and the numerical results used in Supplementary Tables S2 (NPP–stability part) and S3. |
| `scripts/make_figure2_autoselected_final.py` | Final main Figure 2, using the response forms selected by the preceding analysis. |
| `scripts/reviewer_climate_spread.py` | Supplementary Figure S10, climate-chain summaries, and the revised main Figure 4 with ensemble median and minimum–maximum spread, provided that the original Figure 4 values CSV is supplied. |

## Typical commands

The first two scripts accept data and output paths on the command line:

```bash
python3 scripts/paired_fixed_variable_spatial_analysis.py \
  --data-dir /path/to/netcdf_inputs \
  --output-dir /path/to/paired_outputs \
  --confirm-resistance-period

python3 scripts/make_supplementary_maps_s1_s2_v10_corsica.py \
  --data-dir /path/to/netcdf_inputs \
  --output-dir /path/to/map_outputs \
  --grassland-mask /path/to/PP10m.nc \
  --confirm-resistance-period

python3 scripts/reviewer_climate_spread.py \
  --data-dir /path/to/climate_inputs \
  --output-dir /path/to/climate_outputs \
  --annual-2010-2099 \
  --figure4-values /path/to/Figure_temporal_evolution_independent_windows_values.csv
```

The independent-period and Figure 2 scripts currently preserve the exact TGCC
paths used in the final analysis. Before running them elsewhere, edit `DATA_DIR`
and `OUTPUT_DIR` in their user-settings sections. Run them in this order:

```bash
python3 scripts/independent_period_npp_stability_autoselected_final.py
python3 scripts/make_figure2_autoselected_final.py
```

Both spatial-map scripts provide an in-memory self-test:

```bash
python3 scripts/paired_fixed_variable_spatial_analysis.py --self-test
python3 scripts/make_supplementary_maps_s1_s2_v10_corsica.py --self-test
```

## Input-data notes

The scripts expect the original ORCHIDEE/SAFRAN NetCDF grids and use explicit
variable names. In particular, `logresistance_all.nc` must represent 1960–2019,
and `PP10m.nc` must retain its Lambert-93 coordinate metadata. Do not commit
large or restricted NetCDF files to GitHub; instead document their provenance,
access conditions, checksums, and the exact filenames expected by the scripts.

## Code still required for a complete paper repository

The following source scripts were not present in the final shared workspace and
therefore are not included here:

- the Figure 3 / Supplementary Figure S7 environmental and trait relationship
  analysis;
- the original Figure 4 time-series calculation that creates
  `Figure_temporal_evolution_independent_windows_values.csv`;
- the transient-versus-constant CO2 calculations for Supplementary Figures
  S3–S5;
- the M5/M10/M20 resistance-sensitivity calculations for Supplementary Figures
  S8–S9;
- a distinct all-candidate model-comparison figure for Supplementary Figure S6,
  if that figure is retained as a separate item.

The image-assembly utilities and editorial Word-processing scripts are not
scientific analysis code and are intentionally excluded.

