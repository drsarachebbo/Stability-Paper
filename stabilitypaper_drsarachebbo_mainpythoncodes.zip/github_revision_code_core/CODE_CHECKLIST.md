# Before making the repository public

- Add the missing analysis scripts listed in `README.md` if the repository is
  described as reproducing the entire paper rather than only the revision.
- Replace or parameterize the two remaining hard-coded TGCC path blocks.
- Add an input-data table with source, filename, variable names, units, period,
  access conditions, and SHA-256 checksum.
- Record the final Python/package versions used on TGCC.
- Add a license and citation information after the authors agree on them.
- Check Supplementary Figure S6: in the supplied final Word document its
  caption repeats the paired-difference caption from Figure S2, while the main
  text and Table S2 describe S6 as a response-form/model-comparison figure.
