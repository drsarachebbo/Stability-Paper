#!/usr/bin/env python3
"""Create the final, automatically selected manuscript Figure 2.

One parsimonious response shape is plotted in each panel. Model choices were
read directly from the completed independent-period analysis output. This
prevents the displayed response forms from drifting away from the AICc plus
fivefold spatially blocked cross-validation results.

Outputs are written at 600 dpi (PNG) and as a vector PDF in
``figure2_autoselected_final``. The NetCDF inputs and analysis CSV are read
only, and the previous Figure 2 is not overwritten.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import netCDF4 as nc
import numpy as np
from matplotlib.lines import Line2D


# -----------------------------------------------------------------------------
# Paths and output settings
# -----------------------------------------------------------------------------

DATA_DIR = Path("/ccc/work/cont003/gen6328/chebbosa")
OUTPUT_DIR = DATA_DIR / "figure2_autoselected_final"
MODEL_SELECTION_CSV = (
    DATA_DIR
    / "independent_period_analysis_autoselected_final"
    / "concurrent_Figure2_relationship_statistics_spatial.csv"
)

ALL_NPP_FILE = DATA_DIR / "npp_simnol_all.nc"
ALL_CONSTANCY_FILE = DATA_DIR / "stab_simnol_all.nc"
TYPE_NPP_CONSTANCY_FILE = DATA_DIR / "stab_simnol_types.nc"
RESISTANCE_FILE = DATA_DIR / "logresistance_all.nc"

OUTPUT_PNG = OUTPUT_DIR / "Figure2_NPP_stability_by_habitat_autoselected_final.png"
OUTPUT_PDF = OUTPUT_DIR / "Figure2_NPP_stability_by_habitat_autoselected_final.pdf"
OUTPUT_CSV = OUTPUT_DIR / "Figure2_NPP_stability_by_habitat_autoselected_models.csv"

# High-resolution publication output. 60 dpi would be low resolution.
PNG_DPI = 600
ZERO_IS_MISSING = True

# Segmented breakpoints are searched only between the 10th and 90th
# percentiles, avoiding unstable breakpoints defined by a few extreme pixels.
BREAKPOINT_MIN_QUANTILE = 0.10
BREAKPOINT_MAX_QUANTILE = 0.90
N_BREAKPOINT_CANDIDATES = 181


@dataclass(frozen=True)
class Habitat:
    key: str
    title: str
    color: str
    npp_variable: str
    constancy_variable: str
    resistance_variable: str
    npp_file: Path
    constancy_file: Path


HABITATS = (
    Habitat(
        key="All",
        title="All grasslands",
        color="#6B6B6B",
        npp_variable="NPP_VARLLVARNOL",
        constancy_variable="CONSTANCY_VARLLVARNOL",
        resistance_variable="RESISTANCE_VARLLVAR",
        npp_file=ALL_NPP_FILE,
        constancy_file=ALL_CONSTANCY_FILE,
    ),
    Habitat(
        key="Calcareous",
        title="Calcareous",
        color="#8E44AD",
        npp_variable="NPP_CALC_VARLLVAR",
        constancy_variable="CONS_CALC_VARLLVAR",
        resistance_variable="RESISTANCE_CALC_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Mesic",
        title="Mesic",
        color="#1F3A93",
        npp_variable="NPP_MESO_VARLLVAR",
        constancy_variable="CONS_MESO_VARLLVAR",
        resistance_variable="RESISTANCE_MESO_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Mountain",
        title="Mountain",
        color="#196F3D",
        npp_variable="NPP_MOUN_VARLLVAR",
        constancy_variable="CONS_MOUN_VARLLVAR",
        resistance_variable="RESISTANCE_MOUN_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Ruderal",
        title="Ruderal",
        color="#F39C12",
        npp_variable="NPP_RUD_VARLLVAR",
        constancy_variable="CONS_RUD_VARLLVAR",
        resistance_variable="RESISTANCE_RUD_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
)


@dataclass(frozen=True)
class Relationship:
    key: str
    predictor: str
    response: str
    xlabel: str
    ylabel: str


RELATIONSHIPS = (
    Relationship(
        key="NPP_vs_Constancy",
        predictor="NPP",
        response="Constancy",
        xlabel=r"NPP (g C m$^{-2}$ yr$^{-1}$)",
        ylabel="Constancy",
    ),
    Relationship(
        key="NPP_vs_Resistance",
        predictor="NPP",
        response="Resistance",
        xlabel=r"NPP (g C m$^{-2}$ yr$^{-1}$)",
        ylabel=r"Resistance ($\log_{10}$)",
    ),
    Relationship(
        key="Constancy_vs_Resistance",
        predictor="Constancy",
        response="Resistance",
        xlabel="Constancy",
        ylabel=r"Resistance ($\log_{10}$)",
    ),
)


LINESTYLES = {
    "Linear": "-",
    "Quadratic": "--",
    # A dotted line remains clearly distinguishable from the solid linear
    # fit after the full figure is reduced to journal page width.
    "Segmented": ":",
}


def load_final_model_selection() -> dict[tuple[str, str], dict[str, str]]:
    """Read and validate the 15 final concurrent relationship results."""
    if not MODEL_SELECTION_CSV.is_file():
        raise FileNotFoundError(
            "Final model-selection CSV not found:\n"
            f"  {MODEL_SELECTION_CSV}\n"
            "Run independent_period_npp_stability_autoselected_final.py first."
        )

    with MODEL_SELECTION_CSV.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))

    expected = {
        (relationship.key, habitat.key)
        for relationship in RELATIONSHIPS
        for habitat in HABITATS
    }
    by_key: dict[tuple[str, str], dict[str, str]] = {}
    for row in rows:
        key = (row.get("relationship", ""), row.get("habitat", ""))
        if key not in expected:
            continue
        if key in by_key:
            raise ValueError(f"Duplicate model-selection row: {key}")
        if row.get("model_selection_mode") != "AICc_plus_blocked_CV":
            raise ValueError(
                f"{key}: expected AICc_plus_blocked_CV, found "
                f"{row.get('model_selection_mode')!r}"
            )
        model = row.get("selected_model")
        if model not in LINESTYLES:
            raise ValueError(f"{key}: unsupported selected model {model!r}")
        by_key[key] = row

    missing = sorted(expected - set(by_key))
    if missing:
        raise ValueError(f"Missing final model-selection rows: {missing}")
    if len(by_key) != 15:
        raise ValueError(f"Expected 15 final panel selections, found {len(by_key)}")
    return by_key


# -----------------------------------------------------------------------------
# Data loading and pairing
# -----------------------------------------------------------------------------

def load_map(path: Path, variable_name: str) -> np.ndarray:
    if not path.is_file():
        raise FileNotFoundError(f"Input file not found: {path}")
    with nc.Dataset(path, mode="r") as dataset:
        if variable_name not in dataset.variables:
            available = ", ".join(dataset.variables.keys())
            raise KeyError(
                f"{path.name}: variable '{variable_name}' not found. "
                f"Available variables: {available}"
            )
        values = dataset.variables[variable_name][:]
    array = np.asarray(np.ma.filled(values, np.nan), dtype=np.float64).squeeze()
    if array.ndim != 2:
        raise ValueError(
            f"{path.name}/{variable_name}: expected a 2-D map, found {array.shape}"
        )
    return array


def load_all_maps() -> dict[str, dict[str, np.ndarray]]:
    maps: dict[str, dict[str, np.ndarray]] = {}
    reference_shape = None
    for habitat in HABITATS:
        current = {
            "NPP": load_map(habitat.npp_file, habitat.npp_variable),
            "Constancy": load_map(
                habitat.constancy_file,
                habitat.constancy_variable,
            ),
            "Resistance": load_map(
                RESISTANCE_FILE,
                habitat.resistance_variable,
            ),
        }
        shapes = {name: values.shape for name, values in current.items()}
        if len(set(shapes.values())) != 1:
            raise ValueError(f"{habitat.key}: incompatible shapes: {shapes}")
        current_shape = next(iter(shapes.values()))
        if reference_shape is None:
            reference_shape = current_shape
        elif current_shape != reference_shape:
            raise ValueError(
                f"{habitat.key}: grid {current_shape} differs from {reference_shape}"
            )
        maps[habitat.key] = current
    return maps


def paired_values(
    predictor: np.ndarray,
    response: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    # A single mask preserves the pixel-by-pixel correspondence between x/y.
    valid = np.isfinite(predictor) & np.isfinite(response)
    if ZERO_IS_MISSING:
        valid &= (predictor != 0) & (response != 0)
    x = predictor[valid].astype(np.float64)
    y = response[valid].astype(np.float64)
    if x.size < 20:
        raise ValueError(f"Only {x.size} paired pixels were found")
    return x, y


# -----------------------------------------------------------------------------
# Selected models
# -----------------------------------------------------------------------------

def segmented_design(x: np.ndarray, breakpoint: float) -> np.ndarray:
    return np.column_stack(
        [np.ones_like(x), x, np.maximum(0.0, x - breakpoint)]
    )


def fit_model(model_name: str, x: np.ndarray, y: np.ndarray) -> dict:
    if model_name == "Linear":
        return {
            "model": model_name,
            "coefficients": np.polyfit(x, y, deg=1),
        }
    if model_name == "Quadratic":
        return {
            "model": model_name,
            "coefficients": np.polyfit(x, y, deg=2),
        }
    if model_name != "Segmented":
        raise ValueError(f"Unknown model: {model_name}")

    quantiles = np.linspace(
        BREAKPOINT_MIN_QUANTILE,
        BREAKPOINT_MAX_QUANTILE,
        N_BREAKPOINT_CANDIDATES,
    )
    candidates = np.unique(np.quantile(x, quantiles))
    best_sse = np.inf
    best_breakpoint = None
    best_coefficients = None

    for breakpoint in candidates:
        design = segmented_design(x, float(breakpoint))
        coefficients, _, _, _ = np.linalg.lstsq(design, y, rcond=None)
        residuals = y - design @ coefficients
        sse = float(np.sum(residuals**2))
        if sse < best_sse:
            best_sse = sse
            best_breakpoint = float(breakpoint)
            best_coefficients = coefficients

    if best_breakpoint is None or best_coefficients is None:
        raise RuntimeError("No segmented breakpoint could be estimated")
    return {
        "model": model_name,
        "coefficients": best_coefficients,
        "breakpoint": best_breakpoint,
    }


def predict(fit: dict, x: np.ndarray) -> np.ndarray:
    if fit["model"] in ("Linear", "Quadratic"):
        return np.polyval(fit["coefficients"], x)
    return segmented_design(x, fit["breakpoint"]) @ fit["coefficients"]


def fit_statistics(fit: dict, x: np.ndarray, y: np.ndarray) -> dict:
    fitted = predict(fit, x)
    residuals = y - fitted
    sse = float(np.sum(residuals**2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    result = {
        "Pearson_R": float(np.corrcoef(x, y)[0, 1]),
        "RMSE": float(np.sqrt(np.mean(residuals**2))),
        "R_squared": float(1 - sse / sst) if sst > 0 else np.nan,
        "breakpoint": np.nan,
        "slope_before": np.nan,
        "slope_after": np.nan,
        "quadratic_turning_point": np.nan,
    }

    coefficients = fit["coefficients"]
    if fit["model"] == "Linear":
        result["slope_before"] = float(coefficients[0])
    elif fit["model"] == "Quadratic":
        quadratic, linear, _ = coefficients
        if quadratic != 0:
            result["quadratic_turning_point"] = float(
                -linear / (2 * quadratic)
            )
    else:
        _, first_slope, slope_change = coefficients
        result["breakpoint"] = float(fit["breakpoint"])
        result["slope_before"] = float(first_slope)
        result["slope_after"] = float(first_slope + slope_change)
    return result


# -----------------------------------------------------------------------------
# Figure and reproducibility table
# -----------------------------------------------------------------------------

def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    final_selection = load_final_model_selection()
    maps = load_all_maps()

    plot_data: dict[tuple[str, str], tuple[np.ndarray, np.ndarray]] = {}
    fits: dict[tuple[str, str], dict] = {}
    statistics: dict[tuple[str, str], dict] = {}
    rows: list[dict] = []

    for relationship in RELATIONSHIPS:
        for habitat in HABITATS:
            x, y = paired_values(
                maps[habitat.key][relationship.predictor],
                maps[habitat.key][relationship.response],
            )
            source_row = final_selection[(relationship.key, habitat.key)]
            model_name = source_row["selected_model"]

            # Refuse to draw a figure if the paired points no longer match the
            # validated final analysis. This catches a changed mask, variable,
            # file or spatial orientation before publication.
            expected_n = int(source_row["n"])
            expected_r = float(source_row["Pearson_r"])
            observed_r = float(np.corrcoef(x, y)[0, 1])
            if x.size != expected_n:
                raise RuntimeError(
                    f"{relationship.key}/{habitat.key}: expected {expected_n} "
                    f"paired cells from the final analysis, found {x.size}"
                )
            if not np.isclose(observed_r, expected_r, rtol=0.0, atol=1e-10):
                raise RuntimeError(
                    f"{relationship.key}/{habitat.key}: Pearson r does not "
                    f"match the final analysis ({observed_r} versus {expected_r})"
                )

            fit = fit_model(model_name, x, y)
            stats = fit_statistics(fit, x, y)

            if model_name == "Segmented":
                expected_breakpoint = float(source_row["selected_breakpoint"])
                if not np.isclose(
                    fit["breakpoint"],
                    expected_breakpoint,
                    rtol=0.0,
                    atol=1e-8,
                ):
                    raise RuntimeError(
                        f"{relationship.key}/{habitat.key}: fitted breakpoint "
                        "does not match the final analysis"
                    )
            elif model_name == "Quadratic":
                quadratic, linear, _ = fit["coefficients"]
                turning_point = float(-linear / (2.0 * quadratic))
                expected_turning_point = float(source_row["selected_turning_point"])
                if not np.isclose(
                    turning_point,
                    expected_turning_point,
                    rtol=0.0,
                    atol=1e-8,
                ):
                    raise RuntimeError(
                        f"{relationship.key}/{habitat.key}: fitted turning point "
                        "does not match the final analysis"
                    )
            plot_data[(relationship.key, habitat.key)] = (x, y)
            fits[(relationship.key, habitat.key)] = fit
            statistics[(relationship.key, habitat.key)] = stats
            rows.append(
                {
                    "relationship": relationship.key,
                    "habitat": habitat.key,
                    "selected_model": model_name,
                    "n": int(x.size),
                    **stats,
                }
            )

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 14,
            "axes.labelsize": 18,
            "axes.titlesize": 20,
            "xtick.labelsize": 14,
            "ytick.labelsize": 14,
            "axes.linewidth": 1.0,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )

    figure, axes = plt.subplots(
        3,
        5,
        figsize=(16.0, 10.2),
        sharex="row",
        sharey="row",
        constrained_layout=False,
    )
    figure.subplots_adjust(
        left=0.065,
        right=0.995,
        top=0.925,
        bottom=0.175,
        wspace=0.13,
        hspace=0.42,
    )

    # Add headroom above each row. The compact correlation annotation is
    # placed in this empty area and therefore does not hide observations.
    row_y_limits: dict[str, tuple[float, float]] = {}
    for relationship in RELATIONSHIPS:
        all_y = np.concatenate(
            [
                plot_data[(relationship.key, habitat.key)][1]
                for habitat in HABITATS
            ]
        )
        y_min = float(np.min(all_y))
        y_max = float(np.max(all_y))
        y_span = y_max - y_min
        if y_span <= 0:
            raise ValueError(f"{relationship.key}: response has no variation")
        row_y_limits[relationship.key] = (
            y_min - 0.03 * y_span,
            y_max + 0.14 * y_span,
        )

    panel_index = 0

    for row_index, relationship in enumerate(RELATIONSHIPS):
        for column_index, habitat in enumerate(HABITATS):
            axis = axes[row_index, column_index]
            key = (relationship.key, habitat.key)
            x, y = plot_data[key]
            fit = fits[key]
            stats = statistics[key]
            model_name = fit["model"]

            # Use one identical marker size in every column. The complete
            # grassland sample contains many more pixels, so transparency is
            # increased there to avoid hiding its internal point density.
            point_alpha = 0.30 if habitat.key == "All" else 0.64
            axis.scatter(
                x,
                y,
                s=8,
                alpha=point_alpha,
                color=habitat.color,
                edgecolors="none",
                rasterized=True,
            )

            x_grid = np.linspace(float(np.min(x)), float(np.max(x)), 500)
            axis.plot(
                x_grid,
                predict(fit, x_grid),
                color="#303030",
                linestyle=LINESTYLES[model_name],
                linewidth=2.2,
                zorder=5,
            )

            # Keep only Pearson's r in the main figure. RMSE and n remain in
            # the accompanying reproducibility CSV.
            axis.text(
                0.04,
                0.96,
                rf"$r$ = {stats['Pearson_R']:.2f}",
                transform=axis.transAxes,
                ha="left",
                va="top",
                fontsize=14,
                bbox={
                    "facecolor": "white",
                    "alpha": 0.85,
                    "edgecolor": "none",
                    "pad": 1.0,
                },
                zorder=10,
            )

            panel_letter = chr(ord("a") + panel_index)
            axis.text(
                -0.04,
                1.02,
                panel_letter,
                transform=axis.transAxes,
                ha="left",
                va="bottom",
                fontsize=17,
                fontweight="bold",
            )
            panel_index += 1

            if row_index == 0:
                axis.set_title(
                    habitat.title,
                    color=habitat.color,
                    fontweight="bold",
                    fontsize=17,
                    pad=8,
                )
            if column_index == 0:
                axis.set_ylabel(relationship.ylabel)
            if column_index == 2:
                axis.set_xlabel(relationship.xlabel, labelpad=2)
            axis.set_ylim(*row_y_limits[relationship.key])
            axis.grid(False)

    legend_handles = [
        Line2D(
            [0],
            [0],
            color="#303030",
            linestyle=LINESTYLES[model_name],
            linewidth=2.5,
            label=model_name,
        )
        for model_name in ("Linear", "Quadratic", "Segmented")
    ]
    figure.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.018),
        ncol=3,
        frameon=False,
        fontsize=14,
        handlelength=4.0,
        handletextpad=0.8,
        columnspacing=1.8,
    )

    figure.savefig(
        OUTPUT_PDF,
        bbox_inches="tight",
        facecolor="white",
    )
    figure.savefig(
        OUTPUT_PNG,
        dpi=PNG_DPI,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    fieldnames = [
        "relationship",
        "habitat",
        "selected_model",
        "n",
        "Pearson_R",
        "RMSE",
        "R_squared",
        "breakpoint",
        "slope_before",
        "slope_after",
        "quadratic_turning_point",
    ]
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("\nFinal automatically selected Figure 2 created successfully")
    print("=" * 72)
    for row in rows:
        extra = ""
        if row["selected_model"] == "Segmented":
            extra = f"; breakpoint={row['breakpoint']:.4f}"
        elif row["selected_model"] == "Quadratic":
            extra = f"; turning point={row['quadratic_turning_point']:.4f}"
        print(
            f"{row['relationship']:<28} {row['habitat']:<12} "
            f"{row['selected_model']:<10} R={row['Pearson_R']:.3f} "
            f"RMSE={row['RMSE']:.5f}{extra}"
        )

    print("\nSaved outputs:")
    print(f"  {OUTPUT_PNG}")
    print(f"  {OUTPUT_PDF}")
    print(f"  {OUTPUT_CSV}")
    print("\nInput NetCDF files were not modified.")


if __name__ == "__main__":
    main()
