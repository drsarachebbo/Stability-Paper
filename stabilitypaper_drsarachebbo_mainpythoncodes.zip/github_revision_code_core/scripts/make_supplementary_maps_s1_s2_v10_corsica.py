#!/usr/bin/env python3
"""Reproduce Supplementary Figures S1 and S2 from the validated NetCDF files.

Figure S1 contains the 1960-2019 Variable-trait (VARLLVAR) spatial maps of
mean NPP, constancy, and log10 resistance. Figure S2 contains permanent-
grassland fraction followed by the paired within-cell differences Variable
minus Fixed for the same three quantities. The figures are cartographically
masked with a fine-resolution permanent-grassland layer derived from the
French RPG polygons.

The calculation follows the validated workflow used for the paired analysis:

* raw annual NPP is read from the 60-record files and multiplied by 365 once;
* residual standard deviations are read from the residual files with ddof=0;
* constancy is annual mean NPP divided by residual SD;
* resistance is read directly from logresistance_all.nc (no second log);
* the common Ferret-style gateway is recalculated Fixed constancy > 0;
* the confirmed latitude flip is applied to the legacy resistance maps.
* PP10m.nc/Band1 is converted to presence/absence (strictly positive values);
* grassland fraction is aggregated first to a 1-km display grid and then to
  the ORCHIDEE grid without filtering any analytical cell;
* RPG pixels over Corsica retain their true map coordinates but are associated
  with the Corsica component stored nine longitude columns farther east in the
  packed ORCHIDEE array;
* the 1-km layer is used only as a cartographic display mask. All simulated
  quantities and all analyses remain on the original ORCHIDEE grid.

Inputs are opened read-only. Existing outputs are protected unless
``--overwrite`` is supplied.

Typical Irene command
---------------------
python3 make_supplementary_maps_s1_s2_v10_corsica.py \
  --confirm-resistance-period \
  --grassland-mask /ccc/work/cont003/gen6328/chebbosa/PP10m.nc

The default output directory is
/ccc/work/cont003/gen6328/chebbosa/supplementary_maps_python_grassland_mask_v10_corsica
"""

from __future__ import annotations

import argparse
import csv
import math
import tempfile
import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import FuncFormatter
import numpy as np


SCRIPT_VERSION = "2026-10-01-supplementary-maps-v10-corsica-final"

DEFAULT_DATA_DIR = Path("/ccc/work/cont003/gen6328/chebbosa")
DEFAULT_OUTPUT_SUBDIR = "supplementary_maps_python_grassland_mask_v10_corsica"

NPP_FILES = {
    "Fixed": "fixrecalcllvarnol_2D.nc",
    "Variable": "varllvarnol_2D.nc",
}
RESIDUAL_FILES = {
    "Fixed": "residuals_fixrecalcllvarnol60.nc",
    "Variable": "residuals_varllvarnol60.nc",
}
RESISTANCE_FILE = "logresistance_all.nc"
DEFAULT_GRASSLAND_MASK_FILE = "PP10m.nc"
RESISTANCE_VARIABLES = {
    "Fixed": "RESISTANCE_FIXRECALCLLVAR",
    "Variable": "RESISTANCE_VARLLVAR",
}

NPP_VARIABLE = "NPP"
RESIDUAL_VARIABLE = "residuals"
TIME_DIMENSION = "time_counter"
LATITUDE_DIMENSION = "latitude"
LONGITUDE_DIMENSION = "longitude"

FULL_PERIOD = slice(0, 60)  # ordered annual records 1960 through 2019
NPP_ANNUAL_FACTOR = 365.0
RESIDUAL_STD_DDOF = 0
MISSING_ABS_THRESHOLD = 1.0e30
EXPECTED_GRID_SHAPE = (134, 143)
EXPECTED_GATEWAY_CELLS = 4624
PNG_DPI = 600
OCEAN_COLOR = "#C9DDEB"
LAND_COLOR = "#D9D9D9"
GRASSLAND_VARIABLE = "Band1"
GRASSLAND_X_DIMENSION = "x"
GRASSLAND_Y_DIMENSION = "y"
GRASSLAND_DISPLAY_RESOLUTION_M = 1000.0
GRASSLAND_SOURCE_ROWS_PER_BLOCK = 500
LAMBERT93_TO_LONLAT_PIPELINE = (
    "+proj=pipeline "
    "+step +inv +proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=49 +lat_2=44 "
    "+x_0=700000 +y_0=6600000 +ellps=GRS80 "
    "+step +proj=unitconvert +xy_in=rad +xy_out=deg"
)

# The raw-versus-legacy diagnostic established this orientation correction.
CONFIRMED_LEGACY_LATITUDE_FLIP = True

# The simulation files use a packed rectangular array: the Corsica component
# is stored nine longitude columns east of its geographic position.  The RPG
# raster itself is georeferenced correctly.  Only the RPG-to-ORCHIDEE lookup
# index is shifted; the 1-km longitude/latitude used to draw the island stays
# at its true geographic position.
CORSICA_TRUE_MIN_LONGITUDE = 8.3
CORSICA_TRUE_MAX_LONGITUDE = 9.8
CORSICA_TRUE_MIN_LATITUDE = 41.2
CORSICA_TRUE_MAX_LATITUDE = 43.2
CORSICA_PACKED_SHIFT_CELLS = 9

MAP_EXTENT = (-5.5, 10.0, 41.0, 51.5)
LONGITUDE_TICKS = (-4.0, 0.0, 4.0, 8.0)
LATITUDE_TICKS = (42.0, 44.0, 46.0, 48.0, 50.0)

# Fixed limits make repeated runs directly comparable. Values outside these
# display ranges are retained and shown with extended colorbar triangles.
ABSOLUTE_SPECS = {
    "GrasslandFraction": {
        "title": "Permanent-grassland fraction",
        "colorbar": "% of ORCHIDEE grid cell",
        "levels": np.linspace(0.0, 100.0, 21),
        "cmap": "YlGn",
        "extend": "neither",
    },
    "NPP": {
        "title": "Mean net primary productivity",
        "colorbar": r"g C m$^{-2}$ yr$^{-1}$",
        "levels": np.linspace(280.0, 1080.0, 21),
    },
    "Constancy": {
        "title": "Constancy",
        "colorbar": "dimensionless",
        "levels": np.linspace(6.0, 33.0, 28),
    },
    "Resistance": {
        "title": r"Resistance ($\log_{10}$)",
        "colorbar": r"$\log_{10}$ units",
        "levels": np.linspace(-0.80, -0.30, 26),
    },
}

DIFFERENCE_SPECS = {
    "NPP": {
        "title": r"$\Delta$ net primary productivity",
        "colorbar": r"Variable $-$ Fixed (g C m$^{-2}$ yr$^{-1}$)",
        "levels": np.linspace(-60.0, 60.0, 25),
    },
    "Constancy": {
        "title": r"$\Delta$ constancy",
        "colorbar": r"Variable $-$ Fixed",
        "levels": np.linspace(-1.60, 1.60, 25),
    },
    "Resistance": {
        "title": r"$\Delta$ resistance ($\log_{10}$)",
        "colorbar": r"Variable $-$ Fixed ($\log_{10}$ units)",
        "levels": np.linspace(-0.060, 0.060, 25),
    },
}

SPATIAL_DIFFERENCE_SPECS = {
    "GrasslandFraction": ABSOLUTE_SPECS["GrasslandFraction"],
    **DIFFERENCE_SPECS,
}

METRIC_ORDER = ("NPP", "Constancy", "Resistance")
S1_PANEL_ORDER = METRIC_ORDER
S2_PANEL_ORDER = ("GrasslandFraction",) + METRIC_ORDER


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=f"Default: DATA_DIR/{DEFAULT_OUTPUT_SUBDIR}",
    )
    parser.add_argument(
        "--grassland-mask",
        type=Path,
        default=None,
        help=(
            "Fine-resolution RPG permanent-grassland NetCDF. Default: "
            "DATA_DIR/PP10m.nc. The file metadata, not its filename, define "
            "the actual pixel size."
        ),
    )
    parser.add_argument(
        "--grassland-variable",
        default=GRASSLAND_VARIABLE,
        help=f"Presence source variable (default: {GRASSLAND_VARIABLE}).",
    )
    parser.add_argument(
        "--grassland-display-resolution-m",
        type=float,
        default=GRASSLAND_DISPLAY_RESOLUTION_M,
        help=(
            "Intermediate Lambert-93 display-mask resolution in metres "
            f"(default: {GRASSLAND_DISPLAY_RESOLUTION_M:g})."
        ),
    )
    parser.add_argument(
        "--layout",
        choices=("two-row", "row"),
        default="two-row",
        help=(
            "two-row uses a 2x2 S1 layout and a two-panels-above, one-below "
            "S2 layout; row places every panel on one row."
        ),
    )
    parser.add_argument(
        "--map-engine",
        choices=("auto", "cartopy", "plain"),
        default="auto",
        help="auto uses Cartopy when available and otherwise uses plain lon/lat axes.",
    )
    parser.add_argument(
        "--absolute-cmap",
        default="turbo",
        help="Sequential colormap for S1 (default: turbo, matching the legacy style).",
    )
    parser.add_argument(
        "--difference-cmap",
        default="RdBu_r",
        help="Diverging colormap for S2 (default: RdBu_r).",
    )
    parser.add_argument(
        "--expected-cells",
        type=int,
        default=EXPECTED_GATEWAY_CELLS,
        help="Strict gateway-cell check; use 0 only for a documented diagnostic run.",
    )
    parser.add_argument(
        "--confirm-resistance-period",
        action="store_true",
        help="Confirm that logresistance_all.nc represents 1960-2019.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacement of files already present in the output directory.",
    )
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="Run plotting/alignment tests without NetCDF inputs and exit.",
    )
    return parser.parse_args()


def require_xarray():
    try:
        import xarray as xr
    except ModuleNotFoundError as error:
        raise ModuleNotFoundError(
            "xarray is required. Run this script in the same Python environment "
            "that successfully ran paired_fixed_variable_spatial_analysis.py."
        ) from error
    return xr


def require_file(path: Path) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"Input file not found: {path}")


def clean_values(values: np.ndarray) -> np.ndarray:
    output = np.asarray(values, dtype=np.float64).copy()
    output[~np.isfinite(output)] = np.nan
    output[np.abs(output) >= MISSING_ABS_THRESHOLD] = np.nan
    return output


def coordinate_values(data_array, coordinate_name: str) -> np.ndarray | None:
    if coordinate_name not in data_array.coords:
        return None
    values = np.asarray(data_array.coords[coordinate_name].values).squeeze()
    if values.ndim != 1:
        return None
    return values.astype(np.float64)


def reduce_time_map(
    path: Path,
    variable_name: str,
    operation: str,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None, dict[str, str]]:
    """Read 60 annual records and reduce them to latitude x longitude."""
    xr = require_xarray()
    require_file(path)
    with xr.open_dataset(path, decode_times=False) as dataset:
        if variable_name not in dataset:
            available = ", ".join(dataset.data_vars)
            raise KeyError(
                f"{path.name}: '{variable_name}' not found; available: {available}"
            )
        variable = dataset[variable_name]
        if TIME_DIMENSION not in variable.dims:
            raise ValueError(
                f"{path.name}/{variable_name}: missing '{TIME_DIMENSION}'; "
                f"dimensions are {variable.dims}"
            )
        if variable.sizes[TIME_DIMENSION] < 60:
            raise ValueError(
                f"{path.name}/{variable_name}: expected at least 60 annual "
                f"records, found {variable.sizes[TIME_DIMENSION]}"
            )

        selected = variable.isel({TIME_DIMENSION: FULL_PERIOD})
        selected = selected.where(
            np.isfinite(selected) & (np.abs(selected) < MISSING_ABS_THRESHOLD)
        )
        if operation == "mean":
            result = selected.mean(dim=TIME_DIMENSION, skipna=True)
        elif operation == "std":
            result = selected.std(
                dim=TIME_DIMENSION,
                skipna=True,
                ddof=RESIDUAL_STD_DDOF,
            )
        else:
            raise ValueError(f"Unsupported temporal reduction: {operation}")

        result = result.squeeze(drop=True)
        if LATITUDE_DIMENSION in result.dims and LONGITUDE_DIMENSION in result.dims:
            result = result.transpose(LATITUDE_DIMENSION, LONGITUDE_DIMENSION)
        if result.ndim != 2:
            raise ValueError(
                f"{path.name}/{variable_name}: expected a 2-D reduced map, "
                f"found dimensions={result.dims}, shape={result.shape}"
            )

        latitude = coordinate_values(result, LATITUDE_DIMENSION)
        longitude = coordinate_values(result, LONGITUDE_DIMENSION)
        metadata = {
            "path": str(path),
            "variable": variable_name,
            "source_dimensions": str(tuple(variable.dims)),
            "source_shape": str(tuple(variable.shape)),
            "source_units": str(variable.attrs.get("units", "not specified")),
        }
        values = result.load().values
    return clean_values(values), latitude, longitude, metadata


def read_2d_map(
    path: Path,
    variable_name: str,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None, dict[str, str]]:
    xr = require_xarray()
    require_file(path)
    with xr.open_dataset(path, decode_times=False) as dataset:
        if variable_name not in dataset:
            available = ", ".join(dataset.data_vars)
            raise KeyError(
                f"{path.name}: '{variable_name}' not found; available: {available}"
            )
        variable = dataset[variable_name]
        result = variable.squeeze(drop=True)
        if LATITUDE_DIMENSION in result.dims and LONGITUDE_DIMENSION in result.dims:
            result = result.transpose(LATITUDE_DIMENSION, LONGITUDE_DIMENSION)
        if result.ndim != 2:
            raise ValueError(
                f"{path.name}/{variable_name}: expected a 2-D map, "
                f"found dimensions={result.dims}, shape={result.shape}"
            )
        latitude = coordinate_values(result, LATITUDE_DIMENSION)
        longitude = coordinate_values(result, LONGITUDE_DIMENSION)
        metadata = {
            "path": str(path),
            "variable": variable_name,
            "source_dimensions": str(tuple(variable.dims)),
            "source_shape": str(tuple(variable.shape)),
            "source_units": str(variable.attrs.get("units", "not specified")),
            "variable_attributes": str(dict(variable.attrs)),
        }
        values = result.load().values
    return clean_values(values), latitude, longitude, metadata


def require_pyproj():
    try:
        # The TGCC Python installation can emit a warning when the optional
        # PROJ database directory is not configured. This workflow uses a
        # complete explicit Lambert-93 inverse pipeline and therefore does not
        # require an EPSG database lookup.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="Valid PROJ data directory not found.*",
            )
            from pyproj import Transformer
    except ModuleNotFoundError as error:
        raise ModuleNotFoundError(
            "pyproj is required to align the Lambert-93 RPG mask with the "
            "longitude/latitude ORCHIDEE grid. It is normally installed with "
            "Cartopy."
        ) from error
    return Transformer


def lambert93_to_lonlat_transformer():
    """Build and validate a database-independent Lambert-93 inverse transform."""
    Transformer = require_pyproj()
    try:
        transformer = Transformer.from_pipeline(LAMBERT93_TO_LONLAT_PIPELINE)
        test_longitude, test_latitude = transformer.transform(700000.0, 6600000.0)
    except Exception as error:
        raise RuntimeError(
            "The explicit Lambert-93 transformation could not be initialized. "
            "Stop before processing PP10m.nc and inspect the pyproj installation."
        ) from error
    if not (
        math.isclose(float(test_longitude), 3.0, abs_tol=0.02)
        and math.isclose(float(test_latitude), 46.5, abs_tol=0.02)
    ):
        raise RuntimeError(
            "Lambert-93 projection self-check failed: expected approximately "
            f"(3 E, 46.5 N), obtained ({test_longitude}, {test_latitude})."
        )
    return transformer


def coarse_coordinate_centres(
    fine_coordinates: np.ndarray,
    aggregation_factor: int,
) -> np.ndarray:
    """Return mean source-cell centres for complete or partial coarse blocks."""
    fine_coordinates = np.asarray(fine_coordinates, dtype=np.float64)
    return np.asarray(
        [
            np.mean(fine_coordinates[start : start + aggregation_factor])
            for start in range(0, fine_coordinates.size, aggregation_factor)
        ],
        dtype=np.float64,
    )


def aggregate_grassland_mask(
    path: Path,
    variable_name: str,
    display_resolution_m: float,
) -> dict[str, object]:
    """Aggregate the fine RPG raster to a manageable Lambert-93 display grid.

    The source is never loaded in full. Strictly positive values are classified
    as permanent-grassland presence. Zero, negative values (including any
    undeclared negative no-data codes), and non-finite values are classified as
    absence. This implements the provider's non-zero-presence instruction while
    recognising that parcel area cannot legitimately be negative. The
    denominator is the total number of source pixels in each output block.
    """
    xr = require_xarray()
    require_file(path)
    if display_resolution_m <= 0:
        raise ValueError("Grassland display resolution must be positive")

    with xr.open_dataset(
        path,
        decode_cf=False,
        mask_and_scale=False,
        decode_times=False,
    ) as dataset:
        if variable_name not in dataset:
            available = ", ".join(dataset.data_vars)
            raise KeyError(
                f"{path.name}: '{variable_name}' not found; available: {available}"
            )
        band = dataset[variable_name].squeeze(drop=True)
        if not {
            GRASSLAND_Y_DIMENSION,
            GRASSLAND_X_DIMENSION,
        }.issubset(band.dims):
            raise ValueError(
                f"{path.name}/{variable_name}: expected x/y dimensions, found "
                f"{band.dims}"
            )
        band = band.transpose(GRASSLAND_Y_DIMENSION, GRASSLAND_X_DIMENSION)
        x = np.asarray(dataset[GRASSLAND_X_DIMENSION].values, dtype=np.float64)
        y = np.asarray(dataset[GRASSLAND_Y_DIMENSION].values, dtype=np.float64)
        if x.ndim != 1 or y.ndim != 1:
            raise ValueError("The RPG x and y coordinates must be one-dimensional")
        if x.size != band.sizes[GRASSLAND_X_DIMENSION] or y.size != band.sizes[
            GRASSLAND_Y_DIMENSION
        ]:
            raise ValueError("The RPG coordinate sizes do not match Band1")
        if x.size < 2 or y.size < 2:
            raise ValueError("The RPG grid has insufficient coordinate values")

        x_steps = np.diff(x)
        y_steps = np.diff(y)
        dx = float(np.median(x_steps))
        dy = float(np.median(y_steps))
        if not np.allclose(x_steps, dx, rtol=0.0, atol=1.0e-6):
            raise ValueError("The RPG x coordinate is not regularly spaced")
        if not np.allclose(y_steps, dy, rtol=0.0, atol=1.0e-6):
            raise ValueError("The RPG y coordinate is not regularly spaced")
        if dx == 0 or dy == 0:
            raise ValueError("The RPG coordinate spacing cannot be zero")

        factor_x_float = display_resolution_m / abs(dx)
        factor_y_float = display_resolution_m / abs(dy)
        factor_x = int(round(factor_x_float))
        factor_y = int(round(factor_y_float))
        if factor_x < 1 or factor_y < 1:
            raise ValueError(
                "The requested display resolution is finer than the RPG raster"
            )
        if not (
            math.isclose(factor_x_float, factor_x, rel_tol=0.0, abs_tol=1.0e-6)
            and math.isclose(
                factor_y_float,
                factor_y,
                rel_tol=0.0,
                abs_tol=1.0e-6,
            )
        ):
            raise ValueError(
                f"Display resolution {display_resolution_m:g} m is not an "
                f"integer multiple of the detected RPG spacing "
                f"({abs(dx):g} x {abs(dy):g} m)"
            )

        ny, nx = band.shape
        coarse_ny = math.ceil(ny / factor_y)
        coarse_nx = math.ceil(nx / factor_x)
        presence_count = np.zeros((coarse_ny, coarse_nx), dtype=np.int32)
        source_pixel_count = np.zeros((coarse_ny, coarse_nx), dtype=np.int32)
        fill_value = band.attrs.get("_FillValue", -32767)
        if isinstance(fill_value, np.ndarray):
            fill_value = fill_value.item()

        source_positive_count = 0
        source_zero_count = 0
        source_negative_count = 0
        source_nonfinite_count = 0
        source_declared_fill_count = 0

        coarse_rows_per_block = max(
            1,
            GRASSLAND_SOURCE_ROWS_PER_BLOCK // factor_y,
        )
        for coarse_start in range(0, coarse_ny, coarse_rows_per_block):
            coarse_stop = min(
                coarse_ny,
                coarse_start + coarse_rows_per_block,
            )
            fine_start = coarse_start * factor_y
            fine_stop = min(ny, coarse_stop * factor_y)
            values = np.asarray(
                band.isel(
                    {
                        GRASSLAND_Y_DIMENSION: slice(fine_start, fine_stop),
                        GRASSLAND_X_DIMENSION: slice(0, nx),
                    }
                ).values
            )
            if values.ndim != 2:
                raise ValueError(
                    f"Unexpected RPG block shape {values.shape}; expected 2-D"
                )

            finite = np.isfinite(values)
            # Parcel-area values are necessarily positive. Treating every
            # finite non-zero value as presence can incorrectly include an
            # undeclared negative background/no-data code (for example
            # -32768 when the declared FillValue is -32767).
            present = finite & (values > 0)
            source_positive_count += int(np.count_nonzero(present))
            source_zero_count += int(np.count_nonzero(finite & (values == 0)))
            source_negative_count += int(np.count_nonzero(finite & (values < 0)))
            source_nonfinite_count += int(np.count_nonzero(~finite))
            source_declared_fill_count += int(
                np.count_nonzero(finite & (values == fill_value))
            )
            actual = np.ones(values.shape, dtype=bool)
            padded_rows = (coarse_stop - coarse_start) * factor_y
            padded_cols = coarse_nx * factor_x
            if values.shape != (padded_rows, padded_cols):
                pad_rows = padded_rows - values.shape[0]
                pad_cols = padded_cols - values.shape[1]
                present = np.pad(
                    present,
                    ((0, pad_rows), (0, pad_cols)),
                    constant_values=False,
                )
                actual = np.pad(
                    actual,
                    ((0, pad_rows), (0, pad_cols)),
                    constant_values=False,
                )

            output_rows = coarse_stop - coarse_start
            presence_count[coarse_start:coarse_stop, :] = present.reshape(
                output_rows,
                factor_y,
                coarse_nx,
                factor_x,
            ).sum(axis=(1, 3), dtype=np.int32)
            source_pixel_count[coarse_start:coarse_stop, :] = actual.reshape(
                output_rows,
                factor_y,
                coarse_nx,
                factor_x,
            ).sum(axis=(1, 3), dtype=np.int32)

        if int(np.sum(presence_count, dtype=np.int64)) == 0:
            raise ValueError(
                "No strictly positive permanent-grassland pixels were detected "
                "in the RPG file"
            )
        with np.errstate(divide="ignore", invalid="ignore"):
            fraction_percent = 100.0 * presence_count / source_pixel_count
        fraction_percent[source_pixel_count == 0] = np.nan

        x_coarse = coarse_coordinate_centres(x, factor_x)
        y_coarse = coarse_coordinate_centres(y, factor_y)
        grid_mapping_name = str(band.attrs.get("grid_mapping", ""))
        mapping_attributes: dict[str, object] = {}
        if grid_mapping_name and grid_mapping_name in dataset:
            mapping_attributes = dict(dataset[grid_mapping_name].attrs)
        source_wkt = str(
            mapping_attributes.get("crs_wkt")
            or mapping_attributes.get("spatial_ref")
            or ""
        )
        geotransform = str(mapping_attributes.get("GeoTransform", ""))
        metadata = {
            "path": str(path),
            "variable": variable_name,
            "source_shape": str(tuple(band.shape)),
            "source_dtype": str(band.dtype),
            "source_fill_value": str(fill_value),
            "source_positive_pixel_count": str(source_positive_count),
            "source_zero_pixel_count": str(source_zero_count),
            "source_negative_pixel_count": str(source_negative_count),
            "source_nonfinite_pixel_count": str(source_nonfinite_count),
            "source_declared_fill_pixel_count": str(
                source_declared_fill_count
            ),
            "detected_x_spacing_m": f"{abs(dx):.12g}",
            "detected_y_spacing_m": f"{abs(dy):.12g}",
            "display_resolution_m": f"{display_resolution_m:.12g}",
            "aggregation_factor_x": str(factor_x),
            "aggregation_factor_y": str(factor_y),
            "display_shape": str(tuple(fraction_percent.shape)),
            "grid_mapping": grid_mapping_name,
            "geotransform": geotransform,
            "source_wkt_available": str(bool(source_wkt)),
        }

    return {
        "fraction_percent": fraction_percent.astype(np.float32),
        "presence_count": presence_count,
        "source_pixel_count": source_pixel_count,
        "x": x_coarse,
        "y": y_coarse,
        "source_wkt": source_wkt,
        "metadata": metadata,
    }


def coordinate_cell_indices(
    values: np.ndarray,
    centres: np.ndarray,
) -> np.ndarray:
    """Locate coordinates in cells represented by ascending or descending centres."""
    values = np.asarray(values, dtype=np.float64)
    centres = np.asarray(centres, dtype=np.float64)
    if centres.ndim != 1 or centres.size < 2:
        raise ValueError("Target coordinate centres must be one-dimensional")
    edges = np.empty(centres.size + 1, dtype=np.float64)
    edges[1:-1] = 0.5 * (centres[:-1] + centres[1:])
    edges[0] = centres[0] - 0.5 * (centres[1] - centres[0])
    edges[-1] = centres[-1] + 0.5 * (centres[-1] - centres[-2])
    if edges[0] < edges[-1]:
        indices = np.searchsorted(edges, values, side="right") - 1
    else:
        reversed_indices = np.searchsorted(
            edges[::-1],
            values,
            side="right",
        ) - 1
        indices = centres.size - 1 - reversed_indices
    inside = (values >= np.min(edges)) & (values <= np.max(edges))
    indices = indices.astype(np.int32, copy=False)
    indices[(indices < 0) | (indices >= centres.size) | ~inside] = -1
    return indices


def remap_true_corsica_to_packed_orchidee(
    longitude: np.ndarray,
    latitude: np.ndarray,
    x_index: np.ndarray,
    y_index: np.ndarray,
    target_longitude_size: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Associate geographic Corsica cells with its packed ORCHIDEE columns.

    The returned x indices are used only to look up or aggregate ORCHIDEE-grid
    values.  ``longitude`` and ``latitude`` are not changed, so the rendered
    island remains at its true position.
    """
    remapped_x = np.asarray(x_index, dtype=np.int32).copy()
    longitude = np.asarray(longitude, dtype=np.float64)
    latitude = np.asarray(latitude, dtype=np.float64)
    y_index = np.asarray(y_index, dtype=np.int32)
    candidate = (
        (longitude >= CORSICA_TRUE_MIN_LONGITUDE)
        & (longitude <= CORSICA_TRUE_MAX_LONGITUDE)
        & (latitude >= CORSICA_TRUE_MIN_LATITUDE)
        & (latitude <= CORSICA_TRUE_MAX_LATITUDE)
        & (remapped_x >= 0)
        & (y_index >= 0)
    )
    shifted_x = remapped_x + CORSICA_PACKED_SHIFT_CELLS
    remapped = candidate & (shifted_x < target_longitude_size)
    outside_packed_grid = candidate & ~remapped
    remapped_x[remapped] = shifted_x[remapped]
    # Cells east of the packed component cannot represent an ORCHIDEE cell.
    # Ignoring them is safer than assigning them to an unrelated mainland cell.
    remapped_x[outside_packed_grid] = -1
    return remapped_x, remapped, outside_packed_grid


def align_grassland_to_orchidee(
    grassland: dict[str, object],
    target_latitude: np.ndarray,
    target_longitude: np.ndarray,
) -> dict[str, object]:
    """Transform 1-km Lambert centres and aggregate their fine-pixel counts."""
    transformer = lambert93_to_lonlat_transformer()

    x = np.asarray(grassland["x"], dtype=np.float64)
    y = np.asarray(grassland["y"], dtype=np.float64)
    presence = np.asarray(grassland["presence_count"], dtype=np.int32)
    total = np.asarray(grassland["source_pixel_count"], dtype=np.int32)
    shape = presence.shape
    if total.shape != shape or shape != (y.size, x.size):
        raise ValueError("The aggregated RPG arrays and coordinates do not align")

    longitude_1km = np.empty(shape, dtype=np.float32)
    latitude_1km = np.empty(shape, dtype=np.float32)
    target_y_index = np.full(shape, -1, dtype=np.int16)
    target_x_index = np.full(shape, -1, dtype=np.int16)
    target_presence = np.zeros(
        (target_latitude.size, target_longitude.size),
        dtype=np.int64,
    )
    target_total = np.zeros_like(target_presence)
    corsica_remapped_1km_cells = 0
    corsica_positive_1km_cells = 0
    corsica_outside_packed_grid_1km_cells = 0

    rows_per_block = 64
    for start in range(0, y.size, rows_per_block):
        stop = min(y.size, start + rows_per_block)
        x_grid, y_grid = np.meshgrid(x, y[start:stop])
        lon_block, lat_block = transformer.transform(x_grid, y_grid)
        lon_block = np.asarray(lon_block, dtype=np.float64)
        lat_block = np.asarray(lat_block, dtype=np.float64)
        longitude_1km[start:stop, :] = lon_block.astype(np.float32)
        latitude_1km[start:stop, :] = lat_block.astype(np.float32)
        x_index = coordinate_cell_indices(lon_block, target_longitude)
        y_index = coordinate_cell_indices(lat_block, target_latitude)
        x_index, corsica_remapped, corsica_outside = (
            remap_true_corsica_to_packed_orchidee(
                lon_block,
                lat_block,
                x_index,
                y_index,
                target_longitude.size,
            )
        )
        presence_block = presence[start:stop, :]
        total_block = total[start:stop, :]
        corsica_remapped_1km_cells += int(np.count_nonzero(corsica_remapped))
        corsica_positive_1km_cells += int(
            np.count_nonzero(corsica_remapped & (presence_block > 0))
        )
        corsica_outside_packed_grid_1km_cells += int(
            np.count_nonzero(corsica_outside)
        )
        target_x_index[start:stop, :] = x_index.astype(np.int16)
        target_y_index[start:stop, :] = y_index.astype(np.int16)
        inside = (x_index >= 0) & (y_index >= 0)
        if np.any(inside):
            np.add.at(
                target_presence,
                (y_index[inside], x_index[inside]),
                presence_block[inside],
            )
            np.add.at(
                target_total,
                (y_index[inside], x_index[inside]),
                total_block[inside],
            )

    with np.errstate(divide="ignore", invalid="ignore"):
        fraction_8km = 100.0 * target_presence / target_total
    fraction_8km[target_total == 0] = np.nan
    return {
        "fraction_8km_percent": fraction_8km.astype(np.float32),
        "presence_count_8km": target_presence,
        "source_pixel_count_8km": target_total,
        "longitude_1km": longitude_1km,
        "latitude_1km": latitude_1km,
        "target_y_index": target_y_index,
        "target_x_index": target_x_index,
        "corsica_remapped_1km_cells": corsica_remapped_1km_cells,
        "corsica_positive_1km_cells": corsica_positive_1km_cells,
        "corsica_outside_packed_grid_1km_cells": (
            corsica_outside_packed_grid_1km_cells
        ),
    }


def align_to_reference(
    values: np.ndarray,
    source_latitude: np.ndarray | None,
    source_longitude: np.ndarray | None,
    target_shape: tuple[int, int],
    target_latitude: np.ndarray | None,
    target_longitude: np.ndarray | None,
    source_name: str,
    allow_confirmed_latitude_fallback: bool,
) -> np.ndarray:
    output = clean_values(values)
    if output.shape == target_shape[::-1] and output.shape != target_shape:
        output = output.T
        source_latitude, source_longitude = source_longitude, source_latitude
        warnings.warn(f"{source_name}: transposed reversed spatial dimensions")
    if output.shape != target_shape:
        raise ValueError(
            f"{source_name}: expected grid {target_shape}, found {output.shape}"
        )

    if target_latitude is not None and source_latitude is not None:
        if source_latitude.shape != target_latitude.shape:
            raise ValueError(f"{source_name}: latitude size does not match reference")
        if np.allclose(source_latitude, target_latitude, equal_nan=False):
            pass
        elif np.allclose(source_latitude[::-1], target_latitude, equal_nan=False):
            output = output[::-1, :]
            source_latitude = source_latitude[::-1]
            warnings.warn(f"{source_name}: reversed latitude to match reference")
        else:
            raise ValueError(f"{source_name}: latitude coordinates do not align")
    elif allow_confirmed_latitude_fallback and CONFIRMED_LEGACY_LATITUDE_FLIP:
        output = output[::-1, :]
        warnings.warn(
            f"{source_name}: latitude coordinate unavailable; applied the "
            "previously diagnosed latitude flip"
        )

    if target_longitude is not None and source_longitude is not None:
        if source_longitude.shape != target_longitude.shape:
            raise ValueError(f"{source_name}: longitude size does not match reference")
        if np.allclose(source_longitude, target_longitude, equal_nan=False):
            pass
        elif np.allclose(source_longitude[::-1], target_longitude, equal_nan=False):
            output = output[:, ::-1]
            warnings.warn(f"{source_name}: reversed longitude to match reference")
        else:
            raise ValueError(f"{source_name}: longitude coordinates do not align")
    return output


def validate_geographic_coordinates(
    latitude: np.ndarray | None,
    longitude: np.ndarray | None,
    shape: tuple[int, int],
) -> tuple[np.ndarray, np.ndarray]:
    if latitude is None or longitude is None:
        raise ValueError(
            "The raw NPP reference file must provide one-dimensional latitude "
            "and longitude coordinates for geographic maps."
        )
    if latitude.shape != (shape[0],) or longitude.shape != (shape[1],):
        raise ValueError(
            f"Coordinate lengths do not match map shape {shape}: "
            f"latitude={latitude.shape}, longitude={longitude.shape}"
        )
    if not (
        39.0 <= float(np.nanmin(latitude)) <= 45.0
        and 48.0 <= float(np.nanmax(latitude)) <= 54.0
        and -8.0 <= float(np.nanmin(longitude)) <= 0.0
        and 8.0 <= float(np.nanmax(longitude)) <= 15.0
    ):
        raise ValueError(
            "Latitude/longitude ranges are not plausible for the France grid: "
            f"lat=[{np.nanmin(latitude)}, {np.nanmax(latitude)}], "
            f"lon=[{np.nanmin(longitude)}, {np.nanmax(longitude)}]"
        )
    return latitude, longitude


def calculate_metric_maps(
    data_dir: Path,
    resistance_period_confirmed: bool,
) -> tuple[
    dict[str, dict[str, np.ndarray]],
    np.ndarray,
    np.ndarray,
    list[dict[str, str]],
]:
    if not resistance_period_confirmed:
        raise ValueError(
            "Resistance was not transformed again by design. Re-run with "
            "--confirm-resistance-period after confirming that "
            "logresistance_all.nc represents 1960-2019."
        )

    maps: dict[str, dict[str, np.ndarray]] = {
        "NPP": {},
        "Constancy": {},
        "Resistance": {},
    }
    metadata: list[dict[str, str]] = []

    fixed_npp, latitude, longitude, info = reduce_time_map(
        data_dir / NPP_FILES["Fixed"], NPP_VARIABLE, "mean"
    )
    fixed_npp *= NPP_ANNUAL_FACTOR
    maps["NPP"]["Fixed"] = fixed_npp
    metadata.append({"role": "Fixed NPP", **info})

    target_shape = fixed_npp.shape
    if target_shape != EXPECTED_GRID_SHAPE:
        raise ValueError(
            f"Expected the validated {EXPECTED_GRID_SHAPE} grid; found {target_shape}"
        )
    latitude, longitude = validate_geographic_coordinates(
        latitude, longitude, target_shape
    )

    variable_npp, source_lat, source_lon, info = reduce_time_map(
        data_dir / NPP_FILES["Variable"], NPP_VARIABLE, "mean"
    )
    variable_npp = align_to_reference(
        variable_npp,
        source_lat,
        source_lon,
        target_shape,
        latitude,
        longitude,
        "Variable NPP",
        allow_confirmed_latitude_fallback=False,
    )
    maps["NPP"]["Variable"] = variable_npp * NPP_ANNUAL_FACTOR
    metadata.append({"role": "Variable NPP", **info})

    residual_sd: dict[str, np.ndarray] = {}
    for configuration in ("Fixed", "Variable"):
        values, source_lat, source_lon, info = reduce_time_map(
            data_dir / RESIDUAL_FILES[configuration],
            RESIDUAL_VARIABLE,
            "std",
        )
        values = align_to_reference(
            values,
            source_lat,
            source_lon,
            target_shape,
            latitude,
            longitude,
            f"{configuration} residual SD",
            allow_confirmed_latitude_fallback=False,
        )
        residual_sd[configuration] = values
        metadata.append({"role": f"{configuration} residual SD", **info})

    for configuration in ("Fixed", "Variable"):
        with np.errstate(divide="ignore", invalid="ignore"):
            constancy = maps["NPP"][configuration] / residual_sd[configuration]
        constancy[~np.isfinite(constancy)] = np.nan
        maps["Constancy"][configuration] = constancy

    resistance_path = data_dir / RESISTANCE_FILE
    for configuration in ("Fixed", "Variable"):
        values, source_lat, source_lon, info = read_2d_map(
            resistance_path,
            RESISTANCE_VARIABLES[configuration],
        )
        values = align_to_reference(
            values,
            source_lat,
            source_lon,
            target_shape,
            latitude,
            longitude,
            f"{configuration} resistance",
            allow_confirmed_latitude_fallback=True,
        )
        maps["Resistance"][configuration] = values
        metadata.append({"role": f"{configuration} resistance", **info})

    return maps, latitude, longitude, metadata


def prepare_display_maps(
    maps: dict[str, dict[str, np.ndarray]],
    expected_cells: int,
) -> tuple[
    dict[str, np.ndarray],
    dict[str, np.ndarray],
    np.ndarray,
    dict[str, int],
]:
    """Apply one gateway and return S1 absolute and S2 paired-difference maps."""
    gateway = np.isfinite(maps["Constancy"]["Fixed"]) & (
        maps["Constancy"]["Fixed"] > 0
    )
    gateway_count = int(np.count_nonzero(gateway))
    if expected_cells > 0 and gateway_count != expected_cells:
        raise ValueError(
            f"Gateway contains {gateway_count} cells, not the expected "
            f"{expected_cells}. Stop and inspect input versions/alignment."
        )

    absolute_maps: dict[str, np.ndarray] = {}
    difference_maps: dict[str, np.ndarray] = {}
    valid_counts: dict[str, int] = {}
    for metric in METRIC_ORDER:
        fixed = maps[metric]["Fixed"]
        variable = maps[metric]["Variable"]
        valid = gateway & np.isfinite(fixed) & np.isfinite(variable)
        if metric in {"NPP", "Constancy"}:
            valid &= (fixed > 0) & (variable > 0)
        # A resistance value of exactly zero on the log10 scale is valid.
        valid_count = int(np.count_nonzero(valid))
        if expected_cells > 0 and valid_count != expected_cells:
            raise ValueError(
                f"{metric}: {valid_count} paired finite cells after the common "
                f"gateway, not {expected_cells}. Stop before plotting."
            )
        absolute_maps[metric] = np.where(valid, variable, np.nan)
        difference_maps[metric] = np.where(valid, variable - fixed, np.nan)
        valid_counts[metric] = valid_count
    return absolute_maps, difference_maps, gateway, valid_counts


def expand_to_grassland_display_grid(
    values_8km: np.ndarray,
    gateway: np.ndarray,
    grassland_fraction_1km: np.ndarray,
    target_y_index: np.ndarray,
    target_x_index: np.ndarray,
) -> np.ndarray:
    """Show an ORCHIDEE value only in 1-km cells containing mapped grassland."""
    output = np.full(grassland_fraction_1km.shape, np.nan, dtype=np.float32)
    inside = (target_y_index >= 0) & (target_x_index >= 0)
    if not np.any(inside):
        raise ValueError("No 1-km RPG cells overlap the ORCHIDEE grid")
    y_index = target_y_index[inside].astype(np.intp)
    x_index = target_x_index[inside].astype(np.intp)
    source_present = grassland_fraction_1km[inside] > 0
    source_gateway = gateway[y_index, x_index]
    source_values = values_8km[y_index, x_index]
    use = source_present & source_gateway & np.isfinite(source_values)
    flat_positions = np.flatnonzero(inside)
    output.ravel()[flat_positions[use]] = source_values[use].astype(np.float32)
    return output


def prepare_grassland_masked_figures(
    absolute_maps: dict[str, np.ndarray],
    difference_maps: dict[str, np.ndarray],
    gateway: np.ndarray,
    grassland: dict[str, object],
    aligned_grassland: dict[str, np.ndarray],
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    fraction_1km = np.asarray(grassland["fraction_percent"], dtype=np.float32)
    target_y_index = aligned_grassland["target_y_index"]
    target_x_index = aligned_grassland["target_x_index"]
    fraction_8km = aligned_grassland["fraction_8km_percent"]

    s1_maps: dict[str, np.ndarray] = {}
    s2_maps: dict[str, np.ndarray] = {
        "GrasslandFraction": expand_to_grassland_display_grid(
            fraction_8km,
            gateway,
            fraction_1km,
            target_y_index,
            target_x_index,
        )
    }
    for metric in METRIC_ORDER:
        s1_maps[metric] = expand_to_grassland_display_grid(
            absolute_maps[metric],
            gateway,
            fraction_1km,
            target_y_index,
            target_x_index,
        )
        s2_maps[metric] = expand_to_grassland_display_grid(
            difference_maps[metric],
            gateway,
            fraction_1km,
            target_y_index,
            target_x_index,
        )
    return s1_maps, s2_maps


def load_cartopy(map_engine: str):
    if map_engine == "plain":
        return None
    try:
        import cartopy.crs as ccrs
        import cartopy.feature as cfeature
    except ModuleNotFoundError as error:
        if map_engine == "cartopy":
            raise ModuleNotFoundError(
                "--map-engine cartopy was requested, but Cartopy is unavailable."
            ) from error
        warnings.warn(
            "Cartopy is unavailable; maps will use plain longitude/latitude axes "
            "without an external coastline layer."
        )
        return None
    return ccrs, cfeature


def longitude_label(value: float, _position: int | None = None) -> str:
    if abs(value) < 1.0e-10:
        return "0°"
    suffix = "W" if value < 0 else "E"
    return f"{abs(value):g}°{suffix}"


def latitude_label(value: float, _position: int | None = None) -> str:
    suffix = "S" if value < 0 else "N"
    return f"{abs(value):g}°{suffix}"


def panel_positions(layout: str, panel_count: int):
    if panel_count == 4:
        if layout == "row":
            return (
                (1, 4),
                ((0, 0), (0, 1), (0, 2), (0, 3)),
                (20.8, 5.1),
            )
        return (
            (2, 2),
            ((0, 0), (0, 1), (1, 0), (1, 1)),
            (13.2, 9.2),
        )
    if panel_count == 3:
        if layout == "row":
            return (1, 3), ((0, 0), (0, 1), (0, 2)), (15.6, 5.1)
        return (
            (2, 4),
            ((0, slice(0, 2)), (0, slice(2, 4)), (1, slice(1, 3))),
            (13.2, 8.7),
        )
    raise ValueError(f"Unsupported panel count: {panel_count}")


def add_map_axis(figure, grid_spec, position, cartopy_modules):
    if cartopy_modules is None:
        return figure.add_subplot(grid_spec[position])
    ccrs, _ = cartopy_modules
    return figure.add_subplot(grid_spec[position], projection=ccrs.PlateCarree())


def configure_axis(axis, cartopy_modules) -> None:
    if cartopy_modules is None:
        axis.set_facecolor(LAND_COLOR)
        axis.set_xlim(MAP_EXTENT[0], MAP_EXTENT[1])
        axis.set_ylim(MAP_EXTENT[2], MAP_EXTENT[3])
        axis.set_xticks(LONGITUDE_TICKS)
        axis.set_yticks(LATITUDE_TICKS)
        axis.xaxis.set_major_formatter(FuncFormatter(longitude_label))
        axis.yaxis.set_major_formatter(FuncFormatter(latitude_label))
        axis.set_xlabel("Longitude")
        axis.set_ylabel("Latitude")
        middle_latitude = 0.5 * (MAP_EXTENT[2] + MAP_EXTENT[3])
        axis.set_aspect(1.0 / math.cos(math.radians(middle_latitude)))
        axis.grid(False)
        return

    ccrs, cfeature = cartopy_modules
    axis.set_extent(MAP_EXTENT, crs=ccrs.PlateCarree())
    # Painting the GeoAxes background supplies the ocean colour without
    # requiring Cartopy's separate Natural Earth ocean or lake downloads.
    axis.set_facecolor(OCEAN_COLOR)
    axis.add_feature(
        cfeature.LAND.with_scale("50m"),
        facecolor=LAND_COLOR,
        edgecolor="none",
        zorder=0,
    )
    axis.coastlines(
        resolution="50m",
        linewidth=0.6,
        color="#333333",
        zorder=3,
    )
    axis.add_feature(
        cfeature.BORDERS.with_scale("50m"),
        linewidth=0.45,
        edgecolor="#555555",
        zorder=3,
    )
    gridlines = axis.gridlines(
        crs=ccrs.PlateCarree(),
        draw_labels=True,
        xlocs=LONGITUDE_TICKS,
        ylocs=LATITUDE_TICKS,
        linewidth=0.0,
        color="#C8C8C8",
        alpha=0.65,
        linestyle="-",
    )
    gridlines.top_labels = False
    gridlines.right_labels = False
    gridlines.xlabel_style = {"size": 9}
    gridlines.ylabel_style = {"size": 9}
    axis.set_xlabel("Longitude")
    axis.set_ylabel("Latitude")


def create_map_figure(
    maps_to_plot: dict[str, np.ndarray],
    latitude: np.ndarray,
    longitude: np.ndarray,
    specifications: dict[str, dict[str, object]],
    cmap_name: str,
    layout: str,
    cartopy_modules,
    panel_order: tuple[str, ...],
):
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "axes.linewidth": 0.8,
        }
    )
    grid_shape, positions, figure_size = panel_positions(layout, len(panel_order))
    figure = plt.figure(figsize=figure_size, layout="constrained")
    grid_spec = figure.add_gridspec(*grid_shape)

    for panel_index, metric in enumerate(panel_order):
        # Give every panel its own fixed-ratio map/colorbar sub-grid. Passing
        # each GeoAxes directly to figure.colorbar lets constrained_layout
        # shrink panels by different amounts when labels have different
        # widths, which made the first S2 panel visibly smaller.
        panel_grid = grid_spec[positions[panel_index]].subgridspec(
            1,
            2,
            width_ratios=(1.0, 0.050),
            wspace=0.08,
        )
        axis = add_map_axis(
            figure,
            panel_grid,
            (0, 0),
            cartopy_modules,
        )
        colorbar_axis = figure.add_subplot(panel_grid[0, 1])
        spec = specifications[metric]
        colormap = plt.get_cmap(str(spec.get("cmap", cmap_name))).copy()
        # Transparent missing cells reveal the pale land/ocean base map.
        colormap.set_bad((0.0, 0.0, 0.0, 0.0))
        levels = np.asarray(spec["levels"], dtype=float)
        norm = BoundaryNorm(levels, colormap.N, clip=False)
        kwargs = {
            "cmap": colormap,
            "norm": norm,
            "shading": "auto",
            "rasterized": True,
            "zorder": 1,
        }
        if cartopy_modules is not None:
            ccrs, _ = cartopy_modules
            kwargs["transform"] = ccrs.PlateCarree()
        mesh = axis.pcolormesh(
            longitude,
            latitude,
            maps_to_plot[metric],
            **kwargs,
        )
        configure_axis(axis, cartopy_modules)
        axis.set_title(str(spec["title"]), color="#5A5A5A", pad=7)
        axis.text(
            -0.09,
            1.03,
            f"({chr(ord('a') + panel_index)})",
            transform=axis.transAxes,
            ha="left",
            va="bottom",
            fontsize=13,
            fontweight="bold",
            color="#333333",
            clip_on=False,
        )
        # Symmetric difference scales must show zero explicitly so that the
        # pale central colours are unambiguously read as changes near zero.
        if (
            levels[0] < 0.0
            and levels[-1] > 0.0
            and np.isclose(abs(levels[0]), abs(levels[-1]))
        ):
            ticks = np.linspace(levels[0], levels[-1], 5)
        else:
            ticks = np.linspace(levels[0], levels[-1], 6)
        colorbar = figure.colorbar(
            mesh,
            cax=colorbar_axis,
            orientation="vertical",
            ticks=ticks,
            extend=str(spec.get("extend", "both")),
        )
        colorbar.ax.tick_params(labelsize=8, length=2.5)
        colorbar.set_label(str(spec["colorbar"]), fontsize=9.5)
    return figure


def save_map_figure(
    maps_to_plot: dict[str, np.ndarray],
    latitude: np.ndarray,
    longitude: np.ndarray,
    specifications: dict[str, dict[str, object]],
    cmap_name: str,
    layout: str,
    map_engine: str,
    output_png: Path,
    output_pdf: Path,
    panel_order: tuple[str, ...],
    png_dpi: int = PNG_DPI,
) -> str:
    cartopy_modules = load_cartopy(map_engine)
    actual_engine = "cartopy" if cartopy_modules is not None else "plain"

    def render(modules):
        figure = create_map_figure(
            maps_to_plot,
            latitude,
            longitude,
            specifications,
            cmap_name,
            layout,
            modules,
            panel_order,
        )
        try:
            figure.savefig(output_pdf, bbox_inches="tight", facecolor="white")
            figure.savefig(
                output_png,
                dpi=png_dpi,
                bbox_inches="tight",
                facecolor="white",
            )
        finally:
            plt.close(figure)

    try:
        render(cartopy_modules)
    except Exception as error:
        if map_engine != "auto" or cartopy_modules is None:
            raise
        warnings.warn(
            "Cartopy rendering failed (often because Natural Earth files are "
            f"not cached): {error}. Retrying with plain lon/lat axes."
        )
        render(None)
        actual_engine = "plain"
    return actual_engine


def output_paths(output_dir: Path) -> dict[str, Path]:
    return {
        "s1_png": output_dir / "Figure_S1_varllvar_spatial_distribution_1960_2019.png",
        "s1_pdf": output_dir / "Figure_S1_varllvar_spatial_distribution_1960_2019.pdf",
        "s2_png": output_dir / "Figure_S2_grassland_fraction_and_variable_minus_fixed_1960_2019.png",
        "s2_pdf": output_dir / "Figure_S2_grassland_fraction_and_variable_minus_fixed_1960_2019.pdf",
        "grassland_1km_nc": output_dir / "permanent_grassland_fraction_1km_display.nc",
        "grassland_8km_nc": output_dir / "permanent_grassland_fraction_ORCHIDEE_grid.nc",
        "grassland_8km_csv": output_dir / "permanent_grassland_fraction_ORCHIDEE_grid.csv",
        "summary": output_dir / "Figure_S1_S2_map_summary.csv",
        "methods": output_dir / "analysis_methods_and_settings.txt",
    }


def protect_existing_outputs(paths: dict[str, Path], overwrite: bool) -> None:
    existing = [path for path in paths.values() if path.exists()]
    if existing and not overwrite:
        formatted = "\n".join(f"  {path}" for path in existing)
        raise FileExistsError(
            "Output files already exist and were not changed:\n"
            f"{formatted}\nUse --overwrite only after checking these files."
        )


def write_grassland_outputs(
    paths: dict[str, Path],
    grassland: dict[str, object],
    aligned_grassland: dict[str, np.ndarray],
    latitude: np.ndarray,
    longitude: np.ndarray,
    gateway: np.ndarray,
) -> None:
    xr = require_xarray()
    fraction_1km = np.asarray(grassland["fraction_percent"], dtype=np.float32)
    presence_1km = np.asarray(grassland["presence_count"], dtype=np.int32)
    total_1km = np.asarray(grassland["source_pixel_count"], dtype=np.int32)
    x_1km = np.asarray(grassland["x"], dtype=np.float64)
    y_1km = np.asarray(grassland["y"], dtype=np.float64)
    metadata = dict(grassland["metadata"])

    one_km_dataset = xr.Dataset(
        data_vars={
            "permanent_grassland_fraction": (
                ("y", "x"),
                fraction_1km,
                {
                    "long_name": "permanent grassland fraction",
                    "units": "%",
                },
            ),
            "grassland_source_pixel_count": (
                ("y", "x"),
                presence_1km,
                {
                    "long_name": "fine-grid pixels classified as permanent grassland"
                },
            ),
            "total_source_pixel_count": (
                ("y", "x"),
                total_1km,
                {"long_name": "fine-grid pixels represented in the display cell"},
            ),
        },
        coords={
            "x": (
                "x",
                x_1km,
                {"standard_name": "projection_x_coordinate", "units": "m"},
            ),
            "y": (
                "y",
                y_1km,
                {"standard_name": "projection_y_coordinate", "units": "m"},
            ),
        },
        attrs={
            "title": "Permanent grassland fraction on the 1-km display grid",
            "source": metadata.get("path", ""),
            "source_variable": metadata.get("variable", ""),
            "source_pixel_rule": (
                "presence = finite Band1 > 0; zero, negative and non-finite "
                "values = absence"
            ),
            "crs": "RGF93 v1 / Lambert-93 (EPSG:2154)",
            "purpose": "cartographic display mask only",
        },
    )
    one_km_dataset.to_netcdf(paths["grassland_1km_nc"])

    fraction_8km = aligned_grassland["fraction_8km_percent"].astype(np.float32)
    presence_8km = aligned_grassland["presence_count_8km"].astype(np.int32)
    total_8km = aligned_grassland["source_pixel_count_8km"].astype(np.int32)
    eight_km_dataset = xr.Dataset(
        data_vars={
            "permanent_grassland_fraction": (
                (LATITUDE_DIMENSION, LONGITUDE_DIMENSION),
                fraction_8km,
                {
                    "long_name": "permanent grassland fraction",
                    "units": "%",
                },
            ),
            "grassland_source_pixel_count": (
                (LATITUDE_DIMENSION, LONGITUDE_DIMENSION),
                presence_8km,
            ),
            "total_source_pixel_count": (
                (LATITUDE_DIMENSION, LONGITUDE_DIMENSION),
                total_8km,
            ),
            "analysis_gateway": (
                (LATITUDE_DIMENSION, LONGITUDE_DIMENSION),
                gateway.astype(np.int8),
                {
                    "long_name": "cell included by recalculated Fixed constancy > 0"
                },
            ),
        },
        coords={
            LATITUDE_DIMENSION: latitude,
            LONGITUDE_DIMENSION: longitude,
        },
        attrs={
            "title": "Permanent grassland fraction on the ORCHIDEE grid",
            "aggregation_note": (
                "Fine-grid counts were aggregated through a 1-km Lambert-93 "
                "intermediate grid assigned by cell centre. No fraction "
                "threshold was applied to the analytical sample."
            ),
            "corsica_mapping_note": (
                "RPG cells retain true geographic coordinates for rendering; "
                "their lookup indices are shifted nine longitude columns east "
                "to match the packed Corsica component in the ORCHIDEE array."
            ),
        },
    )
    eight_km_dataset.to_netcdf(paths["grassland_8km_nc"])

    with paths["grassland_8km_csv"].open(
        "w",
        newline="",
        encoding="utf-8",
    ) as handle:
        fieldnames = [
            "latitude",
            "longitude",
            "permanent_grassland_fraction_percent",
            "grassland_source_pixel_count",
            "total_source_pixel_count",
            "analysis_gateway",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row_index, latitude_value in enumerate(latitude):
            for column_index, longitude_value in enumerate(longitude):
                if not gateway[row_index, column_index]:
                    continue
                fraction_value = fraction_8km[row_index, column_index]
                writer.writerow(
                    {
                        "latitude": f"{latitude_value:.10g}",
                        "longitude": f"{longitude_value:.10g}",
                        "permanent_grassland_fraction_percent": (
                            "" if not np.isfinite(fraction_value) else f"{fraction_value:.10g}"
                        ),
                        "grassland_source_pixel_count": int(
                            presence_8km[row_index, column_index]
                        ),
                        "total_source_pixel_count": int(
                            total_8km[row_index, column_index]
                        ),
                        "analysis_gateway": 1,
                    }
                )


def distribution_summary(
    figure_name: str,
    map_kind: str,
    metric: str,
    values_map: np.ndarray,
    levels: np.ndarray,
) -> dict[str, object]:
    values = values_map[np.isfinite(values_map)]
    if values.size == 0:
        raise ValueError(f"{figure_name}/{metric}: no finite values to summarize")
    return {
        "figure": figure_name,
        "map_kind": map_kind,
        "metric": metric,
        "n_cells": int(values.size),
        "minimum": float(np.min(values)),
        "q25": float(np.quantile(values, 0.25)),
        "median": float(np.median(values)),
        "mean": float(np.mean(values)),
        "q75": float(np.quantile(values, 0.75)),
        "maximum": float(np.max(values)),
        "display_minimum": float(levels[0]),
        "display_maximum": float(levels[-1]),
        "fraction_below_display_range": float(np.mean(values < levels[0])),
        "fraction_above_display_range": float(np.mean(values > levels[-1])),
    }


def write_summary(
    path: Path,
    absolute_maps: dict[str, np.ndarray],
    difference_maps: dict[str, np.ndarray],
    grassland_fraction_8km: np.ndarray,
    gateway: np.ndarray,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = [
        distribution_summary(
            "S2",
            "Permanent-grassland fraction on analytical cells",
            "GrasslandFraction",
            np.where(gateway, grassland_fraction_8km, np.nan),
            np.asarray(ABSOLUTE_SPECS["GrasslandFraction"]["levels"]),
        )
    ]
    for metric in METRIC_ORDER:
        rows.append(
            distribution_summary(
                "S1",
                "Variable absolute value",
                metric,
                absolute_maps[metric],
                np.asarray(ABSOLUTE_SPECS[metric]["levels"]),
            )
        )
        rows.append(
            distribution_summary(
                "S2",
                "Variable minus Fixed",
                metric,
                difference_maps[metric],
                np.asarray(DIFFERENCE_SPECS[metric]["levels"]),
            )
        )
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


def write_methods(
    path: Path,
    data_dir: Path,
    output_dir: Path,
    layout: str,
    map_engine: str,
    gateway_count: int,
    valid_counts: dict[str, int],
    metadata: list[dict[str, str]],
    grassland_metadata: dict[str, str],
    grassland_gateway_summary: dict[str, float | int],
) -> None:
    lines = [
        "Supplementary Figures S1 and S2 spatial maps",
        "",
        f"Script version: {SCRIPT_VERSION}",
        f"Data directory: {data_dir}",
        f"Output directory: {output_dir}",
        "Period: ordered annual records 0:60 (1960-2019)",
        "Raw NPP: multiplied once by 365 to g C m-2 yr-1",
        "Residual SD: read from residual files; no additional x365 conversion",
        f"Residual SD ddof: {RESIDUAL_STD_DDOF}",
        "Constancy: annual mean NPP / residual SD",
        "Resistance: precomputed log10 resistance read directly; no second log",
        "Resistance period: confirmed as 1960-2019 by command-line flag",
        "Legacy resistance alignment: confirmed latitude flip",
        "Gateway: recalculated Fixed constancy > 0",
        f"Gateway cells: {gateway_count}",
        f"Metric-specific valid counts: {valid_counts}",
        "S1a-c: Variable-trait absolute maps",
        "S2a: permanent-grassland fraction on the ORCHIDEE grid",
        "S2b-d: paired within-cell differences, Variable - Fixed",
        "No zero resistance values were discarded",
        "RPG rule: finite Band1 > 0 = permanent grassland",
        "RPG zero, negative and non-finite pixels were classified as absence",
        "Grassland fraction denominator: all fine-grid pixels represented in a cell",
        "Grassland display mask: 1-km Lambert-93 aggregation",
        "Coordinate transform: explicit Lambert-93 inverse PROJ pipeline; no EPSG database lookup",
        (
            "Corsica lookup: true-position RPG cells were associated with the "
            f"ORCHIDEE component stored {CORSICA_PACKED_SHIFT_CELLS} longitude "
            "columns farther east; plotted longitude/latitude were not shifted"
        ),
        "Grassland fraction panel: fraction aggregated to the ORCHIDEE grid",
        "No grassland-fraction threshold was applied to the analytical sample",
        "The RPG layer changes map rendering only; simulated values and analyses remain at the original ORCHIDEE resolution",
        f"Grassland summary on analytical cells: {grassland_gateway_summary}",
        f"Layout: {layout}",
        f"Rendered map engine: {map_engine}",
        f"Ocean background: {OCEAN_COLOR} (GeoAxes face colour; no ocean dataset required)",
        f"Unmapped land background: {LAND_COLOR}",
        f"PNG resolution: {PNG_DPI} dpi",
        "PDF: vector text and map cell artwork rasterized only within the PDF",
        "Input files were opened read-only",
        "",
        "Grassland-mask metadata",
        str(grassland_metadata),
        "",
        "Input metadata",
    ]
    lines.extend(str(item) for item in metadata)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_self_test() -> None:
    latitude = np.linspace(41.0, 51.5, 24)
    longitude = np.linspace(-5.5, 10.0, 32)
    lon_grid, lat_grid = np.meshgrid(longitude, latitude)
    gateway = ((lon_grid - 2.0) / 7.0) ** 2 + ((lat_grid - 46.0) / 5.0) ** 2 < 1
    absolute_maps = {
        "GrasslandFraction": np.where(
            gateway,
            55 + 35 * np.sin(lon_grid / 3) ** 2,
            np.nan,
        ),
        "NPP": np.where(gateway, 650 + 90 * np.sin(lon_grid / 2), np.nan),
        "Constancy": np.where(gateway, 18 + 3 * np.cos(lat_grid), np.nan),
        "Resistance": np.where(gateway, -0.55 + 0.05 * np.sin(lat_grid), np.nan),
    }
    difference_maps = {
        "GrasslandFraction": absolute_maps["GrasslandFraction"],
        "NPP": np.where(gateway, 25 * np.sin(lon_grid), np.nan),
        "Constancy": np.where(gateway, 0.5 * np.cos(lat_grid), np.nan),
        "Resistance": np.where(gateway, 0.02 * np.sin(lon_grid + lat_grid), np.nan),
    }

    sentinel_test = clean_values(np.array([1.0, np.nan, -1.0e34]))
    if not (sentinel_test[0] == 1.0 and np.isnan(sentinel_test[1:]).all()):
        raise AssertionError("Missing-value cleaning test failed")

    raw = np.arange(12, dtype=float).reshape(3, 4)
    flipped = align_to_reference(
        raw,
        None,
        None,
        raw.shape,
        np.arange(3, dtype=float),
        np.arange(4, dtype=float),
        "synthetic legacy map",
        allow_confirmed_latitude_fallback=True,
    )
    if not np.array_equal(flipped, raw[::-1, :]):
        raise AssertionError("Confirmed latitude-flip test failed")

    test_values = np.array([0.0, 1.0, 2.0])
    ascending_indices = coordinate_cell_indices(
        test_values,
        np.array([0.0, 1.0, 2.0]),
    )
    descending_indices = coordinate_cell_indices(
        test_values,
        np.array([2.0, 1.0, 0.0]),
    )
    if not np.array_equal(ascending_indices, np.array([0, 1, 2])):
        raise AssertionError("Ascending coordinate-index test failed")
    if not np.array_equal(descending_indices, np.array([2, 1, 0])):
        raise AssertionError("Descending coordinate-index test failed")

    test_longitude = np.array([[8.8, 2.0, 9.7]])
    test_latitude = np.array([[42.0, 46.0, 42.0]])
    test_x_index = np.array([[100, 60, 141]], dtype=np.int32)
    test_y_index = np.array([[10, 20, 10]], dtype=np.int32)
    remapped_x, remapped_mask, outside_mask = (
        remap_true_corsica_to_packed_orchidee(
            test_longitude,
            test_latitude,
            test_x_index,
            test_y_index,
            target_longitude_size=143,
        )
    )
    if remapped_x[0, 0] != 109 or not remapped_mask[0, 0]:
        raise AssertionError("Corsica packed-column remapping test failed")
    if remapped_x[0, 1] != 60 or remapped_mask[0, 1]:
        raise AssertionError("Mainland index changed during Corsica remapping")
    if remapped_x[0, 2] != -1 or not outside_mask[0, 2]:
        raise AssertionError("Corsica packed-grid boundary test failed")

    with tempfile.TemporaryDirectory() as temporary_directory:
        temporary = Path(temporary_directory)
        for prefix, values, specifications, cmap, layout, panel_order in (
            (
                "s1",
                absolute_maps,
                ABSOLUTE_SPECS,
                "turbo",
                "two-row",
                S1_PANEL_ORDER,
            ),
            (
                "s2",
                difference_maps,
                SPATIAL_DIFFERENCE_SPECS,
                "RdBu_r",
                "two-row",
                S2_PANEL_ORDER,
            ),
        ):
            png = temporary / f"{prefix}.png"
            pdf = temporary / f"{prefix}.pdf"
            save_map_figure(
                values,
                latitude,
                longitude,
                specifications,
                cmap,
                layout,
                "plain",
                png,
                pdf,
                panel_order,
                png_dpi=100,
            )
            if not (png.is_file() and png.stat().st_size > 0):
                raise AssertionError(f"{prefix} PNG test failed")
            if not (pdf.is_file() and pdf.stat().st_size > 0):
                raise AssertionError(f"{prefix} PDF test failed")
    print(
        "Self-test passed: missing values, latitude flip, coordinate indexing, "
        "Corsica packed-grid lookup, S1 and S2 rendering"
    )


def main() -> None:
    arguments = parse_arguments()
    if arguments.self_test:
        run_self_test()
        return

    data_dir = arguments.data_dir.resolve()
    output_dir = (
        arguments.output_dir.resolve()
        if arguments.output_dir is not None
        else data_dir / DEFAULT_OUTPUT_SUBDIR
    )
    grassland_mask_path = (
        arguments.grassland_mask.resolve()
        if arguments.grassland_mask is not None
        else data_dir / DEFAULT_GRASSLAND_MASK_FILE
    )
    # Fail fast before reading the multi-gigabyte RPG raster.
    lambert93_to_lonlat_transformer()
    paths = output_paths(output_dir)
    protect_existing_outputs(paths, arguments.overwrite)
    output_dir.mkdir(parents=True, exist_ok=True)

    maps, latitude, longitude, metadata = calculate_metric_maps(
        data_dir,
        arguments.confirm_resistance_period,
    )
    absolute_maps, difference_maps, gateway, valid_counts = prepare_display_maps(
        maps,
        arguments.expected_cells,
    )

    print("\nAggregating the fine-resolution RPG permanent-grassland mask")
    print(f"  Source: {grassland_mask_path}")
    print(
        "  The file is processed by row blocks and is never loaded fully "
        "into memory."
    )
    grassland = aggregate_grassland_mask(
        grassland_mask_path,
        arguments.grassland_variable,
        arguments.grassland_display_resolution_m,
    )
    grassland_source_summary = {
        key: grassland["metadata"][key]
        for key in (
            "source_positive_pixel_count",
            "source_zero_pixel_count",
            "source_negative_pixel_count",
            "source_nonfinite_pixel_count",
            "source_declared_fill_pixel_count",
        )
    }
    print(f"  Source-value diagnostic: {grassland_source_summary}")
    aligned_grassland = align_grassland_to_orchidee(
        grassland,
        latitude,
        longitude,
    )
    corsica_positive_1km_cells = int(
        aligned_grassland["corsica_positive_1km_cells"]
    )
    if corsica_positive_1km_cells == 0:
        raise ValueError(
            "No positive permanent-grassland 1-km cell was found over Corsica "
            "after transforming PP10m.nc. Stop before rendering."
        )
    print(
        "  Corsica mapping diagnostic: "
        f"{corsica_positive_1km_cells} positive 1-km RPG cells; "
        f"{int(aligned_grassland['corsica_remapped_1km_cells'])} total 1-km "
        f"cells associated with the packed ORCHIDEE component (+"
        f"{CORSICA_PACKED_SHIFT_CELLS} columns)."
    )
    grassland_fraction_8km = aligned_grassland["fraction_8km_percent"]
    gateway_fraction_values = grassland_fraction_8km[
        gateway & np.isfinite(grassland_fraction_8km)
    ]
    if gateway_fraction_values.size == 0:
        raise ValueError(
            "The RPG mask produced no grassland-fraction values on analytical cells"
        )
    grassland_gateway_summary: dict[str, float | int] = {
        "n_gateway_cells": int(np.count_nonzero(gateway)),
        "n_with_fraction": int(gateway_fraction_values.size),
        "n_with_positive_fraction": int(np.count_nonzero(gateway_fraction_values > 0)),
        "minimum_percent": float(np.min(gateway_fraction_values)),
        "median_percent": float(np.median(gateway_fraction_values)),
        "mean_percent": float(np.mean(gateway_fraction_values)),
        "maximum_percent": float(np.max(gateway_fraction_values)),
        "fraction_of_cells_at_least_99_percent": float(
            np.mean(gateway_fraction_values >= 99.0)
        ),
        "corsica_positive_1km_cells": corsica_positive_1km_cells,
        "corsica_remapped_1km_cells": int(
            aligned_grassland["corsica_remapped_1km_cells"]
        ),
        "corsica_outside_packed_grid_1km_cells": int(
            aligned_grassland["corsica_outside_packed_grid_1km_cells"]
        ),
    }
    if (
        grassland_gateway_summary["median_percent"] >= 99.0
        or grassland_gateway_summary["fraction_of_cells_at_least_99_percent"]
        >= 0.90
    ):
        raise ValueError(
            "The derived permanent-grassland fractions remain implausibly "
            "concentrated near 100%. No figure was rendered. Inspect the "
            f"Band1 value diagnostic: {grassland_source_summary}"
        )
    s1_display_maps, s2_display_maps = prepare_grassland_masked_figures(
        absolute_maps,
        difference_maps,
        gateway,
        grassland,
        aligned_grassland,
    )
    display_latitude = aligned_grassland["latitude_1km"]
    display_longitude = aligned_grassland["longitude_1km"]

    write_grassland_outputs(
        paths,
        grassland,
        aligned_grassland,
        latitude,
        longitude,
        gateway,
    )

    s1_engine = save_map_figure(
        s1_display_maps,
        display_latitude,
        display_longitude,
        ABSOLUTE_SPECS,
        arguments.absolute_cmap,
        arguments.layout,
        arguments.map_engine,
        paths["s1_png"],
        paths["s1_pdf"],
        S1_PANEL_ORDER,
    )
    s2_engine = save_map_figure(
        s2_display_maps,
        display_latitude,
        display_longitude,
        SPATIAL_DIFFERENCE_SPECS,
        arguments.difference_cmap,
        arguments.layout,
        arguments.map_engine,
        paths["s2_png"],
        paths["s2_pdf"],
        S2_PANEL_ORDER,
    )
    rendered_engine = s1_engine if s1_engine == s2_engine else f"S1={s1_engine}; S2={s2_engine}"
    summary_rows = write_summary(
        paths["summary"],
        absolute_maps,
        difference_maps,
        grassland_fraction_8km,
        gateway,
    )
    write_methods(
        paths["methods"],
        data_dir,
        output_dir,
        arguments.layout,
        rendered_engine,
        int(np.count_nonzero(gateway)),
        valid_counts,
        metadata,
        dict(grassland["metadata"]),
        grassland_gateway_summary,
    )

    print("\nSupplementary spatial figures completed")
    print("=" * 72)
    print(f"Gateway cells: {int(np.count_nonzero(gateway))}")
    print(f"Grassland fraction on gateway cells: {grassland_gateway_summary}")
    print(f"Map engine: {rendered_engine}")
    for row in summary_rows:
        print(
            f"{row['figure']} {row['metric']}: n={row['n_cells']}, "
            f"min={row['minimum']:.6g}, mean={row['mean']:.6g}, "
            f"max={row['maximum']:.6g}"
        )
    print("\nNew outputs; input NetCDF files were not modified:")
    for path in paths.values():
        print(f"  {path}")


if __name__ == "__main__":
    main()
