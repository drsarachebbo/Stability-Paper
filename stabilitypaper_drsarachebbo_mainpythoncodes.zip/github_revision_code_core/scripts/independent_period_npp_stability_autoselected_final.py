#!/usr/bin/env python3
"""Independent-period sensitivity analysis for NPP and stability.

This script addresses the reviewer's concern that the original spatial
NPP--stability relationships used productivity and stability metrics calculated
from the same 1960--2019 time series.

Primary analysis
----------------
* Baseline productivity: mean annual NPP over 1960--1989.
* Subsequent stability: constancy and M1 resistance over 1990--2019.
* The two periods do not share any year.

The calculations reproduce the definitions used in the manuscript:

    constancy = mean(NPP) / SD(quadratically detrended NPP residuals)

    A[t] = (NPP[t] - mean(NPP)) / SD(detrended residuals)

    log10 resistance = log10(abs(1 / min(A)))

NPP is converted from the supplied ORCHIDEE daily mean rate to annual units by
multiplying by 365 before detrending. The same conversion is consequently
present in both the numerator and denominator of the dimensionless stability
metrics.

The script also:
* aligns legacy maps to the raw cube by coordinate, including the confirmed
  latitude reversal, and applies the Ferret constancy > 0 gateway mask;
* explicitly converts Ferret -1.E+34 sentinels to missing values;
* checks the reconstructed 1960--2019 maps against the legacy NetCDF maps and
  stops before inference if this validation fails;
* compares old concurrent correlations with the new non-overlapping-period
  correlations;
* reports Pearson r, Spearman rho, linear slopes and spatial block-bootstrap
  95% intervals;
* repeats all-grassland spatial intervals with 120-, 160- and 200-km blocks;
* repeats both the original and independent-period NPP relationships within
  productivity quartiles, including repeated samples of up to 1,000 pixels;
* calculates queen-neighbour Moran's I and distance correlograms for fitted
  model residuals;
* selects response forms for both concurrent and independent-period
  relationships using AICc and five-fold spatially blocked cross-validation;
* produces publication figures at 600 dpi and vector PDFs.

Run
---
Edit only the paths/settings below if necessary, then run:

    python3 independent_period_npp_stability_autoselected_final.py

Input NetCDF files are read only. Existing output files with the same names in
OUTPUT_DIR are replaced.
"""

from __future__ import annotations

import csv
import gc
import math
import os
import struct
import warnings
import zlib
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

try:
    import netCDF4 as nc
except ModuleNotFoundError:  # Allows numerical self-tests without NetCDF I/O.
    nc = None


# =============================================================================
# User settings
# =============================================================================

DATA_DIR = Path("/ccc/work/cont003/gen6328/chebbosa")
OUTPUT_DIR = DATA_DIR / "independent_period_analysis_autoselected_final"
SCRIPT_VERSION = "2026-10-05-aligned-ferret-mask-autoselected-v3"

# Annual gridded NPP source: 60 ordered records, 1960 through 2019.
RAW_NPP_FILE = DATA_DIR / "varllvarnol_2D.nc"
RAW_NPP_VARIABLE = "NPP"

# Legacy maps used by the current Figure 2. They are used only for masks,
# validation and comparison with the old concurrent relationships.
ALL_NPP_FILE = DATA_DIR / "npp_simnol_all.nc"
ALL_CONSTANCY_FILE = DATA_DIR / "stab_simnol_all.nc"
TYPE_NPP_CONSTANCY_FILE = DATA_DIR / "stab_simnol_types.nc"
RESISTANCE_FILE = DATA_DIR / "logresistance_all.nc"

TIME_DIMENSION = "time_counter"
LATITUDE_DIMENSION = "latitude"
LONGITUDE_DIMENSION = "longitude"

FIRST_YEAR = 1960
LAST_YEAR = 2019
BASELINE_START = 1960
BASELINE_END = 1989
EVALUATION_START = 1990
EVALUATION_END = 2019

# User-confirmed conversion of the model NPP rate to annual NPP.
NPP_TO_ANNUAL = 365.0

# Ferret missing-data sentinel.  It is filtered explicitly because a literal
# -1.E+34 remains finite in NumPy when the NetCDF variable does not declare it
# as _FillValue or missing_value.
MISSING_ABS_THRESHOLD = 1.0e30

# The full-period calculation must reproduce the legacy maps before any
# independent-period result is accepted.  These tolerances accommodate small
# Ferret/NumPy numerical differences while rejecting a mask/alignment error.
VALIDATION_MIN_PEARSON = 0.995
VALIDATION_MAX_MEDIAN_RELATIVE_DIFFERENCE = 0.02
# Fallback established by diagnose_ferret_mask_reproduction.py. Coordinate
# matching takes precedence whenever one-dimensional coordinates are readable.
CONFIRMED_LEGACY_LATITUDE_FLIP = True

# The historical residuals were calculated after a quadratic temporal fit.
DETREND_DEGREE = 2

# Ferret @STD convention will be checked against the legacy constancy map.
# Set to 0 or 1 to force a value; None selects whichever most closely
# reproduces the existing 1960--2019 constancy map.
FORCE_STD_DDOF: int | None = None

# Conservative block size after inspecting the residual correlograms:
# 15 grid cells x 8 km = about 120 km per side.
SPATIAL_BLOCK_CELLS = 15
# Automatically verify the all-grassland conclusions at 120, 160 and 200 km.
# The primary reported interval remains the 120-km result above.
BLOCK_SENSITIVITY_CELLS = (15, 20, 25)
N_SPATIAL_FOLDS = 5
# 1,000 replicates provide percentile intervals at a reasonable run time.
# Increase to 2,000 for the final archived analysis if desired.
N_BOOTSTRAP = 1000
RANDOM_SEED = 20260910

# Reviewer-requested within-productivity-range sensitivity analysis.
N_QUARTILE_SUBSAMPLES = 1000
QUARTILE_SAMPLE_SIZE = 1000
QUARTILE_MIN_SAMPLE_SIZE = 500
MIN_QUARTILE_PAIRED_PIXELS = 20

# Residual spatial diagnostics. Distances are expressed in grid cells and
# converted to approximate kilometres using the 8-km SAFRAN grid. Twenty
# lags examine residual dependence out to approximately 160 km.
MAX_CORRELOGRAM_LAG_CELLS = 20
GRID_CELL_SIZE_KM = 8.0

# Nonlinear fits are retained only if they improve blocked-CV RMSE by at least
# 5% and also have a lower AICc than the linear fit.
MIN_CV_IMPROVEMENT = 0.05
BREAKPOINT_MIN_QUANTILE = 0.10
BREAKPOINT_MAX_QUANTILE = 0.90
N_BREAKPOINT_CANDIDATES = 181

PNG_DPI = 600

# =============================================================================
# Analysis definitions
# =============================================================================


@dataclass(frozen=True)
class Habitat:
    key: str
    title: str
    color: str
    legacy_npp_variable: str
    legacy_constancy_variable: str
    legacy_resistance_variable: str
    npp_file: Path
    constancy_file: Path


HABITATS = (
    Habitat(
        key="All",
        title="All grasslands",
        color="#6B6B6B",
        legacy_npp_variable="NPP_VARLLVARNOL",
        legacy_constancy_variable="CONSTANCY_VARLLVARNOL",
        legacy_resistance_variable="RESISTANCE_VARLLVAR",
        npp_file=ALL_NPP_FILE,
        constancy_file=ALL_CONSTANCY_FILE,
    ),
    Habitat(
        key="Calcareous",
        title="Calcareous",
        color="#8E44AD",
        legacy_npp_variable="NPP_CALC_VARLLVAR",
        legacy_constancy_variable="CONS_CALC_VARLLVAR",
        legacy_resistance_variable="RESISTANCE_CALC_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Mesic",
        title="Mesic",
        color="#1F3A93",
        legacy_npp_variable="NPP_MESO_VARLLVAR",
        legacy_constancy_variable="CONS_MESO_VARLLVAR",
        legacy_resistance_variable="RESISTANCE_MESO_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Mountain",
        title="Mountain",
        color="#196F3D",
        legacy_npp_variable="NPP_MOUN_VARLLVAR",
        legacy_constancy_variable="CONS_MOUN_VARLLVAR",
        legacy_resistance_variable="RESISTANCE_MOUN_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
    Habitat(
        key="Ruderal",
        title="Ruderal",
        color="#F39C12",
        legacy_npp_variable="NPP_RUD_VARLLVAR",
        legacy_constancy_variable="CONS_RUD_VARLLVAR",
        legacy_resistance_variable="RESISTANCE_RUD_VARLLVAR",
        npp_file=TYPE_NPP_CONSTANCY_FILE,
        constancy_file=TYPE_NPP_CONSTANCY_FILE,
    ),
)


@dataclass(frozen=True)
class Relationship:
    key: str
    predictor: str
    response: str
    xlabel: str
    ylabel: str


# Same three relationship types as the current Figure 2, but baseline NPP and
# subsequent stability now come from non-overlapping periods.
MAIN_RELATIONSHIPS = (
    Relationship(
        key="Baseline_NPP_vs_Subsequent_Constancy",
        predictor="Baseline_NPP",
        response="Subsequent_Constancy",
        xlabel=r"Baseline NPP, 1960–1989 (g C m$^{-2}$ yr$^{-1}$)",
        ylabel="Subsequent constancy\n(1990–2019)",
    ),
    Relationship(
        key="Baseline_NPP_vs_Subsequent_Resistance",
        predictor="Baseline_NPP",
        response="Subsequent_Resistance",
        xlabel=r"Baseline NPP, 1960–1989 (g C m$^{-2}$ yr$^{-1}$)",
        ylabel="Subsequent resistance\n" + r"(1990–2019; $\log_{10}$)",
    ),
    Relationship(
        key="Subsequent_Constancy_vs_Subsequent_Resistance",
        predictor="Subsequent_Constancy",
        response="Subsequent_Resistance",
        xlabel="Subsequent constancy (1990–2019)",
        ylabel="Subsequent resistance\n" + r"(1990–2019; $\log_{10}$)",
    ),
)

LEGACY_RELATIONSHIPS = (
    Relationship(
        key="NPP_vs_Constancy",
        predictor="NPP",
        response="Constancy",
        xlabel=r"NPP, 1960–2019 (g C m$^{-2}$ yr$^{-1}$)",
        ylabel="Constancy (1960–2019)",
    ),
    Relationship(
        key="NPP_vs_Resistance",
        predictor="NPP",
        response="Resistance",
        xlabel=r"NPP, 1960–2019 (g C m$^{-2}$ yr$^{-1}$)",
        ylabel=r"Resistance (1960–2019; $\log_{10}$)",
    ),
    Relationship(
        key="Constancy_vs_Resistance",
        predictor="Constancy",
        response="Resistance",
        xlabel="Constancy (1960–2019)",
        ylabel=r"Resistance (1960–2019; $\log_{10}$)",
    ),
)

# Direct variability check: unlike constancy, residual SD does not contain
# mean NPP in its numerator.
VARIABILITY_RELATIONSHIP = Relationship(
    key="Baseline_NPP_vs_Subsequent_Detrended_SD",
    predictor="Baseline_NPP",
    response="Subsequent_Detrended_SD",
    xlabel=r"Baseline NPP, 1960–1989 (g C m$^{-2}$ yr$^{-1}$)",
    ylabel="Detrended NPP SD, 1990–2019\n"
    + r"(g C m$^{-2}$ yr$^{-1}$)",
)

LINESTYLES = {"Linear": "-", "Quadratic": "--", "Segmented": ":"}


@dataclass
class MetricMaps:
    mean_npp: np.ndarray
    residual_sd: np.ndarray
    constancy: np.ndarray
    log10_resistance: np.ndarray


# =============================================================================
# NetCDF loading and validation
# =============================================================================


def require_files() -> None:
    required = {
        RAW_NPP_FILE,
        ALL_NPP_FILE,
        ALL_CONSTANCY_FILE,
        TYPE_NPP_CONSTANCY_FILE,
        RESISTANCE_FILE,
    }
    missing = sorted(path for path in required if not path.is_file())
    if missing:
        formatted = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(f"Required input files not found:\n{formatted}")


def read_masked_variable(path: Path, variable_name: str) -> tuple[np.ndarray, tuple[str, ...]]:
    if nc is None:
        raise ModuleNotFoundError(
            "The netCDF4 package is required to read the input files. "
            "Load/install netCDF4 in the Python environment used on the cluster."
        )
    with nc.Dataset(path, mode="r") as dataset:
        if variable_name not in dataset.variables:
            available = ", ".join(dataset.variables.keys())
            raise KeyError(
                f"{path.name}: '{variable_name}' was not found. "
                f"Available variables: {available}"
            )
        variable = dataset.variables[variable_name]
        values = np.asarray(np.ma.filled(variable[:], np.nan), dtype=np.float64)
        dimensions = tuple(variable.dimensions)
    values[~np.isfinite(values)] = np.nan
    values[np.abs(values) >= MISSING_ABS_THRESHOLD] = np.nan
    return values, dimensions


def read_coordinate(path: Path, coordinate_name: str) -> np.ndarray | None:
    """Read a one-dimensional coordinate when it is available."""
    with nc.Dataset(path, mode="r") as dataset:
        if coordinate_name not in dataset.variables:
            return None
        values = np.asarray(
            np.ma.filled(dataset.variables[coordinate_name][:], np.nan),
            dtype=np.float64,
        ).squeeze()
    if values.ndim != 1:
        return None
    return values


def load_npp_cube() -> tuple[
    np.ndarray,
    dict[str, str],
    np.ndarray | None,
    np.ndarray | None,
]:
    values, dimensions = read_masked_variable(RAW_NPP_FILE, RAW_NPP_VARIABLE)

    required_dimensions = {
        TIME_DIMENSION,
        LATITUDE_DIMENSION,
        LONGITUDE_DIMENSION,
    }
    if set(dimensions) != required_dimensions:
        raise ValueError(
            f"{RAW_NPP_FILE.name}/{RAW_NPP_VARIABLE}: expected exactly "
            f"{sorted(required_dimensions)}, found dimensions={dimensions}, "
            f"shape={values.shape}"
        )

    axes = [dimensions.index(name) for name in (
        TIME_DIMENSION,
        LATITUDE_DIMENSION,
        LONGITUDE_DIMENSION,
    )]
    values = np.transpose(values, axes)

    expected_years = LAST_YEAR - FIRST_YEAR + 1
    if values.shape[0] != expected_years:
        raise ValueError(
            f"Expected {expected_years} ordered annual records for "
            f"{FIRST_YEAR}--{LAST_YEAR}, found {values.shape[0]}"
        )

    with nc.Dataset(RAW_NPP_FILE, mode="r") as dataset:
        variable = dataset.variables[RAW_NPP_VARIABLE]
        metadata = {
            "source_units": str(getattr(variable, "units", "not specified")),
            "source_dimensions": str(tuple(variable.dimensions)),
            "source_shape": str(tuple(variable.shape)),
        }

    latitude = read_coordinate(RAW_NPP_FILE, LATITUDE_DIMENSION)
    longitude = read_coordinate(RAW_NPP_FILE, LONGITUDE_DIMENSION)
    return values * NPP_TO_ANNUAL, metadata, latitude, longitude


def load_2d_map(
    path: Path,
    variable_name: str,
    expected_shape: tuple[int, int],
    target_latitude: np.ndarray | None,
    target_longitude: np.ndarray | None,
) -> np.ndarray:
    """Load and align a legacy map to the raw NPP latitude/longitude order."""
    values, dimensions = read_masked_variable(path, variable_name)
    original_shape = values.shape
    remaining_dimensions = [
        name for name, size in zip(dimensions, original_shape) if size != 1
    ]
    values = np.squeeze(values)

    if (
        values.ndim == 2
        and LATITUDE_DIMENSION in remaining_dimensions
        and LONGITUDE_DIMENSION in remaining_dimensions
    ):
        axes = (
            remaining_dimensions.index(LATITUDE_DIMENSION),
            remaining_dimensions.index(LONGITUDE_DIMENSION),
        )
        values = np.transpose(values, axes)
    elif values.shape == expected_shape[::-1]:
        warnings.warn(
            f"{path.name}/{variable_name} has reversed spatial axes; transposing it."
        )
        values = values.T

    if values.shape != expected_shape:
        raise ValueError(
            f"{path.name}/{variable_name}: expected map shape {expected_shape}, "
            f"found {values.shape} after squeeze; original dimensions={dimensions}"
        )

    source_latitude = read_coordinate(path, LATITUDE_DIMENSION)
    source_longitude = read_coordinate(path, LONGITUDE_DIMENSION)

    if target_latitude is not None and source_latitude is not None:
        if source_latitude.shape != target_latitude.shape:
            raise ValueError(
                f"Latitude size mismatch for {path.name}/{variable_name}: "
                f"{source_latitude.shape} versus {target_latitude.shape}"
            )
        if np.allclose(source_latitude, target_latitude, equal_nan=False):
            pass
        elif np.allclose(source_latitude[::-1], target_latitude, equal_nan=False):
            values = values[::-1, :]
            source_latitude = source_latitude[::-1]
            warnings.warn(
                f"{path.name}/{variable_name}: latitude order was reversed "
                "to match the raw NPP cube."
            )
        else:
            raise ValueError(
                f"Latitude coordinates do not align for {path.name}/{variable_name}"
            )
        if not np.allclose(source_latitude, target_latitude, equal_nan=False):
            raise AssertionError("Latitude alignment failed")
    elif target_latitude is not None:
        # The dedicated diagnostic established this orientation for the files
        # used in the paper.  Keep the fallback explicit and visible.
        values = values[::-1, :]
        warnings.warn(
            f"{path.name}/{variable_name}: no readable latitude coordinate; "
            "applying the diagnostically confirmed latitude flip."
        )
    elif CONFIRMED_LEGACY_LATITUDE_FLIP:
        values = values[::-1, :]
        warnings.warn(
            f"{path.name}/{variable_name}: raw/legacy latitude coordinates "
            "were unavailable; applying the confirmed latitude flip."
        )

    if target_longitude is not None and source_longitude is not None:
        if source_longitude.shape != target_longitude.shape:
            raise ValueError(
                f"Longitude size mismatch for {path.name}/{variable_name}: "
                f"{source_longitude.shape} versus {target_longitude.shape}"
            )
        if np.allclose(source_longitude, target_longitude, equal_nan=False):
            pass
        elif np.allclose(source_longitude[::-1], target_longitude, equal_nan=False):
            values = values[:, ::-1]
            source_longitude = source_longitude[::-1]
            warnings.warn(
                f"{path.name}/{variable_name}: longitude order was reversed "
                "to match the raw NPP cube."
            )
        else:
            raise ValueError(
                f"Longitude coordinates do not align for {path.name}/{variable_name}"
            )
        if not np.allclose(source_longitude, target_longitude, equal_nan=False):
            raise AssertionError("Longitude alignment failed")

    return values


def load_legacy_maps(
    shape: tuple[int, int],
    target_latitude: np.ndarray | None,
    target_longitude: np.ndarray | None,
) -> dict[str, dict[str, np.ndarray]]:
    maps: dict[str, dict[str, np.ndarray]] = {}
    for habitat in HABITATS:
        maps[habitat.key] = {
            "NPP": load_2d_map(
                habitat.npp_file,
                habitat.legacy_npp_variable,
                shape,
                target_latitude,
                target_longitude,
            ),
            "Constancy": load_2d_map(
                habitat.constancy_file,
                habitat.legacy_constancy_variable,
                shape,
                target_latitude,
                target_longitude,
            ),
            # All resistance variables, including habitat-specific ones, are
            # deliberately read from the already log10-transformed file.
            "Resistance": load_2d_map(
                RESISTANCE_FILE,
                habitat.legacy_resistance_variable,
                shape,
                target_latitude,
                target_longitude,
            ),
        }
    return maps


def build_masks(
    annual_npp: np.ndarray,
    legacy_maps: dict[str, dict[str, np.ndarray]],
) -> tuple[dict[str, np.ndarray], list[dict]]:
    """Reproduce the Ferret gateway masks after coordinate alignment."""
    complete_npp = np.all(np.isfinite(annual_npp) & (annual_npp != 0), axis=0)
    masks: dict[str, np.ndarray] = {}
    diagnostics: list[dict] = []

    for habitat in HABITATS:
        legacy_npp = legacy_maps[habitat.key]["NPP"]
        legacy_constancy = legacy_maps[habitat.key]["Constancy"]
        # Exact Ferret gateway used to create NPP_VARLLVARNOL and the
        # habitat-specific NPP maps: retain cells whose corresponding
        # constancy is positive.
        ferret_mask = np.isfinite(legacy_constancy) & (legacy_constancy > 0)
        legacy_npp_mask = np.isfinite(legacy_npp) & (legacy_npp != 0)
        mask = complete_npp & ferret_mask
        if np.count_nonzero(mask) < 20:
            raise ValueError(
                f"{habitat.key}: only {np.count_nonzero(mask)} complete pixels "
                "remain after applying the Ferret constancy mask"
            )
        masks[habitat.key] = mask
        diagnostics.append({
            "habitat": habitat.key,
            "ferret_constancy_positive_pixels": int(np.count_nonzero(ferret_mask)),
            "legacy_npp_nonmissing_pixels": int(np.count_nonzero(legacy_npp_mask)),
            "complete_raw_npp_pixels": int(np.count_nonzero(complete_npp)),
            "final_common_pixels": int(np.count_nonzero(mask)),
            "ferret_pixels_excluded_for_incomplete_raw_npp": int(
                np.count_nonzero(ferret_mask & ~complete_npp)
            ),
            "mask_disagreement_constancy_vs_legacy_npp": int(
                np.count_nonzero(np.logical_xor(ferret_mask, legacy_npp_mask))
            ),
        })
        print(
            f"  {habitat.key}: Ferret mask={np.count_nonzero(ferret_mask)}, "
            f"complete/common={np.count_nonzero(mask)}",
            flush=True,
        )

    type_stack = np.stack([masks[h.key] for h in HABITATS if h.key != "All"])
    overlap = np.sum(type_stack, axis=0) > 1
    if np.any(overlap):
        warnings.warn(
            f"{np.count_nonzero(overlap)} cells occur in more than one habitat mask. "
            "They remain in each corresponding habitat analysis."
        )
    diagnostics.append({
        "habitat": "Overlap_among_four_habitat_masks",
        "ferret_constancy_positive_pixels": int(np.count_nonzero(overlap)),
        "legacy_npp_nonmissing_pixels": "",
        "complete_raw_npp_pixels": "",
        "final_common_pixels": int(np.count_nonzero(overlap)),
        "ferret_pixels_excluded_for_incomplete_raw_npp": "",
        "mask_disagreement_constancy_vs_legacy_npp": "",
    })
    return masks, diagnostics


# =============================================================================
# NPP stability metrics
# =============================================================================


def period_slice(start_year: int, end_year: int) -> slice:
    if not (FIRST_YEAR <= start_year <= end_year <= LAST_YEAR):
        raise ValueError(f"Invalid period {start_year}--{end_year}")
    return slice(start_year - FIRST_YEAR, end_year - FIRST_YEAR + 1)


def quadratic_residuals(values: np.ndarray) -> np.ndarray:
    """Return quadratic-fit residuals for values shaped (time, cells)."""
    if values.ndim != 2:
        raise ValueError(f"Expected (time, cells), found {values.shape}")
    n_time = values.shape[0]
    if n_time <= DETREND_DEGREE:
        raise ValueError("Too few years for quadratic detrending")
    if not np.isfinite(values).all():
        raise ValueError("quadratic_residuals requires complete finite series")

    # Centering/scaling time improves numerical conditioning but gives the same
    # fitted quadratic subspace as using 0, 1, ..., n_time-1 directly.
    time = np.arange(n_time, dtype=np.float64)
    time = (time - np.mean(time)) / np.std(time)
    design = np.column_stack([np.ones(n_time), time, time**2])
    coefficients, _, _, _ = np.linalg.lstsq(design, values, rcond=None)
    fitted = design @ coefficients
    return values - fitted


def calculate_metric_maps(
    annual_npp: np.ndarray,
    selected_period: slice,
    analysis_mask: np.ndarray,
    ddof: int,
) -> MetricMaps:
    shape = annual_npp.shape[1:]
    output = {
        "mean_npp": np.full(shape, np.nan, dtype=np.float64),
        "residual_sd": np.full(shape, np.nan, dtype=np.float64),
        "constancy": np.full(shape, np.nan, dtype=np.float64),
        "log10_resistance": np.full(shape, np.nan, dtype=np.float64),
    }

    period_values = annual_npp[selected_period][:, analysis_mask]
    residuals = quadratic_residuals(period_values)
    residual_sd = np.std(residuals, axis=0, ddof=ddof)
    mean_npp = np.mean(period_values, axis=0)

    valid_scale = np.isfinite(residual_sd) & (residual_sd > 0)
    constancy = np.full(mean_npp.shape, np.nan, dtype=np.float64)
    log10_resistance = np.full(mean_npp.shape, np.nan, dtype=np.float64)

    constancy[valid_scale] = mean_npp[valid_scale] / residual_sd[valid_scale]

    anomalies = np.full(period_values.shape, np.nan, dtype=np.float64)
    anomalies[:, valid_scale] = (
        period_values[:, valid_scale] - mean_npp[None, valid_scale]
    ) / residual_sd[None, valid_scale]
    minimum_anomaly = np.full(mean_npp.shape, np.nan, dtype=np.float64)
    minimum_anomaly[valid_scale] = np.min(anomalies[:, valid_scale], axis=0)
    valid_resistance = valid_scale & np.isfinite(minimum_anomaly) & (minimum_anomaly < 0)
    resistance = np.abs(1.0 / minimum_anomaly[valid_resistance])
    log10_resistance[valid_resistance] = np.log10(resistance)

    output["mean_npp"][analysis_mask] = mean_npp
    output["residual_sd"][analysis_mask] = residual_sd
    output["constancy"][analysis_mask] = constancy
    output["log10_resistance"][analysis_mask] = log10_resistance
    return MetricMaps(**output)


def comparison_statistics(calculated: np.ndarray, reference: np.ndarray) -> dict[str, float]:
    valid = (
        np.isfinite(calculated)
        & np.isfinite(reference)
        & (reference != 0)
    )
    if np.count_nonzero(valid) < 3:
        return {
            "n": float(np.count_nonzero(valid)),
            "pearson_r": np.nan,
            "median_absolute_difference": np.nan,
            "median_relative_absolute_difference": np.nan,
            "maximum_absolute_difference": np.nan,
        }
    calc = calculated[valid]
    ref = reference[valid]
    difference = calc - ref
    relative = np.abs(difference) / np.maximum(np.abs(ref), 1e-12)
    return {
        "n": int(calc.size),
        "pearson_r": float(np.corrcoef(calc, ref)[0, 1]),
        "median_absolute_difference": float(np.median(np.abs(difference))),
        "median_relative_absolute_difference": float(np.median(relative)),
        "maximum_absolute_difference": float(np.max(np.abs(difference))),
    }


def select_ddof_and_validate(
    annual_npp: np.ndarray,
    all_mask: np.ndarray,
    legacy_all: dict[str, np.ndarray],
) -> tuple[int, MetricMaps, list[dict]]:
    full_slice = period_slice(FIRST_YEAR, LAST_YEAR)
    candidates = (FORCE_STD_DDOF,) if FORCE_STD_DDOF is not None else (0, 1)
    calculated_by_ddof: dict[int, MetricMaps] = {}
    candidate_scores: dict[int, float] = {}

    for ddof in candidates:
        if ddof not in (0, 1):
            raise ValueError("FORCE_STD_DDOF must be None, 0 or 1")
        maps = calculate_metric_maps(annual_npp, full_slice, all_mask, ddof)
        calculated_by_ddof[ddof] = maps
        check = comparison_statistics(maps.constancy, legacy_all["Constancy"])
        candidate_scores[ddof] = check["median_relative_absolute_difference"]

    finite_scores = {
        key: value for key, value in candidate_scores.items() if np.isfinite(value)
    }
    if finite_scores:
        selected_ddof = min(finite_scores, key=finite_scores.get)
    else:
        selected_ddof = int(candidates[0])
    selected = calculated_by_ddof[selected_ddof]

    checks = []
    for metric_name, calculated, reference in (
        ("Mean_NPP", selected.mean_npp, legacy_all["NPP"]),
        ("Constancy", selected.constancy, legacy_all["Constancy"]),
        ("Log10_resistance_M1", selected.log10_resistance, legacy_all["Resistance"]),
    ):
        checks.append({
            "metric": metric_name,
            "selected_ddof": selected_ddof,
            **comparison_statistics(calculated, reference),
        })
    return selected_ddof, selected, checks


def enforce_full_period_validation(validation_rows: list[dict]) -> None:
    """Stop before inference if alignment/masking no longer reproduces Ferret."""
    failures = []
    for row in validation_rows:
        correlation = float(row["pearson_r"])
        relative_difference = float(row["median_relative_absolute_difference"])
        if (
            not np.isfinite(correlation)
            or correlation < VALIDATION_MIN_PEARSON
            or not np.isfinite(relative_difference)
            or relative_difference > VALIDATION_MAX_MEDIAN_RELATIVE_DIFFERENCE
        ):
            failures.append(
                f"{row['metric']}: r={correlation:.6f}, "
                f"median relative difference={relative_difference:.6g}"
            )
    if failures:
        details = "\n  - ".join(failures)
        raise RuntimeError(
            "Full-period validation failed. Independent-period results were "
            "not calculated. Inspect full_period_map_validation.csv.\n  - "
            + details
        )


# =============================================================================
# Relationship models and spatial uncertainty
# =============================================================================


def pearson_correlation(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 3 or np.ptp(x) == 0 or np.ptp(y) == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def average_ranks(values: np.ndarray) -> np.ndarray:
    """Return one-based average ranks, including tied values."""
    values = np.asarray(values, dtype=np.float64)
    order = np.argsort(values, kind="mergesort")
    sorted_values = values[order]
    sorted_ranks = np.empty(values.size, dtype=np.float64)
    start = 0
    while start < values.size:
        end = start + 1
        while end < values.size and sorted_values[end] == sorted_values[start]:
            end += 1
        sorted_ranks[start:end] = 0.5 * (start + 1 + end)
        start = end
    ranks = np.empty(values.size, dtype=np.float64)
    ranks[order] = sorted_ranks
    return ranks


def spearman_correlation(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 3:
        return np.nan
    return pearson_correlation(average_ranks(x), average_ranks(y))


def paired_arrays(
    x_map: np.ndarray,
    y_map: np.ndarray,
    habitat_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    valid = habitat_mask & np.isfinite(x_map) & np.isfinite(y_map)
    rows, columns = np.nonzero(valid)
    x = x_map[valid].astype(np.float64)
    y = y_map[valid].astype(np.float64)
    if x.size < 20:
        raise ValueError(f"Only {x.size} paired pixels were found")
    return x, y, rows, columns


def spatial_block_ids(
    rows: np.ndarray,
    columns: np.ndarray,
    n_columns: int,
    block_cells: int = SPATIAL_BLOCK_CELLS,
) -> np.ndarray:
    block_columns = math.ceil(n_columns / block_cells)
    return (
        (rows // block_cells) * block_columns
        + (columns // block_cells)
    ).astype(np.int64)


def residual_map_from_points(
    residuals: np.ndarray,
    rows: np.ndarray,
    columns: np.ndarray,
    grid_shape: tuple[int, int],
) -> np.ndarray:
    output = np.full(grid_shape, np.nan, dtype=np.float64)
    output[rows, columns] = residuals
    return output


def shifted_views(
    array: np.ndarray,
    row_shift: int,
    column_shift: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return overlapping views separated by one signed grid offset."""
    n_rows, n_columns = array.shape
    if row_shift < 0:
        raise ValueError("row_shift must be non-negative")
    if row_shift >= n_rows or abs(column_shift) >= n_columns:
        return np.empty(0), np.empty(0)

    row_a = slice(0, n_rows - row_shift)
    row_b = slice(row_shift, n_rows)
    if column_shift >= 0:
        column_a = slice(0, n_columns - column_shift)
        column_b = slice(column_shift, n_columns)
    else:
        column_a = slice(-column_shift, n_columns)
        column_b = slice(0, n_columns + column_shift)
    return array[row_a, column_a], array[row_b, column_b]


def queen_morans_i(residual_map: np.ndarray) -> tuple[float, float, int]:
    """Queen-contiguity Moran's I using all valid horizontal/diagonal pairs."""
    valid_values = residual_map[np.isfinite(residual_map)]
    n = valid_values.size
    if n < 3:
        return np.nan, np.nan, 0
    centered = residual_map - np.mean(valid_values)
    denominator = float(np.nansum(centered**2))
    if denominator <= 0:
        return np.nan, -1.0 / (n - 1), 0

    # One direction from each symmetric queen-neighbour pair. The factors of
    # two in the symmetric weights cancel in the final expression.
    pair_product_sum = 0.0
    n_pairs = 0
    for row_shift, column_shift in ((0, 1), (1, -1), (1, 0), (1, 1)):
        first, second = shifted_views(centered, row_shift, column_shift)
        valid = np.isfinite(first) & np.isfinite(second)
        pair_product_sum += float(np.sum(first[valid] * second[valid]))
        n_pairs += int(np.count_nonzero(valid))
    if n_pairs == 0:
        return np.nan, -1.0 / (n - 1), 0
    moran_i = (n / n_pairs) * pair_product_sum / denominator
    return float(moran_i), float(-1.0 / (n - 1)), n_pairs


def residual_distance_correlogram(
    residual_map: np.ndarray,
    maximum_lag: int = MAX_CORRELOGRAM_LAG_CELLS,
) -> list[dict[str, float]]:
    """Moran-like residual autocorrelation in integer grid-distance classes."""
    valid_values = residual_map[np.isfinite(residual_map)]
    if valid_values.size < 3:
        return []
    centered = residual_map - np.mean(valid_values)
    variance = float(np.mean(valid_values**2) - np.mean(valid_values) ** 2)
    if variance <= 0:
        return []

    product_sums = np.zeros(maximum_lag + 1, dtype=np.float64)
    pair_counts = np.zeros(maximum_lag + 1, dtype=np.int64)
    for row_shift in range(0, maximum_lag + 1):
        for column_shift in range(-maximum_lag, maximum_lag + 1):
            if row_shift == 0 and column_shift <= 0:
                continue
            distance = math.hypot(row_shift, column_shift)
            lag = int(math.floor(distance + 0.5))
            if lag < 1 or lag > maximum_lag:
                continue
            first, second = shifted_views(centered, row_shift, column_shift)
            valid = np.isfinite(first) & np.isfinite(second)
            product_sums[lag] += float(np.sum(first[valid] * second[valid]))
            pair_counts[lag] += int(np.count_nonzero(valid))

    output = []
    for lag in range(1, maximum_lag + 1):
        if pair_counts[lag] == 0:
            autocorrelation = np.nan
        else:
            autocorrelation = (
                product_sums[lag] / pair_counts[lag] / variance
            )
        output.append({
            "lag_grid_cells": lag,
            "distance_km_approx": lag * GRID_CELL_SIZE_KM,
            "residual_autocorrelation": float(autocorrelation),
            "n_pairs": int(pair_counts[lag]),
        })
    return output


def segmented_design(x: np.ndarray, breakpoint: float) -> np.ndarray:
    return np.column_stack([
        np.ones_like(x),
        x,
        np.maximum(0.0, x - breakpoint),
    ])


def fit_model(model_name: str, x: np.ndarray, y: np.ndarray) -> dict:
    if model_name == "Linear":
        coefficients = np.polyfit(x, y, deg=1)
        return {"model": model_name, "coefficients": coefficients, "n_parameters": 2}
    if model_name == "Quadratic":
        coefficients = np.polyfit(x, y, deg=2)
        return {"model": model_name, "coefficients": coefficients, "n_parameters": 3}
    if model_name != "Segmented":
        raise ValueError(f"Unknown model {model_name}")

    quantiles = np.linspace(
        BREAKPOINT_MIN_QUANTILE,
        BREAKPOINT_MAX_QUANTILE,
        N_BREAKPOINT_CANDIDATES,
    )
    candidates = np.unique(np.quantile(x, quantiles))
    best_sse = np.inf
    best_breakpoint = None
    best_coefficients = None
    for breakpoint in candidates:
        design = segmented_design(x, float(breakpoint))
        coefficients, _, _, _ = np.linalg.lstsq(design, y, rcond=None)
        residuals = y - design @ coefficients
        sse = float(np.sum(residuals**2))
        if sse < best_sse:
            best_sse = sse
            best_breakpoint = float(breakpoint)
            best_coefficients = coefficients
    if best_coefficients is None:
        raise RuntimeError("No segmented fit could be estimated")
    return {
        "model": model_name,
        "coefficients": best_coefficients,
        "breakpoint": best_breakpoint,
        # Intercept, first slope, slope change and estimated breakpoint.
        "n_parameters": 4,
    }


def predict(fit: dict, x: np.ndarray) -> np.ndarray:
    if fit["model"] in ("Linear", "Quadratic"):
        return np.polyval(fit["coefficients"], x)
    return segmented_design(x, fit["breakpoint"]) @ fit["coefficients"]


def aicc(fit: dict, x: np.ndarray, y: np.ndarray) -> float:
    n = x.size
    k = int(fit["n_parameters"])
    residuals = y - predict(fit, x)
    sse = max(float(np.sum(residuals**2)), np.finfo(float).tiny)
    value = n * np.log(sse / n) + 2 * k
    if n <= k + 1:
        return np.inf
    return float(value + (2 * k * (k + 1)) / (n - k - 1))


def blocked_fold_labels(block_ids: np.ndarray, n_folds: int, seed: int) -> np.ndarray:
    unique_blocks = np.unique(block_ids)
    if unique_blocks.size < n_folds:
        raise ValueError(
            f"Only {unique_blocks.size} spatial blocks for {n_folds} folds"
        )
    rng = np.random.default_rng(seed)
    shuffled = unique_blocks.copy()
    rng.shuffle(shuffled)
    block_to_fold = {block: index % n_folds for index, block in enumerate(shuffled)}
    return np.array([block_to_fold[block] for block in block_ids], dtype=int)


def blocked_cv_rmse(
    model_name: str,
    x: np.ndarray,
    y: np.ndarray,
    fold_labels: np.ndarray,
) -> float:
    squared_errors = []
    for fold in np.unique(fold_labels):
        test = fold_labels == fold
        train = ~test
        if np.count_nonzero(test) == 0 or np.count_nonzero(train) < 20:
            continue
        try:
            fit = fit_model(model_name, x[train], y[train])
            predictions = predict(fit, x[test])
        except (ValueError, np.linalg.LinAlgError):
            return np.inf
        squared_errors.append((y[test] - predictions) ** 2)
    if not squared_errors:
        return np.inf
    errors = np.concatenate(squared_errors)
    return float(np.sqrt(np.mean(errors)))


def select_relationship_model(
    x: np.ndarray,
    y: np.ndarray,
    block_ids: np.ndarray,
    seed: int,
) -> tuple[dict, dict[str, dict[str, float]]]:
    fold_labels = blocked_fold_labels(block_ids, N_SPATIAL_FOLDS, seed)
    diagnostics: dict[str, dict[str, float]] = {}
    fits: dict[str, dict] = {}
    for model_name in ("Linear", "Quadratic", "Segmented"):
        fit = fit_model(model_name, x, y)
        fits[model_name] = fit
        diagnostics[model_name] = {
            "AICc": aicc(fit, x, y),
            "blocked_CV_RMSE": blocked_cv_rmse(
                model_name,
                x,
                y,
                fold_labels,
            ),
        }

    linear = diagnostics["Linear"]
    eligible = []
    for model_name in ("Quadratic", "Segmented"):
        candidate = diagnostics[model_name]
        if (
            candidate["AICc"] < linear["AICc"]
            and candidate["blocked_CV_RMSE"]
            <= (1.0 - MIN_CV_IMPROVEMENT) * linear["blocked_CV_RMSE"]
        ):
            eligible.append(model_name)
    if eligible:
        selected_name = min(
            eligible,
            key=lambda name: (
                diagnostics[name]["blocked_CV_RMSE"],
                diagnostics[name]["AICc"],
            ),
        )
    else:
        selected_name = "Linear"
    return fits[selected_name], diagnostics


def spatial_block_bootstrap(
    x: np.ndarray,
    y: np.ndarray,
    block_ids: np.ndarray,
    seed: int,
) -> dict[str, float]:
    unique_blocks = np.unique(block_ids)
    indices_by_block = [np.flatnonzero(block_ids == block) for block in unique_blocks]
    if unique_blocks.size < 5:
        return {
            "n_spatial_blocks": int(unique_blocks.size),
            "pearson_ci_low": np.nan,
            "pearson_ci_high": np.nan,
            "spearman_ci_low": np.nan,
            "spearman_ci_high": np.nan,
            "slope_ci_low": np.nan,
            "slope_ci_high": np.nan,
            "successful_bootstraps": 0,
        }

    rng = np.random.default_rng(seed)
    pearson_values = []
    spearman_values = []
    slope_values = []
    for _ in range(N_BOOTSTRAP):
        selected = rng.integers(0, len(indices_by_block), size=len(indices_by_block))
        sample_indices = np.concatenate([indices_by_block[index] for index in selected])
        xb = x[sample_indices]
        yb = y[sample_indices]
        if np.ptp(xb) == 0 or np.ptp(yb) == 0:
            continue
        pearson_values.append(pearson_correlation(xb, yb))
        spearman_values.append(spearman_correlation(xb, yb))
        slope_values.append(float(np.polyfit(xb, yb, 1)[0]))

    def interval(values: list[float]) -> tuple[float, float]:
        if not values:
            return np.nan, np.nan
        return tuple(np.percentile(values, [2.5, 97.5]).astype(float))

    pearson_ci = interval(pearson_values)
    spearman_ci = interval(spearman_values)
    slope_ci = interval(slope_values)
    return {
        "n_spatial_blocks": int(unique_blocks.size),
        "pearson_ci_low": pearson_ci[0],
        "pearson_ci_high": pearson_ci[1],
        "spearman_ci_low": spearman_ci[0],
        "spearman_ci_high": spearman_ci[1],
        "slope_ci_low": slope_ci[0],
        "slope_ci_high": slope_ci[1],
        "successful_bootstraps": len(pearson_values),
    }


def relationship_statistics(
    relationship: Relationship,
    habitat: Habitat,
    x: np.ndarray,
    y: np.ndarray,
    rows: np.ndarray,
    columns: np.ndarray,
    grid_shape: tuple[int, int],
    seed_offset: int,
) -> tuple[dict, dict, dict[str, dict[str, float]]]:
    pearson = pearson_correlation(x, y)
    spearman = spearman_correlation(x, y)
    linear_coefficients = np.polyfit(x, y, deg=1)
    linear_fitted = np.polyval(linear_coefficients, x)
    linear_residuals = y - linear_fitted
    sst = float(np.sum((y - np.mean(y)) ** 2))
    sse = float(np.sum(linear_residuals**2))
    block_ids = spatial_block_ids(rows, columns, grid_shape[1])

    selected_fit, diagnostics = select_relationship_model(
        x,
        y,
        block_ids,
        RANDOM_SEED + seed_offset,
    )
    bootstrap = spatial_block_bootstrap(
        x,
        y,
        block_ids,
        RANDOM_SEED + 10000 + seed_offset,
    )

    selected_residuals = y - predict(selected_fit, x)
    residual_map = residual_map_from_points(
        selected_residuals,
        rows,
        columns,
        grid_shape,
    )
    moran_i, moran_expected, moran_pairs = queen_morans_i(residual_map)

    selected_diagnostic = diagnostics[selected_fit["model"]]
    stats = {
        "relationship": relationship.key,
        "habitat": habitat.key,
        "n": int(x.size),
        "Pearson_r": pearson,
        "Spearman_rho": spearman,
        "linear_slope": float(linear_coefficients[0]),
        "linear_intercept": float(linear_coefficients[1]),
        "linear_R_squared": float(1.0 - sse / sst) if sst > 0 else np.nan,
        "linear_RMSE": float(np.sqrt(np.mean(linear_residuals**2))),
        "selected_model": selected_fit["model"],
        "model_selection_mode": "AICc_plus_blocked_CV",
        "selected_AICc": selected_diagnostic["AICc"],
        "selected_blocked_CV_RMSE": selected_diagnostic["blocked_CV_RMSE"],
        "linear_AICc": diagnostics["Linear"]["AICc"],
        "linear_blocked_CV_RMSE": diagnostics["Linear"]["blocked_CV_RMSE"],
        "quadratic_AICc": diagnostics["Quadratic"]["AICc"],
        "quadratic_blocked_CV_RMSE": diagnostics["Quadratic"]["blocked_CV_RMSE"],
        "segmented_AICc": diagnostics["Segmented"]["AICc"],
        "segmented_blocked_CV_RMSE": diagnostics["Segmented"]["blocked_CV_RMSE"],
        "selected_breakpoint": selected_fit.get("breakpoint", np.nan),
        "selected_turning_point": (
            float(
                -selected_fit["coefficients"][1]
                / (2.0 * selected_fit["coefficients"][0])
            )
            if (
                selected_fit["model"] == "Quadratic"
                and not np.isclose(selected_fit["coefficients"][0], 0.0)
            )
            else np.nan
        ),
        "residual_queen_Morans_I": moran_i,
        "Moran_expected_under_randomness": moran_expected,
        "Moran_queen_neighbour_pairs": moran_pairs,
        **bootstrap,
    }
    return stats, selected_fit, diagnostics


def block_size_sensitivity(
    analysis_name: str,
    relationships: tuple[Relationship, ...],
    plot_data: dict[
        tuple[str, str],
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    ],
    grid_shape: tuple[int, int],
    seed_start: int,
) -> list[dict]:
    """Repeat all-grassland spatial intervals at 120, 160 and 200 km."""
    rows_out: list[dict] = []
    all_habitat = HABITATS[0]
    counter = 0
    for relationship in relationships:
        x, y, grid_rows, grid_columns = plot_data[
            (relationship.key, all_habitat.key)
        ]
        for block_cells in BLOCK_SENSITIVITY_CELLS:
            ids = spatial_block_ids(
                grid_rows,
                grid_columns,
                grid_shape[1],
                block_cells=block_cells,
            )
            uncertainty = spatial_block_bootstrap(
                x,
                y,
                ids,
                RANDOM_SEED + 50000 + seed_start + counter,
            )
            rows_out.append({
                "analysis": analysis_name,
                "relationship": relationship.key,
                "habitat": all_habitat.key,
                "n": int(x.size),
                "block_cells": int(block_cells),
                "block_side_km": float(block_cells * GRID_CELL_SIZE_KM),
                "Pearson_r": pearson_correlation(x, y),
                "Spearman_rho": spearman_correlation(x, y),
                "linear_slope": float(np.polyfit(x, y, 1)[0]),
                **uncertainty,
            })
            counter += 1
    return rows_out


# =============================================================================
# Output helpers
# =============================================================================


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def png_file_is_complete(path: Path) -> bool:
    """Validate PNG chunk lengths and CRCs without decoding the large image."""
    try:
        with path.open("rb") as handle:
            if handle.read(8) != b"\x89PNG\r\n\x1a\n":
                return False
            while True:
                length_bytes = handle.read(4)
                if len(length_bytes) != 4:
                    return False
                length = struct.unpack(">I", length_bytes)[0]
                chunk_type = handle.read(4)
                chunk_data = handle.read(length)
                crc_bytes = handle.read(4)
                if (
                    len(chunk_type) != 4
                    or len(chunk_data) != length
                    or len(crc_bytes) != 4
                ):
                    return False
                stored_crc = struct.unpack(">I", crc_bytes)[0]
                calculated_crc = zlib.crc32(chunk_type)
                calculated_crc = zlib.crc32(chunk_data, calculated_crc) & 0xFFFFFFFF
                if stored_crc != calculated_crc:
                    return False
                if chunk_type == b"IEND":
                    return True
    except OSError:
        return False


def save_publication_figure(
    figure: plt.Figure,
    png_path: Path,
    pdf_path: Path,
) -> None:
    """Save vector and 600-dpi versions, retrying an incomplete PNG write."""
    try:
        figure.savefig(pdf_path, bbox_inches="tight", facecolor="white")
        with pdf_path.open("rb") as handle:
            os.fsync(handle.fileno())
        for attempt in range(1, 4):
            figure.savefig(
                png_path,
                dpi=PNG_DPI,
                bbox_inches="tight",
                facecolor="white",
            )
            with png_path.open("rb") as handle:
                os.fsync(handle.fileno())
            if png_file_is_complete(png_path):
                break
            warnings.warn(
                f"Incomplete PNG write for {png_path.name}; retry {attempt}/3"
            )
            gc.collect()
        else:
            raise OSError(
                f"Could not create a complete PNG after three attempts: {png_path}"
            )
    finally:
        plt.close(figure)
        gc.collect()


def maps_for_new_analysis(
    baseline_mean: np.ndarray,
    evaluation: MetricMaps,
) -> dict[str, np.ndarray]:
    return {
        "Baseline_NPP": baseline_mean,
        "Subsequent_Constancy": evaluation.constancy,
        "Subsequent_Resistance": evaluation.log10_resistance,
        "Subsequent_Detrended_SD": evaluation.residual_sd,
    }


def prepare_relationship_results(
    relationships: tuple[Relationship, ...],
    maps: dict[str, np.ndarray],
    masks: dict[str, np.ndarray],
    grid_shape: tuple[int, int],
    seed_start: int,
) -> tuple[
    dict[tuple[str, str], tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]],
    dict[tuple[str, str], dict],
    list[dict],
]:
    plot_data = {}
    fits = {}
    rows = []
    counter = 0
    for relationship in relationships:
        for habitat in HABITATS:
            x, y, grid_rows, grid_columns = paired_arrays(
                maps[relationship.predictor],
                maps[relationship.response],
                masks[habitat.key],
            )
            stats, fit, _ = relationship_statistics(
                relationship,
                habitat,
                x,
                y,
                grid_rows,
                grid_columns,
                grid_shape,
                seed_start + counter,
            )
            plot_data[(relationship.key, habitat.key)] = (
                x,
                y,
                grid_rows,
                grid_columns,
            )
            fits[(relationship.key, habitat.key)] = fit
            rows.append(stats)
            counter += 1
    return plot_data, fits, rows


def set_plot_style() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 14,
        "axes.labelsize": 17,
        "axes.titlesize": 17,
        "xtick.labelsize": 13,
        "ytick.labelsize": 13,
        "axes.linewidth": 1.0,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })


def plot_relationship_grid(
    relationships: tuple[Relationship, ...],
    plot_data: dict[
        tuple[str, str],
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    ],
    fits: dict[tuple[str, str], dict],
    statistics_rows: list[dict],
    png_path: Path,
    pdf_path: Path,
) -> None:
    set_plot_style()
    n_rows = len(relationships)
    figure_height = 5.0 if n_rows == 1 else 3.35 * n_rows + 0.5
    figure, axes = plt.subplots(
        n_rows,
        len(HABITATS),
        figsize=(16.0, figure_height),
        sharex="row",
        sharey="row",
        squeeze=False,
    )
    figure.subplots_adjust(
        left=0.075,
        right=0.995,
        top=0.925 if n_rows > 1 else 0.87,
        bottom=0.17 if n_rows > 1 else 0.34,
        wspace=0.14,
        hspace=0.43,
    )

    stats_lookup = {
        (row["relationship"], row["habitat"]): row
        for row in statistics_rows
    }
    row_limits = {}
    for relationship in relationships:
        all_y = np.concatenate([
            plot_data[(relationship.key, habitat.key)][1]
            for habitat in HABITATS
        ])
        low = float(np.min(all_y))
        high = float(np.max(all_y))
        span = high - low
        row_limits[relationship.key] = (
            low - 0.03 * span,
            high + 0.18 * span,
        )

    panel_index = 0
    for row_index, relationship in enumerate(relationships):
        for column_index, habitat in enumerate(HABITATS):
            axis = axes[row_index, column_index]
            key = (relationship.key, habitat.key)
            x, y, _, _ = plot_data[key]
            fit = fits[key]
            row = stats_lookup[key]
            alpha = 0.28 if habitat.key == "All" else 0.62
            axis.scatter(
                x,
                y,
                s=8,
                alpha=alpha,
                color=habitat.color,
                edgecolors="none",
                rasterized=True,
            )
            x_grid = np.linspace(float(np.min(x)), float(np.max(x)), 500)
            axis.plot(
                x_grid,
                predict(fit, x_grid),
                color="#303030",
                linestyle=LINESTYLES[fit["model"]],
                linewidth=2.1,
                zorder=5,
            )
            axis.text(
                0.04,
                0.96,
                f"$r$ = {row['Pearson_r']:.2f}\n"
                f"$\\rho$ = {row['Spearman_rho']:.2f}",
                transform=axis.transAxes,
                ha="left",
                va="top",
                fontsize=12.5,
                bbox={
                    "facecolor": "white",
                    "alpha": 0.84,
                    "edgecolor": "none",
                    "pad": 1.0,
                },
                zorder=10,
            )
            axis.text(
                -0.04,
                1.02,
                chr(ord("a") + panel_index),
                transform=axis.transAxes,
                ha="left",
                va="bottom",
                fontsize=16,
                fontweight="bold",
            )
            panel_index += 1
            if row_index == 0:
                axis.set_title(
                    habitat.title,
                    color=habitat.color,
                    fontweight="bold",
                    pad=8,
                )
            if column_index == 0:
                axis.set_ylabel(relationship.ylabel)
            if column_index == 2:
                axis.set_xlabel(relationship.xlabel, labelpad=3)
            axis.set_ylim(*row_limits[relationship.key])
            axis.grid(False)

    model_order = [
        name
        for name in ("Linear", "Quadratic", "Segmented")
        if any(fit["model"] == name for fit in fits.values())
    ]
    handles = [
        Line2D(
            [0],
            [0],
            color="#303030",
            linestyle=LINESTYLES[name],
            linewidth=2.4,
            label=name,
        )
        for name in model_order
    ]
    figure.legend(
        handles=handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.02),
        ncol=len(handles),
        frameon=False,
        fontsize=13,
        handlelength=4.0,
    )
    save_publication_figure(figure, png_path, pdf_path)


def prepare_residual_correlograms(
    analysis_name: str,
    relationships: tuple[Relationship, ...],
    plot_data: dict[
        tuple[str, str],
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    ],
    fits: dict[tuple[str, str], dict],
    grid_shape: tuple[int, int],
) -> list[dict]:
    rows = []
    for relationship in relationships:
        for habitat in HABITATS:
            key = (relationship.key, habitat.key)
            x, y, grid_rows, grid_columns = plot_data[key]
            residuals = y - predict(fits[key], x)
            residual_map = residual_map_from_points(
                residuals,
                grid_rows,
                grid_columns,
                grid_shape,
            )
            moran_i, expected, neighbour_pairs = queen_morans_i(residual_map)
            for result in residual_distance_correlogram(residual_map):
                rows.append({
                    "analysis": analysis_name,
                    "relationship": relationship.key,
                    "habitat": habitat.key,
                    "selected_model": fits[key]["model"],
                    "queen_Morans_I": moran_i,
                    "Moran_expected_under_randomness": expected,
                    "Moran_queen_neighbour_pairs": neighbour_pairs,
                    **result,
                })
    return rows


def plot_residual_correlograms(
    relationships: tuple[Relationship, ...],
    correlogram_rows: list[dict],
    png_path: Path,
    pdf_path: Path,
) -> None:
    set_plot_style()
    figure, axes = plt.subplots(
        len(relationships),
        len(HABITATS),
        figsize=(16.0, 3.0 * len(relationships) + 0.4),
        sharex=True,
        sharey=True,
        squeeze=False,
    )
    figure.subplots_adjust(
        left=0.07,
        right=0.995,
        top=0.92,
        bottom=0.12,
        wspace=0.12,
        hspace=0.30,
    )
    lookup = {}
    for row in correlogram_rows:
        lookup.setdefault((row["relationship"], row["habitat"]), []).append(row)

    panel_index = 0
    row_labels = {
        "NPP_vs_Constancy": "NPP–constancy residual\nautocorrelation",
        "NPP_vs_Resistance": "NPP–resistance residual\nautocorrelation",
        "Constancy_vs_Resistance": "Constancy–resistance residual\nautocorrelation",
        "Baseline_NPP_vs_Subsequent_Constancy": (
            "Baseline NPP–constancy residual\nautocorrelation"
        ),
        "Baseline_NPP_vs_Subsequent_Resistance": (
            "Baseline NPP–resistance residual\nautocorrelation"
        ),
        "Subsequent_Constancy_vs_Subsequent_Resistance": (
            "Constancy–resistance residual\nautocorrelation"
        ),
    }
    for row_index, relationship in enumerate(relationships):
        for column_index, habitat in enumerate(HABITATS):
            axis = axes[row_index, column_index]
            values = sorted(
                lookup[(relationship.key, habitat.key)],
                key=lambda item: item["lag_grid_cells"],
            )
            distances = np.array([item["distance_km_approx"] for item in values])
            correlations = np.array([
                item["residual_autocorrelation"] for item in values
            ])
            axis.axhline(0.0, color="#A0A0A0", linewidth=0.9, zorder=1)
            axis.plot(
                distances,
                correlations,
                marker="o",
                markersize=4.0,
                color=habitat.color,
                linewidth=1.7,
                zorder=3,
            )
            moran_i = values[0]["queen_Morans_I"] if values else np.nan
            axis.text(
                0.05,
                0.94,
                f"Moran's $I$ = {moran_i:.2f}",
                transform=axis.transAxes,
                ha="left",
                va="top",
                fontsize=11.5,
                bbox={
                    "facecolor": "white",
                    "alpha": 0.84,
                    "edgecolor": "none",
                    "pad": 1.0,
                },
            )
            axis.text(
                -0.04,
                1.02,
                chr(ord("a") + panel_index),
                transform=axis.transAxes,
                ha="left",
                va="bottom",
                fontsize=15,
                fontweight="bold",
            )
            panel_index += 1
            if row_index == 0:
                axis.set_title(
                    habitat.title,
                    color=habitat.color,
                    fontweight="bold",
                    pad=8,
                )
            if column_index == 0:
                axis.set_ylabel(
                    row_labels.get(
                        relationship.key,
                        "Residual autocorrelation",
                    ),
                    fontsize=12.5,
                )
            if row_index == len(relationships) - 1 and column_index == 2:
                axis.set_xlabel("Approximate distance (km)")
            axis.grid(False)

    save_publication_figure(figure, png_path, pdf_path)


def prepare_legacy_relationship_results(
    legacy_maps: dict[str, dict[str, np.ndarray]],
    masks: dict[str, np.ndarray],
    grid_shape: tuple[int, int],
) -> tuple[
    dict[tuple[str, str], tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]],
    dict[tuple[str, str], dict],
    list[dict],
]:
    """Reanalyse the current Figure 2 maps with spatially valid inference."""
    plot_data = {}
    fits = {}
    rows = []
    counter = 0
    for relationship in LEGACY_RELATIONSHIPS:
        for habitat in HABITATS:
            x_map = legacy_maps[habitat.key][relationship.predictor]
            y_map = legacy_maps[habitat.key][relationship.response]
            # Reproduce the current Figure 2 pairing rule exactly. Although a
            # log10 resistance of zero can be valid, retaining this rule makes
            # the old-versus-new comparison identical to the plotted dataset.
            valid = (
                masks[habitat.key]
                & np.isfinite(x_map)
                & np.isfinite(y_map)
                & (x_map != 0)
                & (y_map != 0)
            )
            grid_rows, grid_columns = np.nonzero(valid)
            x = x_map[valid].astype(np.float64)
            y = y_map[valid].astype(np.float64)
            if x.size < 20:
                raise ValueError(
                    f"Legacy {relationship.key}/{habitat.key}: only "
                    f"{x.size} paired pixels"
                )
            result, fit, _ = relationship_statistics(
                relationship,
                habitat,
                x,
                y,
                grid_rows,
                grid_columns,
                grid_shape,
                1000 + counter,
            )
            result["analysis"] = "Concurrent_1960_2019_current_Figure2"
            plot_data[(relationship.key, habitat.key)] = (
                x,
                y,
                grid_rows,
                grid_columns,
            )
            fits[(relationship.key, habitat.key)] = fit
            rows.append(result)
            counter += 1
    return plot_data, fits, rows


def old_vs_new_comparison(
    legacy_rows: list[dict],
    new_rows: list[dict],
) -> list[dict]:
    mapping = {
        "NPP_vs_Constancy": "Baseline_NPP_vs_Subsequent_Constancy",
        "NPP_vs_Resistance": "Baseline_NPP_vs_Subsequent_Resistance",
        "Constancy_vs_Resistance": "Subsequent_Constancy_vs_Subsequent_Resistance",
    }
    old_lookup = {(row["relationship"], row["habitat"]): row for row in legacy_rows}
    new_lookup = {(row["relationship"], row["habitat"]): row for row in new_rows}
    output = []
    for old_relationship, new_relationship in mapping.items():
        for habitat in HABITATS:
            old = old_lookup[(old_relationship, habitat.key)]
            new = new_lookup[(new_relationship, habitat.key)]
            output.append({
                "relationship": old_relationship,
                "habitat": habitat.key,
                "old_period_definition": "Concurrent 1960-2019",
                "new_period_definition": (
                    "Baseline NPP 1960-1989; stability 1990-2019"
                    if old_relationship != "Constancy_vs_Resistance"
                    else "Constancy and resistance 1990-2019"
                ),
                "old_n": old["n"],
                "new_n": new["n"],
                "old_Pearson_r": old["Pearson_r"],
                "new_Pearson_r": new["Pearson_r"],
                "change_in_Pearson_r": new["Pearson_r"] - old["Pearson_r"],
                "old_Spearman_rho": old["Spearman_rho"],
                "new_Spearman_rho": new["Spearman_rho"],
                "change_in_Spearman_rho": (
                    new["Spearman_rho"] - old["Spearman_rho"]
                ),
                "old_Pearson_block_CI_low": old["pearson_ci_low"],
                "old_Pearson_block_CI_high": old["pearson_ci_high"],
                "new_Pearson_block_CI_low": new["pearson_ci_low"],
                "new_Pearson_block_CI_high": new["pearson_ci_high"],
                "old_linear_slope": old["linear_slope"],
                "old_slope_block_CI_low": old["slope_ci_low"],
                "old_slope_block_CI_high": old["slope_ci_high"],
                "new_linear_slope": new["linear_slope"],
                "new_slope_block_CI_low": new["slope_ci_low"],
                "new_slope_block_CI_high": new["slope_ci_high"],
                "old_residual_queen_Morans_I": (
                    old["residual_queen_Morans_I"]
                ),
                "new_residual_queen_Morans_I": (
                    new["residual_queen_Morans_I"]
                ),
            })
    return output


def repeated_fixed_size_subsamples(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
) -> dict[str, float]:
    """Reviewer-suggested repeated samples of 500--1,000 pixels."""
    if x.size >= QUARTILE_SAMPLE_SIZE:
        sample_size = QUARTILE_SAMPLE_SIZE
    elif x.size >= QUARTILE_MIN_SAMPLE_SIZE:
        sample_size = QUARTILE_MIN_SAMPLE_SIZE
    else:
        # Retain small habitat/quartile combinations transparently. When all
        # pixels are selected, the repeated-sample interval will collapse.
        sample_size = x.size
    if sample_size < 20:
        return {
            "subsample_size": sample_size,
            "n_subsamples": 0,
            "subsample_Pearson_median": np.nan,
            "subsample_Pearson_CI_low": np.nan,
            "subsample_Pearson_CI_high": np.nan,
            "subsample_Spearman_median": np.nan,
            "subsample_Spearman_CI_low": np.nan,
            "subsample_Spearman_CI_high": np.nan,
            "subsample_slope_median": np.nan,
            "subsample_slope_CI_low": np.nan,
            "subsample_slope_CI_high": np.nan,
            "fraction_subsample_slopes_positive": np.nan,
        }

    rng = np.random.default_rng(seed)
    pearson_values = []
    spearman_values = []
    slopes = []
    for _ in range(N_QUARTILE_SUBSAMPLES):
        indices = rng.choice(x.size, size=sample_size, replace=False)
        xb = x[indices]
        yb = y[indices]
        pearson_values.append(pearson_correlation(xb, yb))
        spearman_values.append(spearman_correlation(xb, yb))
        slopes.append(float(np.polyfit(xb, yb, 1)[0]))

    def summary(values: list[float]) -> tuple[float, float, float]:
        array = np.asarray(values, dtype=float)
        return (
            float(np.nanmedian(array)),
            float(np.nanpercentile(array, 2.5)),
            float(np.nanpercentile(array, 97.5)),
        )

    pearson = summary(pearson_values)
    spearman = summary(spearman_values)
    slope = summary(slopes)
    return {
        "subsample_size": sample_size,
        "n_subsamples": N_QUARTILE_SUBSAMPLES,
        "subsample_Pearson_median": pearson[0],
        "subsample_Pearson_CI_low": pearson[1],
        "subsample_Pearson_CI_high": pearson[2],
        "subsample_Spearman_median": spearman[0],
        "subsample_Spearman_CI_low": spearman[1],
        "subsample_Spearman_CI_high": spearman[2],
        "subsample_slope_median": slope[0],
        "subsample_slope_CI_low": slope[1],
        "subsample_slope_CI_high": slope[2],
        "fraction_subsample_slopes_positive": float(np.mean(np.asarray(slopes) > 0)),
    }


def quartile_sensitivity(
    analysis_name: str,
    habitat_name: str,
    predictor_name: str,
    predictor_map: np.ndarray,
    outcomes: tuple[tuple[str, np.ndarray], ...],
    all_mask: np.ndarray,
    n_grid_columns: int,
    seed_start: int,
    exclude_zero_pairs: bool = False,
) -> list[dict]:
    predictor_values = predictor_map[all_mask & np.isfinite(predictor_map)]
    edges = np.quantile(predictor_values, [0.0, 0.25, 0.50, 0.75, 1.0])
    rows = []
    counter = 0
    for quartile in range(4):
        if quartile < 3:
            quartile_mask = (
                all_mask
                & (predictor_map >= edges[quartile])
                & (predictor_map < edges[quartile + 1])
            )
        else:
            quartile_mask = (
                all_mask
                & (predictor_map >= edges[quartile])
                & (predictor_map <= edges[quartile + 1])
            )
        for outcome_name, outcome_map in outcomes:
            if exclude_zero_pairs:
                quartile_mask_for_outcome = (
                    quartile_mask
                    & (predictor_map != 0)
                    & (outcome_map != 0)
                )
            else:
                quartile_mask_for_outcome = quartile_mask
            valid = (
                quartile_mask_for_outcome
                & np.isfinite(predictor_map)
                & np.isfinite(outcome_map)
            )
            grid_rows, grid_columns = np.nonzero(valid)
            x = predictor_map[valid].astype(np.float64)
            y = outcome_map[valid].astype(np.float64)
            base_row = {
                "analysis": analysis_name,
                "habitat": habitat_name,
                "predictor": predictor_name,
                "quartile": f"Q{quartile + 1}",
                "predictor_lower_bound": float(edges[quartile]),
                "predictor_upper_bound": float(edges[quartile + 1]),
                "outcome": outcome_name,
                "n": int(x.size),
            }
            if x.size < MIN_QUARTILE_PAIRED_PIXELS:
                warnings.warn(
                    f"Skipping {analysis_name}/{habitat_name}/Q{quartile + 1}/"
                    f"{outcome_name}: only {x.size} paired pixels"
                )
                rows.append({
                    **base_row,
                    "analysis_status": (
                        f"skipped_fewer_than_{MIN_QUARTILE_PAIRED_PIXELS}_pixels"
                    ),
                    "Pearson_r": np.nan,
                    "Spearman_rho": np.nan,
                    "linear_slope": np.nan,
                    "n_spatial_blocks": 0,
                    "pearson_ci_low": np.nan,
                    "pearson_ci_high": np.nan,
                    "spearman_ci_low": np.nan,
                    "spearman_ci_high": np.nan,
                    "slope_ci_low": np.nan,
                    "slope_ci_high": np.nan,
                    "successful_bootstraps": 0,
                    **repeated_fixed_size_subsamples(
                        x,
                        y,
                        RANDOM_SEED + seed_start + counter,
                    ),
                })
                counter += 1
                continue
            block_ids = spatial_block_ids(grid_rows, grid_columns, n_grid_columns)
            pearson = pearson_correlation(x, y)
            spearman = spearman_correlation(x, y)
            slope = float(np.polyfit(x, y, 1)[0])
            bootstrap = spatial_block_bootstrap(
                x,
                y,
                block_ids,
                RANDOM_SEED + seed_start + 30000 + counter,
            )
            subsamples = repeated_fixed_size_subsamples(
                x,
                y,
                RANDOM_SEED + seed_start + counter,
            )
            rows.append({
                **base_row,
                "analysis_status": "analysed",
                "Pearson_r": pearson,
                "Spearman_rho": spearman,
                "linear_slope": slope,
                **bootstrap,
                **subsamples,
            })
            counter += 1
    return rows


def plot_quartile_sensitivity(
    rows: list[dict],
    png_path: Path,
    pdf_path: Path,
) -> None:
    """Summarise the reviewer-requested quartile analysis for all grasslands."""
    set_plot_style()
    panels = (
        (
            "Concurrent_1960_2019_current_Figure2",
            "Concurrent_Constancy_1960_2019",
            "Concurrent (1960–2019)",
            "Constancy",
        ),
        (
            "Concurrent_1960_2019_current_Figure2",
            "Concurrent_Resistance_1960_2019",
            "Concurrent (1960–2019)",
            "Resistance",
        ),
        (
            "Independent_period",
            "Subsequent_Constancy_1990_2019",
            "Independent periods",
            "Constancy",
        ),
        (
            "Independent_period",
            "Subsequent_Resistance_1990_2019",
            "Independent periods",
            "Resistance",
        ),
    )
    figure, axes = plt.subplots(
        2,
        2,
        figsize=(10.8, 8.0),
        sharex=True,
        sharey=True,
        squeeze=False,
    )
    figure.subplots_adjust(
        left=0.12,
        right=0.98,
        top=0.91,
        bottom=0.16,
        wspace=0.16,
        hspace=0.22,
    )
    panel_letters = "abcd"
    for panel_index, (analysis, outcome, row_title, column_title) in enumerate(panels):
        axis = axes[panel_index // 2, panel_index % 2]
        selected = [
            row for row in rows
            if row["analysis"] == analysis
            and row["habitat"] == "All"
            and row["outcome"] == outcome
        ]
        selected.sort(key=lambda row: row["quartile"])
        if len(selected) != 4:
            raise ValueError(
                f"Expected four all-grassland quartiles for {analysis}/{outcome}, "
                f"found {len(selected)}"
            )

        positions = np.arange(1, 5, dtype=float)
        observed = np.array([row["Pearson_r"] for row in selected], dtype=float)
        block_low = np.array([row["pearson_ci_low"] for row in selected], dtype=float)
        block_high = np.array([row["pearson_ci_high"] for row in selected], dtype=float)
        repeated_median = np.array([
            row["subsample_Pearson_median"] for row in selected
        ], dtype=float)
        repeated_low = np.array([
            row["subsample_Pearson_CI_low"] for row in selected
        ], dtype=float)
        repeated_high = np.array([
            row["subsample_Pearson_CI_high"] for row in selected
        ], dtype=float)

        axis.axhline(0.0, color="#A0A0A0", linewidth=0.9, zorder=1)
        axis.errorbar(
            positions - 0.07,
            observed,
            yerr=np.maximum(
                0.0,
                np.vstack((observed - block_low, block_high - observed)),
            ),
            fmt="o",
            color="#222222",
            ecolor="#222222",
            elinewidth=1.5,
            capsize=3.0,
            markersize=6.0,
            label="Observed $r$ + spatial-block 95% CI",
            zorder=4,
        )
        axis.errorbar(
            positions + 0.07,
            repeated_median,
            yerr=np.vstack((
                repeated_median - repeated_low,
                repeated_high - repeated_median,
            )),
            fmt="s",
            color="#4C9ED9",
            ecolor="#83BCE3",
            elinewidth=1.5,
            capsize=3.0,
            markersize=5.5,
            label="Repeated-sample median + 95% range",
            zorder=3,
        )
        axis.text(
            -0.08,
            1.02,
            panel_letters[panel_index],
            transform=axis.transAxes,
            ha="left",
            va="bottom",
            fontsize=16,
            fontweight="bold",
        )
        if panel_index < 2:
            axis.set_title(column_title, fontweight="bold", pad=8)
        if panel_index % 2 == 0:
            axis.set_ylabel(f"{row_title}\nPearson $r$")
        axis.set_xticks(positions, ["Q1", "Q2", "Q3", "Q4"])
        axis.set_ylim(-1.0, 1.0)
        axis.grid(False)

    figure.supxlabel("NPP quartile within all grassland pixels", y=0.085, fontsize=16)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    figure.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.005),
        ncol=2,
        frameon=False,
        fontsize=11.5,
    )
    save_publication_figure(figure, png_path, pdf_path)


def write_methods_note(path: Path, selected_ddof: int, metadata: dict[str, str]) -> None:
    content = f"""Independent-period NPP-stability sensitivity analysis

Script version: {SCRIPT_VERSION}

Input NPP: {RAW_NPP_FILE}
Input NPP variable: {RAW_NPP_VARIABLE}
Original dimensions: {metadata['source_dimensions']}
Original shape: {metadata['source_shape']}
Original units attribute: {metadata['source_units']}
Annual conversion: NPP multiplied by {NPP_TO_ANNUAL:g}
Legacy aggregated maps: read without any additional annual conversion
Spatial alignment: legacy latitude/longitude coordinates aligned to the raw NPP cube; reversed axes are corrected before masking
Missing values: masked/non-finite values and abs(value) >= {MISSING_ABS_THRESHOLD:.0e} treated as missing
Ferret gateway mask: the corresponding legacy constancy variable must be > 0
Full-period validation gate: Pearson r >= {VALIDATION_MIN_PEARSON:g} and median relative difference <= {VALIDATION_MAX_MEDIAN_RELATIVE_DIFFERENCE:g} for NPP, constancy and resistance

Baseline productivity period: {BASELINE_START}-{BASELINE_END}
Subsequent stability period: {EVALUATION_START}-{EVALUATION_END}
Shared years between periods: 0
Detrending: polynomial degree {DETREND_DEGREE}, fitted separately within the evaluation period
Residual SD ddof: {selected_ddof}, selected by comparison with the legacy full-period constancy map unless forced
Resistance: log10(abs(1/min(A))), where A=(NPP-mean(NPP))/SD(detrended residuals)

Spatial uncertainty: block bootstrap with {N_BOOTSTRAP} replicates
Block dimensions: {SPATIAL_BLOCK_CELLS} x {SPATIAL_BLOCK_CELLS} grid cells (about {SPATIAL_BLOCK_CELLS * GRID_CELL_SIZE_KM:g} km per side for an 8-km grid)
Block-size sensitivity: all-grassland intervals repeated for {', '.join(str(int(c * GRID_CELL_SIZE_KM)) for c in BLOCK_SENSITIVITY_CELLS)}-km block sides
Random seed: {RANDOM_SEED}

Productivity-range sensitivity: the concurrent 1960-2019 and independent-period
NPP relationships for all grassland pixels are stratified into NPP quartiles.
Within each quartile, {N_QUARTILE_SUBSAMPLES} random samples are drawn without
replacement. The sample size is {QUARTILE_SAMPLE_SIZE} pixels when available,
{QUARTILE_MIN_SAMPLE_SIZE} pixels when 500-999 are available, and all pixels
for smaller strata. Pearson r, Spearman rho and the linear slope are reported
for every stratum, together with repeated-sample distributions and spatial
block-bootstrap intervals.

Residual spatial autocorrelation: queen-contiguity Moran's I and a distance
correlogram from 1 to {MAX_CORRELOGRAM_LAG_CELLS} grid cells (approximately
{GRID_CELL_SIZE_KM:g}-{MAX_CORRELOGRAM_LAG_CELLS * GRID_CELL_SIZE_KM:g} km)
are calculated from the residuals of the selected relationship model. These
diagnostics are produced both for the current concurrent Figure 2 relationships
and for the independent-period sensitivity relationships.
For both the concurrent 1960-2019 relationships and the independent-period
relationships, response forms are selected using the prespecified AICc plus
fivefold spatially blocked cross-validation rule. A nonlinear model is retained
only when it has a lower AICc than the linear model and reduces blocked-CV RMSE
by at least {100 * MIN_CV_IMPROVEMENT:g}%.

No naive pixel-level p-values are used for inference. Interpretation should
rely on the spatial block-bootstrap intervals because neighbouring grid cells
are not independent. The rolling windows used elsewhere in the manuscript
remain descriptive and are not treated as independent replicates.
"""
    path.write_text(content, encoding="utf-8")


# =============================================================================
# Main workflow
# =============================================================================


def main() -> None:
    require_files()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    status_path = OUTPUT_DIR / "analysis_run_status.txt"
    status_path.write_text(
        "INCOMPLETE: analysis started but has not yet passed every step.\n",
        encoding="utf-8",
    )

    print("Reading annual NPP and legacy maps...", flush=True)
    annual_npp, metadata, raw_latitude, raw_longitude = load_npp_cube()
    shape = annual_npp.shape[1:]
    legacy_maps = load_legacy_maps(
        shape,
        raw_latitude,
        raw_longitude,
    )
    masks, mask_diagnostics = build_masks(annual_npp, legacy_maps)

    selected_ddof, full_metrics, validation_rows = select_ddof_and_validate(
        annual_npp,
        masks["All"],
        legacy_maps["All"],
    )
    # Save the gate diagnostics even if validation fails, then stop before any
    # inferential output can be generated from a misaligned dataset.
    write_csv(OUTPUT_DIR / "habitat_mask_diagnostics.csv", mask_diagnostics)
    write_csv(OUTPUT_DIR / "full_period_map_validation.csv", validation_rows)
    enforce_full_period_validation(validation_rows)
    print("Full-period Ferret reproduction passed.", flush=True)

    baseline_slice = period_slice(BASELINE_START, BASELINE_END)
    evaluation_slice = period_slice(EVALUATION_START, EVALUATION_END)
    baseline_mean = np.full(shape, np.nan, dtype=np.float64)
    baseline_mean[masks["All"]] = np.mean(
        annual_npp[baseline_slice][:, masks["All"]],
        axis=0,
    )
    evaluation_metrics = calculate_metric_maps(
        annual_npp,
        evaluation_slice,
        masks["All"],
        selected_ddof,
    )
    new_maps = maps_for_new_analysis(baseline_mean, evaluation_metrics)

    print(
        "Estimating independent-period relationships and spatial "
        f"bootstrap intervals ({N_BOOTSTRAP} replicates)...",
        flush=True,
    )
    main_plot_data, main_fits, main_rows = prepare_relationship_results(
        MAIN_RELATIONSHIPS,
        new_maps,
        masks,
        shape,
        seed_start=0,
    )
    variability_plot_data, variability_fits, variability_rows = (
        prepare_relationship_results(
            (VARIABILITY_RELATIONSHIP,),
            new_maps,
            masks,
            shape,
            seed_start=100,
        )
    )
    for row in main_rows:
        row["analysis"] = "Independent_period"
    for row in variability_rows:
        row["analysis"] = "Independent_period"

    print(
        "Reanalysing the concurrent Figure 2 relationships with spatial "
        "inference...",
        flush=True,
    )
    legacy_plot_data, legacy_fits, legacy_rows = (
        prepare_legacy_relationship_results(legacy_maps, masks, shape)
    )
    comparison_rows = old_vs_new_comparison(legacy_rows, main_rows)

    print("Checking sensitivity to spatial block size...", flush=True)
    block_sensitivity_rows = block_size_sensitivity(
        "Concurrent_1960_2019_current_Figure2",
        LEGACY_RELATIONSHIPS,
        legacy_plot_data,
        shape,
        seed_start=0,
    )
    block_sensitivity_rows.extend(block_size_sensitivity(
        "Independent_period",
        MAIN_RELATIONSHIPS + (VARIABILITY_RELATIONSHIP,),
        {**main_plot_data, **variability_plot_data},
        shape,
        seed_start=1000,
    ))

    print("Calculating residual spatial correlograms...", flush=True)
    legacy_correlogram_rows = prepare_residual_correlograms(
        "Concurrent_1960_2019_current_Figure2",
        LEGACY_RELATIONSHIPS,
        legacy_plot_data,
        legacy_fits,
        shape,
    )
    independent_correlogram_rows = prepare_residual_correlograms(
        "Independent_period",
        MAIN_RELATIONSHIPS,
        main_plot_data,
        main_fits,
        shape,
    )

    print("Creating 600-dpi and vector figures...", flush=True)
    figure_png = OUTPUT_DIR / "Figure_S11_independent_period_relationships.png"
    figure_pdf = OUTPUT_DIR / "Figure_S11_independent_period_relationships.pdf"
    variability_png = OUTPUT_DIR / "Figure_baseline_NPP_subsequent_variability.png"
    variability_pdf = OUTPUT_DIR / "Figure_baseline_NPP_subsequent_variability.pdf"
    legacy_correlogram_png = (
        OUTPUT_DIR / "Figure_residual_correlograms_current_Figure2.png"
    )
    legacy_correlogram_pdf = (
        OUTPUT_DIR / "Figure_residual_correlograms_current_Figure2.pdf"
    )
    independent_correlogram_png = (
        OUTPUT_DIR / "Figure_residual_correlograms_independent_period.png"
    )
    independent_correlogram_pdf = (
        OUTPUT_DIR / "Figure_residual_correlograms_independent_period.pdf"
    )
    quartile_figure_png = OUTPUT_DIR / "Figure_NPP_quartile_sensitivity.png"
    quartile_figure_pdf = OUTPUT_DIR / "Figure_NPP_quartile_sensitivity.pdf"

    plot_relationship_grid(
        MAIN_RELATIONSHIPS,
        main_plot_data,
        main_fits,
        main_rows,
        figure_png,
        figure_pdf,
    )
    plot_relationship_grid(
        (VARIABILITY_RELATIONSHIP,),
        variability_plot_data,
        variability_fits,
        variability_rows,
        variability_png,
        variability_pdf,
    )
    plot_residual_correlograms(
        LEGACY_RELATIONSHIPS,
        legacy_correlogram_rows,
        legacy_correlogram_png,
        legacy_correlogram_pdf,
    )
    plot_residual_correlograms(
        MAIN_RELATIONSHIPS,
        independent_correlogram_rows,
        independent_correlogram_png,
        independent_correlogram_pdf,
    )

    # Save all core results before the optional quartile sensitivity step so
    # that a sparse sensitivity stratum can never discard completed analyses.
    write_csv(
        OUTPUT_DIR / "independent_period_relationship_statistics.csv",
        main_rows + variability_rows,
    )
    write_csv(
        OUTPUT_DIR / "concurrent_Figure2_relationship_statistics_spatial.csv",
        legacy_rows,
    )
    write_csv(
        OUTPUT_DIR / "old_vs_independent_period_comparison.csv",
        comparison_rows,
    )
    write_csv(
        OUTPUT_DIR / "residual_spatial_correlograms.csv",
        legacy_correlogram_rows + independent_correlogram_rows,
    )
    write_csv(
        OUTPUT_DIR / "spatial_block_size_sensitivity.csv",
        block_sensitivity_rows,
    )
    write_methods_note(
        OUTPUT_DIR / "analysis_methods_and_settings.txt",
        selected_ddof,
        metadata,
    )

    print(
        "Running repeated within-NPP-quartile sensitivity analyses...",
        flush=True,
    )
    # The reviewer's proposed 500--1,000-pixel resampling targets the global
    # spatial productivity gradient. It is therefore applied to the complete
    # all-grassland dataset, not to habitat x quartile combinations that may
    # contain only a handful of pixels.
    all_habitat = HABITATS[0]
    quartile_rows = quartile_sensitivity(
        analysis_name="Concurrent_1960_2019_current_Figure2",
        habitat_name=all_habitat.key,
        predictor_name="Mean_NPP_1960_2019",
        predictor_map=legacy_maps[all_habitat.key]["NPP"],
        outcomes=(
            (
                "Concurrent_Constancy_1960_2019",
                legacy_maps[all_habitat.key]["Constancy"],
            ),
            (
                "Concurrent_Resistance_1960_2019",
                legacy_maps[all_habitat.key]["Resistance"],
            ),
        ),
        all_mask=masks[all_habitat.key],
        n_grid_columns=shape[1],
        seed_start=40000,
        exclude_zero_pairs=True,
    )
    quartile_rows.extend(quartile_sensitivity(
        analysis_name="Independent_period",
        habitat_name=all_habitat.key,
        predictor_name="Baseline_NPP_1960_1989",
        predictor_map=new_maps["Baseline_NPP"],
        outcomes=(
            (
                "Subsequent_Constancy_1990_2019",
                new_maps["Subsequent_Constancy"],
            ),
            (
                "Subsequent_Resistance_1990_2019",
                new_maps["Subsequent_Resistance"],
            ),
            (
                "Subsequent_Detrended_SD_1990_2019",
                new_maps["Subsequent_Detrended_SD"],
            ),
        ),
        all_mask=masks[all_habitat.key],
        n_grid_columns=shape[1],
        seed_start=50000,
    ))

    plot_quartile_sensitivity(
        quartile_rows,
        quartile_figure_png,
        quartile_figure_pdf,
    )

    write_csv(
        OUTPUT_DIR / "NPP_quartile_sensitivity.csv",
        quartile_rows,
    )
    status_path.write_text(
        "COMPLETE: alignment, full-period validation, core analyses, "
        "figures and quartile sensitivity all finished successfully.\n",
        encoding="utf-8",
    )

    print("\nIndependent-period analysis completed")
    print("=" * 78)
    print(
        f"Baseline NPP: {BASELINE_START}-{BASELINE_END}; "
        f"stability: {EVALUATION_START}-{EVALUATION_END}"
    )
    print(f"Selected residual SD ddof: {selected_ddof}")
    print("\nFull-period reconstruction checks:")
    for row in validation_rows:
        print(
            f"  {row['metric']:<23} r={row['pearson_r']:.5f}; "
            f"median relative difference="
            f"{100 * row['median_relative_absolute_difference']:.3f}%"
        )

    print("\nOld concurrent versus independent-period Pearson correlations:")
    for row in comparison_rows:
        print(
            f"  {row['relationship']:<28} {row['habitat']:<12} "
            f"old={row['old_Pearson_r']:+.3f}; "
            f"new={row['new_Pearson_r']:+.3f}; "
            f"95% block CI=[{row['new_Pearson_block_CI_low']:+.3f}, "
            f"{row['new_Pearson_block_CI_high']:+.3f}]"
        )

    print("\nOutputs:")
    for path in (
        figure_png,
        figure_pdf,
        variability_png,
        variability_pdf,
        legacy_correlogram_png,
        legacy_correlogram_pdf,
        independent_correlogram_png,
        independent_correlogram_pdf,
        quartile_figure_png,
        quartile_figure_pdf,
        OUTPUT_DIR / "full_period_map_validation.csv",
        OUTPUT_DIR / "habitat_mask_diagnostics.csv",
        OUTPUT_DIR / "independent_period_relationship_statistics.csv",
        OUTPUT_DIR / "concurrent_Figure2_relationship_statistics_spatial.csv",
        OUTPUT_DIR / "old_vs_independent_period_comparison.csv",
        OUTPUT_DIR / "NPP_quartile_sensitivity.csv",
        OUTPUT_DIR / "residual_spatial_correlograms.csv",
        OUTPUT_DIR / "spatial_block_size_sensitivity.csv",
        OUTPUT_DIR / "analysis_methods_and_settings.txt",
        status_path,
    ):
        print(f"  {path}")
    print("\nInput NetCDF files were not modified.")


if __name__ == "__main__":
    main()
