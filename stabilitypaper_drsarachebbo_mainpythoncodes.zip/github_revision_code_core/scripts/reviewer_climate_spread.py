#!/usr/bin/env python3
"""Climate-chain diagnostics and Figure 4 spread, without rerunning ORCHIDEE.

Run in the directory of the ten NetCDFs and the original Figure 4 values CSV:
  python3 reviewer_climate_spread.py --annual-2010-2099

The flag explicitly confirms that the 90 records are annual means for 2010-2099.
The year-zero time origin cannot establish the actual years. No daily/monthly
aggregation is performed here. Temperature stays in K. Rainfall values are
confirmed to represent mean rates in mm/hour and are converted to mm/year with
24 * 365 before calculating and plotting 30-year mean annual rainfall.
With --annual-2010-2099, records are assigned to years by their supplied order,
as in the original Figure 4 script. Numeric time must be finite and increasing
within each documented ten-record segment. Resets exactly at all eight decade
boundaries are supported; other reversals are rejected. The mapping relies on
the supplied chronological order of the nine segments, not their reset dates.
Original time metadata and step sizes are recorded in input_audit.csv.

Dependencies: numpy, xarray, matplotlib, and a NetCDF backend.
By default, outputs are written to reviewer_climate_20260909_155814_569547.
Generated files with the same names are replaced; source NetCDF files are
never modified. Use --output-dir to select another output directory.

Climate mask: common complete-data cells in all ten files with some positive NPP
in EACH file, optionally intersected with an explicit grassland mask > 0.
This is a data-availability proxy, NOT proof of permanent-grassland cover.
Check the reported number of cells and supply --mask-file/--mask-variable if needed.
Equal cell weights (appropriate to an equal-area 8-km grid) are used; no weighting
by grassland fraction. Rain zeros are retained; negative rain is invalid.

Rain CV: sample SD / mean of annual rainfall at EACH cell over 30 years,
then spatial mean. Raw (not detrended) CV; long-term changes can contribute to SD.
CV is invariant to multiplying every annual value by the same positive constant.
Never smooth rain before calculating CV. Windows are labelled by their end year.

Figure 4: original exported series are reused EXACTLY, including existing NPP
365-day scaling, five-year smoothing, masks and log10(mean resistance) convention.
These inherited choices are not independently validated by this script.
Spread is calculated across the five displayed model series, not across cells.
Min-max is ensemble spread, NOT a confidence interval or full uncertainty budget.
"""

import argparse
import csv
from pathlib import Path

import numpy as np
import xarray as xr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator

MODELS = ['RCA4_CNRM', 'RACMO22E_CNRM', 'RACMO22E_EC',
          'RACMO22E_HadGEM', 'REMO2015_NorESM']
# Keep the model colours used in the original temporal-evolution figure.
COLORS = ['#E69F00', '#009E73', '#000000', '#7F7F7F', '#56B4E9']
FILES = {
    'RCP 4.5': ['varllvar_cnrm_cm5_rcp45.nc',
                'varllvar_co2var_rcp45_cnrm_cm_2D.nc',
                'varllvar_ichec_rcp45.nc', 'varllvar_mohcknmi_rcp45.nc',
                'varllvar_nccgerics_rcp45.nc'],
    'RCP 8.5': ['varllvar_rcp85_cnrm_cm5.nc',
                'varllvar_co2var_rcp85_cnrm_cm_2D.nc',
                'varllvar_rcp85_ichec.nc', 'varllvar_rcp85_mohc_knmi.nc',
                'varllvar_rcp85_nccgerics.nc']}
SPATIAL = ('latitude', 'longitude')
WINDOW_YEARS = np.arange(2039, 2100)
CLIMATE_LABELS = ['30-year mean air temperature (K)',
                  '30-year mean annual rainfall (mm yr$^{-1}$)',
                  'Mean local interannual rainfall CV (%)']
HOURS_PER_YEAR = 24.0 * 365.0


def clean(da):
    da = da.astype(float)
    # Exclude nonfinite values and unphysical huge missing-value sentinels.
    return da.where(np.isfinite(da) & (abs(da) < 1e20))


def audit_annual_time(time, attrs, filename):
    """Audit raw chronology; actual year mapping is explicitly user-confirmed in main."""
    time = np.asarray(time, dtype=float)
    attrs = dict(attrs)
    if time.shape != (90,) or not np.isfinite(time).all():
        raise ValueError(f'{filename}: expected 90 finite time coordinates; '
                         f'got shape {time.shape}. Inspect the time axis.')
    steps = np.diff(time)
    bad = np.flatnonzero(steps <= 0)
    decade_resets = np.array_equal(bad, np.arange(9, 89, 10))
    if len(bad) and not decade_resets:
        raise ValueError(f'{filename}: repeated or decreasing time coordinates at '
                         f'indices {bad.tolist()}. These do not match the documented '
                         'nine consecutive ten-year segments. Check chronological order; '
                         'the script will not sort or remove records automatically.')
    if decade_resets:
        print(f'  TIME NOTE: {filename}: resets at all eight ten-year boundaries. '
              'Preserving the nine segments in supplied order: 2010-2019, ..., 2090-2099. '
              'No observations sorted, deleted or averaged.', flush=True)
    units = ' '.join(str(attrs.get('units', '')).lower().split())
    monthly_years = (units.startswith(('month since', 'months since'))
                     and np.allclose(steps, 12))
    attrs['raw_first_time_values'] = time[:5].tolist()
    attrs['raw_last_time_values'] = time[-5:].tolist()
    attrs['raw_min_step'] = float(steps.min())
    attrs['raw_max_step'] = float(steps.max())
    attrs['raw_time_reset_indices'] = bad.tolist()
    attrs['time_layout'] = 'nine ten-record segments' if decade_resets else 'monotonic'
    attrs['analysis_year_mapping'] = 'Record order -> 2010-2099; confirmed by --annual-2010-2099'
    if not monthly_years and not decade_resets:
        print(f'  TIME NOTE: {filename}: units={attrs.get("units")!r}, '
              f'first={time[:5].tolist()}, step range={steps.min():g}..{steps.max():g}. '
              'Using the explicitly confirmed annual record order 2010-2099.', flush=True)
    return attrs


def read_climate(path):
    with xr.open_dataset(path, decode_times=False) as ds:
        arrays = []
        for name in ('tair', 'rain', 'NPP'):
            da = clean(ds[name])
            if set(da.dims) != {'time_counter', *SPATIAL}:
                raise ValueError(f'{path.name}: unexpected {name} dims {da.dims}')
            da = da.transpose('time_counter', *SPATIAL)
            if da.sizes['time_counter'] != 90:
                raise ValueError(f'{path.name}: expected 90 annual records')
            arrays.append(da.load())
        t, r, n = arrays
        if ds['tair'].attrs.get('units', '').strip() != 'K':
            raise ValueError(f'{path.name}: tair units must be K')
        # The numerical values were independently confirmed to be mm/hour.
        # Preserve the file metadata in the audit because older derived files
        # may contain an incorrect mm/d label.
        reported_rain_units = ds['rain'].attrs.get('units', '').strip()
        if reported_rain_units.lower() not in {'mm/h', 'mm/hour', 'mm hr-1', 'mm h-1'}:
            print(f'  UNIT NOTE: {path.name}: rain metadata reports '
                  f'{reported_rain_units!r}; applying the externally confirmed '
                  'mm/hour interpretation.', flush=True)
        time = ds['time_counter'].values.astype(float)
        attrs = audit_annual_time(time, ds['time_counter'].attrs, path.name)
        attrs['rain_units_reported'] = reported_rain_units
        attrs['rain_units_used'] = 'mm/hour'
        attrs['rain_conversion'] = 'annual rainfall = rain * 24 * 365'
    r = r * HOURS_PER_YEAR
    r.attrs['units'] = 'mm/year'
    # A full common temporal footprint, fixed rather than selected separately each year.
    valid = (np.isfinite(t) & np.isfinite(r) & np.isfinite(n)
             & (t > 150) & (t < 350) & (r >= 0)).all('time_counter')
    valid = valid & (n > 0).any('time_counter')
    return t, r, valid, attrs


def window_metrics(t, r, mask):
    tv = t.values[:, mask]
    rv = r.values[:, mask]
    # Undefined CV for any completely dry window: exclude these cells from ALL
    # climate windows for this calculation; caller prechecks the common mask.
    result = np.empty((3, 61))
    for start in range(61):
        tt, rr = tv[start:start+30], rv[start:start+30]
        means = rr.mean(axis=0)
        if np.any(means <= 0):
            raise ValueError('Zero-mean rainfall window: CV undefined; inspect these cells')
        result[:, start] = [tt.mean(), means.mean(),
                            (rr.std(axis=0, ddof=1) / means).mean() * 100]
    return result


def ensemble(ax, years, values):
    if values.shape != (5, len(years)) or not np.isfinite(values).all():
        raise ValueError('Ensemble requires five finite aligned model series')
    ax.fill_between(years, values.min(axis=0), values.max(axis=0),
                    color='0.65', alpha=0.3, linewidth=0, zorder=1)
    for color, row in zip(COLORS, values):
        ax.plot(years, row, color=color, lw=0.9, alpha=0.85, zorder=2)
    ax.plot(years, np.median(values, axis=0), color='black', lw=1.9,
            linestyle='--', zorder=3)


def finish(fig, axes, stem, historical=False):
    for i, ax in enumerate(axes.flat):
        ax.grid(axis='y', alpha=0.2)
        ax.text(0.02, 0.96, chr(97+i), transform=ax.transAxes,
                va='top', weight='bold')
    handles = [Line2D([0], [0], color=c, lw=1.4, label=m)
               for c, m in zip(COLORS, MODELS)]
    if historical:
        handles.insert(0, Line2D([0], [0], color='#D55E00', label='SAFRAN'))
    handles += [Line2D([0], [0], color='black', lw=1.9, ls='--', label='Median'),
                Patch(color='0.65', alpha=0.3, label='Min-max across 5 chains')]
    fig.legend(handles=handles, loc='lower center', ncol=3, frameon=False)
    fig.tight_layout(rect=(0, 0.105, 1, 1))
    fig.savefig(str(stem)+'.png', dpi=600, bbox_inches='tight',
                facecolor='white')
    fig.savefig(str(stem)+'.pdf', bbox_inches='tight', facecolor='white')
    plt.close(fig)


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def figure4(csv_path, out):
    with csv_path.open(newline='', encoding='utf-8') as f:
        records = list(csv.DictReader(f))

    def get(metric, source, scenario, model, expected):
        rows = sorted((r for r in records if r['metric'] == metric
                       and r['source'] == source and r['scenario'] == scenario
                       and r['model'] == model), key=lambda r: int(r['year']))
        years = np.array([int(r['year']) for r in rows])
        if not np.array_equal(years, expected):
            raise ValueError(f'CSV years missing/duplicated: {metric}/{scenario}/{model}')
        return np.array([float(r['value']) for r in rows])

    # Reproduce the original Figure 4 layout and scales. The shaded intermodel
    # range and dashed ensemble median are the only graphical additions.
    plt.rcParams.update({
        'font.family': 'DejaVu Sans',
        'font.size': 9,
        'axes.titlesize': 10,
        'axes.labelsize': 10,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'legend.fontsize': 8,
        'axes.linewidth': 0.8,
    })

    fig, axes = plt.subplots(nrows=3, ncols=3, figsize=(13.0, 10.0),
                             sharey='row')
    spread_rows = []
    for i, (metric, label) in enumerate([
        ('NPP', 'Mean annual NPP (g C m$^{-2}$ yr$^{-1}$)'),
        ('Constancy', 'Mean NPP constancy'),
        ('Resistance', 'Mean NPP resistance M10 (log$_{10}$)')]):
        histyears = np.arange(1960 if metric == 'NPP' else 1989, 2020)
        years = np.arange(2010 if metric == 'NPP' else 2039, 2100)
        hist = get(metric, 'SAFRAN', 'historical', 'SAFRAN', histyears)
        axes[i, 0].plot(histyears, hist, color='#D55E00', lw=1.8)
        axes[i, 0].set_xlim(histyears[0], histyears[-1])
        axes[i, 0].set_ylabel(label)
        for j, scenario in enumerate(FILES, start=1):
            values = np.array([get(metric, 'EURO-CORDEX', scenario, m, years)
                               for m in MODELS])
            ax = axes[i, j]

            # Reviewer addition: full spread across the five displayed chains.
            ax.fill_between(years, values.min(axis=0), values.max(axis=0),
                            color='0.65', alpha=0.30, linewidth=0, zorder=1)

            # Original model series: same values, colours and line appearance.
            for color, row in zip(COLORS, values):
                ax.plot(years, row, color=color, linewidth=1.2,
                        alpha=0.90, zorder=2)

            # Reviewer addition: ensemble median.
            ax.plot(years, np.median(values, axis=0), color='black',
                    linewidth=1.9, linestyle='--', zorder=3)
            ax.set_xlim(years[0], years[-1])
            for k, year in enumerate(years):
                spread_rows.append(dict(metric=metric, scenario=scenario, year=int(year),
                                        median=np.median(values[:, k]),
                                        minimum=values[:, k].min(), maximum=values[:, k].max()))

    # Match the original panel styling and tick density. Since the band lies
    # between existing curves, it does not enlarge the original data ranges.
    for panel_index, ax in enumerate(axes.flat):
        ax.grid(axis='y', color='#D9D9D9', linewidth=0.5, alpha=0.7)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
        ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
        ax.tick_params(direction='out', length=3, width=0.7)
        ax.text(0.02, 0.96, chr(97 + panel_index), transform=ax.transAxes,
                ha='left', va='top', fontweight='bold', fontsize=10)

    # Original Figure 4 axis-title placement: Year for NPP, and the rolling-
    # window label only on the bottom row. The constancy row has tick labels but
    # no repeated x-axis title, exactly as in the base figure.
    for ax in axes[0]:
        ax.set_xlabel('Year')
    for ax in axes[2]:
        ax.set_xlabel('End year of 30-year rolling window')

    titles = ['SAFRAN forcing\n(1960-2019)',
              'EURO-CORDEX RCP 4.5\n(2010-2099)',
              'EURO-CORDEX RCP 8.5\n(2010-2099)']
    for ax, title in zip(axes[0], titles):
        ax.set_title(title, weight='bold', pad=8)

    handles = [Line2D([0], [0], color='#D55E00', linewidth=2.0,
                      label='SAFRAN')]
    handles.extend(Line2D([0], [0], color=color, linewidth=1.8, label=model)
                   for color, model in zip(COLORS, MODELS))
    handles.extend([
        Line2D([0], [0], color='black', linewidth=1.9, linestyle='--',
               label='Median'),
        Patch(color='0.65', alpha=0.30, label='Min-max across 5 chains'),
    ])
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.5, 0.012),
               ncol=4, frameon=False)
    fig.align_ylabels(axes[:, 0])
    fig.tight_layout(rect=(0.02, 0.085, 0.995, 0.995), h_pad=1.2, w_pad=1.0)

    stem = out/'Figure4_intermodel_spread'
    fig.savefig(str(stem)+'.png', dpi=600, bbox_inches='tight',
                facecolor='white')
    fig.savefig(str(stem)+'.pdf', bbox_inches='tight', facecolor='white')
    plt.close(fig)
    write_csv(out/'Figure4_ensemble_values.csv', spread_rows)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--data-dir', type=Path, default=Path.cwd())
    p.add_argument('--output-dir', type=Path,
                   default=Path('reviewer_climate_20260909_155814_569547'),
                   help=('Output directory. Existing generated files with the same '
                         'names are replaced. Relative paths are resolved inside DATA_DIR.'))
    p.add_argument('--annual-2010-2099', action='store_true')
    p.add_argument('--mask-file', type=Path)
    p.add_argument('--mask-variable')
    p.add_argument('--figure4-values', type=Path,
                   default=Path('Figure_temporal_evolution_independent_windows_values.csv'))
    args = p.parse_args()
    if not args.annual_2010_2099:
        p.error('Confirm the 90 records are annual means for 2010-2099 with --annual-2010-2099')
    if bool(args.mask_file) != bool(args.mask_variable):
        p.error('Supply BOTH --mask-file and --mask-variable')
    out = args.output_dir
    if not out.is_absolute():
        out = args.data_dir / out
    fields, audit, common = {}, [], None
    for scenario, names in FILES.items():
        for model, filename in zip(MODELS, names):
            print('Reading', filename, flush=True)
            t, r, valid, attrs = read_climate(args.data_dir/filename)
            if common is None:
                common = valid
            else:
                common, valid = xr.align(common, valid, join='exact')
                common = common & valid
            fields[scenario, model] = (t, r)
            audit.append(dict(scenario=scenario, model=model, filename=filename,
                              valid_cells=int(valid.sum()), time_metadata=str(attrs)))
    if args.mask_file:
        with xr.open_dataset(args.mask_file, decode_times=False) as ds:
            explicit = ds[args.mask_variable].load()
        if set(explicit.dims) != set(SPATIAL):
            raise ValueError('Explicit mask must have latitude/longitude dimensions only')
        common, explicit = xr.align(common, explicit, join='exact')
        common = common & (explicit > 0) & np.isfinite(explicit)
    mask = common.transpose(*SPATIAL).values
    count = int(mask.sum())
    if count == 0:
        raise ValueError('Common mask is empty: check grids, missing data and NPP domain')
    print('Fixed common climate domain:', count, 'cells. Check against study mask.', flush=True)
    out.mkdir(parents=True, exist_ok=True)
    common.astype('int8').rename('common_climate_mask').to_netcdf(out/'common_climate_mask.nc')
    for record in audit:
        record['common_cells'] = count
    write_csv(out/'input_audit.csv', audit)
    plt.rcParams.update({'font.size': 9, 'axes.titlesize': 10})
    fig, axes = plt.subplots(3, 2, figsize=(11, 9), sharex=True, sharey='row')
    rows, summary = [], []
    for j, scenario in enumerate(FILES):
        values = np.array([window_metrics(*fields[scenario, m], mask) for m in MODELS])
        for i, label in enumerate(CLIMATE_LABELS):
            ensemble(axes[i, j], WINDOW_YEARS, values[:, i, :])
            if j == 0:
                axes[i, j].set_ylabel(label)
            for mi, model in enumerate(MODELS):
                for k, year in enumerate(WINDOW_YEARS):
                    rows.append(dict(scenario=scenario, model=model, metric=label,
                                     window_start=int(year-29), window_end=int(year),
                                     value=values[mi, i, k], n_cells=count))
                first, last = values[mi, i, 0], values[mi, i, -1]
                summary.append(dict(scenario=scenario, model=model, metric=label,
                                    value_2010_2039=first, value_2070_2099=last,
                                    difference=last-first))
        axes[0, j].set_title(scenario)
        axes[2, j].set_xlabel('End year of 30-year rolling window')
    finish(fig, axes, out/'Supplement_climate_chains')
    write_csv(out/'climate_rolling_values.csv', rows)
    write_csv(out/'climate_early_late_summary.csv', summary)
    csv_path = args.figure4_values
    if not csv_path.is_absolute():
        csv_path = args.data_dir/csv_path
    if csv_path.is_file():
        figure4(csv_path, out)
    else:
        print('Figure 4 NOT generated: original values CSV missing:', csv_path)
        print('Run your original figure script first, or supply --figure4-values PATH')
    print('Outputs:', out.resolve())
    print('Climate units: tair in K; confirmed rain in mm/hour converted to mm/year; '
          'interannual CV in percent.')
    print('No snow inclusion is inferred.')
    print('Figure 4 values remain unchanged; climate uses a separate fixed common mask.')


if __name__ == '__main__':
    main()
