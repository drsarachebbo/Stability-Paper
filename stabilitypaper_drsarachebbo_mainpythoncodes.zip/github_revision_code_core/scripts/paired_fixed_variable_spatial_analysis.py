#!/usr/bin/env python3
"""Paired spatial comparison of Fixed- and Variable-trait ORCHIDEE runs.

Purpose
-------
This analysis replaces an unpaired comparison of marginal distributions with
the comparison that matches the experimental design: the Fixed- and
Variable-trait values are paired within the same 8-km grid cell.

For each metric, the script calculates

    delta = Variable traits - Fixed traits

and reports raw paired effect sizes, the proportion of cells with positive or
negative changes, and percentile 95% confidence intervals obtained by
resampling non-overlapping spatial blocks.  The primary block side is 15 grid
cells (approximately 120 km); 20- and 25-cell blocks (approximately 160 and
200 km) are included as sensitivity analyses.

The supplied NetCDF files are opened read-only.  Outputs are written to a new
directory and do not replace the existing Figure 1.

Run on Irene
------------
    python3 paired_fixed_variable_spatial_analysis.py \
        --confirm-resistance-period

Use ``--confirm-resistance-period`` only after confirming that
``logresistance_all.nc`` was calculated over 1960-2019.

Numerical self-test (does not require xarray or NetCDF files)
-------------------------------------------------------------
    python3 paired_fixed_variable_spatial_analysis.py --self-test
"""

from __future__ import annotations

import argparse
import math
import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


SCRIPT_VERSION = "2026-09-15-paired-spatial-v1"

DEFAULT_DATA_DIR = Path("/ccc/work/cont003/gen6328/chebbosa")
DEFAULT_OUTPUT_SUBDIR = "paired_fixed_variable_analysis"

NPP_FILES = {
    "Fixed": "fixrecalcllvarnol_2D.nc",
    "Variable": "varllvarnol_2D.nc",
}
RESIDUAL_FILES = {
    "Fixed": "residuals_fixrecalcllvarnol60.nc",
    "Variable": "residuals_varllvarnol60.nc",
}
RESISTANCE_FILE = "logresistance_all.nc"
RESISTANCE_VARIABLES = {
    "Fixed": "RESISTANCE_FIXRECALCLLVAR",
    "Variable": "RESISTANCE_VARLLVAR",
}

NPP_VARIABLE = "NPP"
RESIDUAL_VARIABLE = "residuals"
TIME_DIMENSION = "time_counter"
LATITUDE_DIMENSION = "latitude"
LONGITUDE_DIMENSION = "longitude"

# Indices 0:60 are the 60 ordered annual records from 1960 through 2019.
FULL_PERIOD = slice(0, 60)
NPP_ANNUAL_FACTOR = 365.0
RESIDUAL_STD_DDOF = 0
MISSING_ABS_THRESHOLD = 1.0e30

GRID_CELL_SIZE_KM = 8.0
PRIMARY_BLOCK_CELLS = 15
BLOCK_SENSITIVITY_CELLS = (15, 20, 25)
DEFAULT_N_BOOTSTRAP = 1000
DEFAULT_RANDOM_SEED = 20260915
PNG_DPI = 600

# The earlier raw-versus-legacy diagnostic established this fallback.  If
# readable coordinates are present, coordinate matching takes precedence.
CONFIRMED_LEGACY_LATITUDE_FLIP = True

METRICS = (
    (
        "NPP",
        r"$\Delta$ NPP (g C m$^{-2}$ yr$^{-1}$)",
        "g C m-2 yr-1",
        "#6B6B6B",
    ),
    ("Constancy", r"$\Delta$ constancy", "dimensionless", "#4C78A8"),
    (
        "Resistance",
        r"$\Delta$ resistance ($\log_{10}$ units)",
        "log10 units",
        "#59A14F",
    ),
)


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help=(
            "New output directory. Default: DATA_DIR/"
            f"{DEFAULT_OUTPUT_SUBDIR}"
        ),
    )
    parser.add_argument(
        "--bootstrap",
        type=int,
        default=DEFAULT_N_BOOTSTRAP,
        help="Number of spatial-block bootstrap replicates (default: 1000).",
    )
    parser.add_argument("--seed", type=int, default=DEFAULT_RANDOM_SEED)
    parser.add_argument(
        "--confirm-resistance-period",
        action="store_true",
        help=(
            "Record that logresistance_all.nc has independently been confirmed "
            "to represent 1960-2019."
        ),
    )
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="Run an in-memory numerical test and exit.",
    )
    return parser.parse_args()


def require_xarray():
    try:
        import xarray as xr
    except ModuleNotFoundError as error:
        raise ModuleNotFoundError(
            "xarray is required for the NetCDF analysis. Use the same Python "
            "environment as the original Figure 1 script."
        ) from error
    return xr


def require_file(path: Path) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"Input file not found: {path}")


def clean_values(values: np.ndarray) -> np.ndarray:
    output = np.asarray(values, dtype=np.float64).copy()
    output[~np.isfinite(output)] = np.nan
    output[np.abs(output) >= MISSING_ABS_THRESHOLD] = np.nan
    return output


def coordinate_values(data_array, coordinate_name: str) -> np.ndarray | None:
    if coordinate_name not in data_array.coords:
        return None
    values = np.asarray(data_array.coords[coordinate_name].values).squeeze()
    if values.ndim != 1:
        return None
    return values.astype(np.float64)


def reduce_time_map(
    path: Path,
    variable_name: str,
    operation: str,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None, dict[str, str]]:
    """Read one time-varying field and reduce it to latitude x longitude."""
    xr = require_xarray()
    require_file(path)
    with xr.open_dataset(path, decode_times=False) as dataset:
        if variable_name not in dataset:
            available = ", ".join(dataset.data_vars)
            raise KeyError(
                f"{path.name}: '{variable_name}' not found; available: {available}"
            )
        variable = dataset[variable_name]
        if TIME_DIMENSION not in variable.dims:
            raise ValueError(
                f"{path.name}/{variable_name}: missing '{TIME_DIMENSION}'; "
                f"dimensions are {variable.dims}"
            )
        if variable.sizes[TIME_DIMENSION] < 60:
            raise ValueError(
                f"{path.name}/{variable_name}: expected at least 60 annual "
                f"records, found {variable.sizes[TIME_DIMENSION]}"
            )

        selected = variable.isel({TIME_DIMENSION: FULL_PERIOD})
        selected = selected.where(
            np.isfinite(selected) & (np.abs(selected) < MISSING_ABS_THRESHOLD)
        )
        if operation == "mean":
            result = selected.mean(dim=TIME_DIMENSION, skipna=True)
        elif operation == "std":
            result = selected.std(
                dim=TIME_DIMENSION,
                skipna=True,
                ddof=RESIDUAL_STD_DDOF,
            )
        else:
            raise ValueError(f"Unsupported reduction: {operation}")

        result = result.squeeze(drop=True)
        if LATITUDE_DIMENSION in result.dims and LONGITUDE_DIMENSION in result.dims:
            result = result.transpose(LATITUDE_DIMENSION, LONGITUDE_DIMENSION)
        if result.ndim != 2:
            raise ValueError(
                f"{path.name}/{variable_name}: expected a 2-D reduced map, "
                f"found dimensions={result.dims}, shape={result.shape}"
            )

        latitude = coordinate_values(result, LATITUDE_DIMENSION)
        longitude = coordinate_values(result, LONGITUDE_DIMENSION)
        metadata = {
            "path": str(path),
            "variable": variable_name,
            "source_dimensions": str(tuple(variable.dims)),
            "source_shape": str(tuple(variable.shape)),
            "source_units": str(variable.attrs.get("units", "not specified")),
        }
        values = result.load().values

    return clean_values(values), latitude, longitude, metadata


def read_2d_map(
    path: Path,
    variable_name: str,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None, dict[str, str]]:
    xr = require_xarray()
    require_file(path)
    with xr.open_dataset(path, decode_times=False) as dataset:
        if variable_name not in dataset:
            available = ", ".join(dataset.data_vars)
            raise KeyError(
                f"{path.name}: '{variable_name}' not found; available: {available}"
            )
        variable = dataset[variable_name]
        result = variable.squeeze(drop=True)
        if LATITUDE_DIMENSION in result.dims and LONGITUDE_DIMENSION in result.dims:
            result = result.transpose(LATITUDE_DIMENSION, LONGITUDE_DIMENSION)
        if result.ndim != 2:
            raise ValueError(
                f"{path.name}/{variable_name}: expected a 2-D map, "
                f"found dimensions={result.dims}, shape={result.shape}"
            )
        latitude = coordinate_values(result, LATITUDE_DIMENSION)
        longitude = coordinate_values(result, LONGITUDE_DIMENSION)
        metadata = {
            "path": str(path),
            "variable": variable_name,
            "source_dimensions": str(tuple(variable.dims)),
            "source_shape": str(tuple(variable.shape)),
            "source_units": str(variable.attrs.get("units", "not specified")),
            "global_attributes": str(dict(dataset.attrs)),
            "variable_attributes": str(dict(variable.attrs)),
        }
        values = result.load().values
    return clean_values(values), latitude, longitude, metadata


def align_to_reference(
    values: np.ndarray,
    source_latitude: np.ndarray | None,
    source_longitude: np.ndarray | None,
    target_shape: tuple[int, int],
    target_latitude: np.ndarray | None,
    target_longitude: np.ndarray | None,
    source_name: str,
    allow_confirmed_latitude_fallback: bool,
) -> np.ndarray:
    output = clean_values(values)
    if output.shape == target_shape[::-1] and output.shape != target_shape:
        output = output.T
        source_latitude, source_longitude = source_longitude, source_latitude
        warnings.warn(f"{source_name}: transposed reversed spatial dimensions")
    if output.shape != target_shape:
        raise ValueError(
            f"{source_name}: expected grid {target_shape}, found {output.shape}"
        )

    if target_latitude is not None and source_latitude is not None:
        if source_latitude.shape != target_latitude.shape:
            raise ValueError(f"{source_name}: latitude size does not match reference")
        if np.allclose(source_latitude, target_latitude, equal_nan=False):
            pass
        elif np.allclose(source_latitude[::-1], target_latitude, equal_nan=False):
            output = output[::-1, :]
            source_latitude = source_latitude[::-1]
            warnings.warn(f"{source_name}: reversed latitude to match reference")
        else:
            raise ValueError(f"{source_name}: latitude coordinates do not align")
    elif allow_confirmed_latitude_fallback and CONFIRMED_LEGACY_LATITUDE_FLIP:
        output = output[::-1, :]
        warnings.warn(
            f"{source_name}: latitude coordinate unavailable; applied the "
            "previously diagnosed latitude flip"
        )

    if target_longitude is not None and source_longitude is not None:
        if source_longitude.shape != target_longitude.shape:
            raise ValueError(f"{source_name}: longitude size does not match reference")
        if np.allclose(source_longitude, target_longitude, equal_nan=False):
            pass
        elif np.allclose(source_longitude[::-1], target_longitude, equal_nan=False):
            output = output[:, ::-1]
            warnings.warn(f"{source_name}: reversed longitude to match reference")
        else:
            raise ValueError(f"{source_name}: longitude coordinates do not align")
    return output


def calculate_metric_maps(
    data_dir: Path,
) -> tuple[
    dict[str, dict[str, np.ndarray]],
    np.ndarray | None,
    np.ndarray | None,
    list[dict[str, str]],
]:
    """Reproduce the 1960-2019 maps used in the original Figure 1."""
    maps: dict[str, dict[str, np.ndarray]] = {
        "NPP": {},
        "Constancy": {},
        "Resistance": {},
    }
    metadata: list[dict[str, str]] = []

    fixed_npp, latitude, longitude, info = reduce_time_map(
        data_dir / NPP_FILES["Fixed"], NPP_VARIABLE, "mean"
    )
    fixed_npp *= NPP_ANNUAL_FACTOR
    maps["NPP"]["Fixed"] = fixed_npp
    metadata.append({"role": "Fixed NPP", **info})

    target_shape = fixed_npp.shape
    for configuration in ("Variable",):
        values, source_lat, source_lon, info = reduce_time_map(
            data_dir / NPP_FILES[configuration], NPP_VARIABLE, "mean"
        )
        values = align_to_reference(
            values,
            source_lat,
            source_lon,
            target_shape,
            latitude,
            longitude,
            f"{configuration} NPP",
            allow_confirmed_latitude_fallback=False,
        )
        maps["NPP"][configuration] = values * NPP_ANNUAL_FACTOR
        metadata.append({"role": f"{configuration} NPP", **info})

    residual_sd: dict[str, np.ndarray] = {}
    for configuration in ("Fixed", "Variable"):
        values, source_lat, source_lon, info = reduce_time_map(
            data_dir / RESIDUAL_FILES[configuration],
            RESIDUAL_VARIABLE,
            "std",
        )
        values = align_to_reference(
            values,
            source_lat,
            source_lon,
            target_shape,
            latitude,
            longitude,
            f"{configuration} residual SD",
            allow_confirmed_latitude_fallback=False,
        )
        residual_sd[configuration] = values
        metadata.append({"role": f"{configuration} residual SD", **info})

    for configuration in ("Fixed", "Variable"):
        with np.errstate(divide="ignore", invalid="ignore"):
            constancy = maps["NPP"][configuration] / residual_sd[configuration]
        constancy[~np.isfinite(constancy)] = np.nan
        maps["Constancy"][configuration] = constancy

    resistance_path = data_dir / RESISTANCE_FILE
    for configuration in ("Fixed", "Variable"):
        values, source_lat, source_lon, info = read_2d_map(
            resistance_path,
            RESISTANCE_VARIABLES[configuration],
        )
        values = align_to_reference(
            values,
            source_lat,
            source_lon,
            target_shape,
            latitude,
            longitude,
            f"{configuration} resistance",
            allow_confirmed_latitude_fallback=True,
        )
        maps["Resistance"][configuration] = values
        metadata.append({"role": f"{configuration} resistance", **info})

    return maps, latitude, longitude, metadata


def master_gateway_mask(maps: dict[str, dict[str, np.ndarray]]) -> np.ndarray:
    """Apply the user's Ferret-style Fixed-constancy > 0 gateway."""
    fixed_constancy = maps["Constancy"]["Fixed"]
    return np.isfinite(fixed_constancy) & (fixed_constancy > 0)


def metric_valid_mask(
    metric: str,
    maps: dict[str, dict[str, np.ndarray]],
    gateway: np.ndarray,
) -> np.ndarray:
    fixed = maps[metric]["Fixed"]
    variable = maps[metric]["Variable"]
    valid = gateway & np.isfinite(fixed) & np.isfinite(variable)
    if metric in {"NPP", "Constancy"}:
        # These quantities must be positive. A zero in the log10 resistance
        # map, however, is a valid value and must not be discarded.
        valid &= (fixed > 0) & (variable > 0)
    return valid


def spatial_block_ids(
    rows: np.ndarray,
    columns: np.ndarray,
    n_columns: int,
    block_cells: int,
) -> np.ndarray:
    block_columns = math.ceil(n_columns / block_cells)
    return (
        (rows // block_cells) * block_columns + (columns // block_cells)
    ).astype(np.int64)


def percentile_interval(values: list[float]) -> tuple[float, float]:
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        return np.nan, np.nan
    low, high = np.percentile(finite, [2.5, 97.5])
    return float(low), float(high)


def paired_spatial_block_bootstrap(
    differences: np.ndarray,
    block_ids: np.ndarray,
    n_bootstrap: int,
    seed: int,
) -> dict[str, float]:
    """Resample spatial blocks while preserving within-cell pairing."""
    unique_blocks = np.unique(block_ids)
    indices_by_block = [
        np.flatnonzero(block_ids == block_id) for block_id in unique_blocks
    ]
    if unique_blocks.size < 5:
        return {
            "n_spatial_blocks": int(unique_blocks.size),
            "mean_delta_ci_low": np.nan,
            "mean_delta_ci_high": np.nan,
            "median_delta_ci_low": np.nan,
            "median_delta_ci_high": np.nan,
            "fraction_positive_ci_low": np.nan,
            "fraction_positive_ci_high": np.nan,
            "successful_bootstraps": 0,
        }

    rng = np.random.default_rng(seed)
    mean_values: list[float] = []
    median_values: list[float] = []
    positive_values: list[float] = []

    for _ in range(n_bootstrap):
        selected_blocks = rng.integers(
            0,
            len(indices_by_block),
            size=len(indices_by_block),
        )
        sample_indices = np.concatenate(
            [indices_by_block[index] for index in selected_blocks]
        )
        sample = differences[sample_indices]
        if sample.size == 0:
            continue
        mean_values.append(float(np.mean(sample)))
        median_values.append(float(np.median(sample)))
        positive_values.append(float(np.mean(sample > 0)))

    mean_ci = percentile_interval(mean_values)
    median_ci = percentile_interval(median_values)
    positive_ci = percentile_interval(positive_values)
    return {
        "n_spatial_blocks": int(unique_blocks.size),
        "mean_delta_ci_low": mean_ci[0],
        "mean_delta_ci_high": mean_ci[1],
        "median_delta_ci_low": median_ci[0],
        "median_delta_ci_high": median_ci[1],
        "fraction_positive_ci_low": positive_ci[0],
        "fraction_positive_ci_high": positive_ci[1],
        "successful_bootstraps": len(mean_values),
    }


def shifted_views(
    array: np.ndarray,
    row_shift: int,
    column_shift: int,
) -> tuple[np.ndarray, np.ndarray]:
    n_rows, n_columns = array.shape
    if row_shift >= n_rows or abs(column_shift) >= n_columns:
        return np.empty(0), np.empty(0)
    row_first = slice(0, n_rows - row_shift)
    row_second = slice(row_shift, n_rows)
    if column_shift >= 0:
        column_first = slice(0, n_columns - column_shift)
        column_second = slice(column_shift, n_columns)
    else:
        column_first = slice(-column_shift, n_columns)
        column_second = slice(0, n_columns + column_shift)
    return (
        array[row_first, column_first],
        array[row_second, column_second],
    )


def queen_morans_i(values_map: np.ndarray) -> tuple[float, float, int]:
    finite_values = values_map[np.isfinite(values_map)]
    n = finite_values.size
    if n < 3:
        return np.nan, np.nan, 0
    centered = values_map - np.mean(finite_values)
    denominator = float(np.nansum(centered**2))
    if denominator <= 0:
        return np.nan, float(-1.0 / (n - 1)), 0

    product_sum = 0.0
    n_pairs = 0
    for row_shift, column_shift in ((0, 1), (1, -1), (1, 0), (1, 1)):
        first, second = shifted_views(centered, row_shift, column_shift)
        valid = np.isfinite(first) & np.isfinite(second)
        product_sum += float(np.sum(first[valid] * second[valid]))
        n_pairs += int(np.count_nonzero(valid))
    if n_pairs == 0:
        return np.nan, float(-1.0 / (n - 1)), 0
    moran_i = (n / n_pairs) * product_sum / denominator
    return float(moran_i), float(-1.0 / (n - 1)), n_pairs


def effect_summary(
    metric: str,
    fixed: np.ndarray,
    variable: np.ndarray,
    differences: np.ndarray,
    rows: np.ndarray,
    columns: np.ndarray,
    grid_shape: tuple[int, int],
    block_cells: int,
    n_bootstrap: int,
    seed: int,
) -> dict[str, float | int | str]:
    block_ids = spatial_block_ids(
        rows,
        columns,
        grid_shape[1],
        block_cells,
    )
    uncertainty = paired_spatial_block_bootstrap(
        differences,
        block_ids,
        n_bootstrap,
        seed,
    )

    difference_map = np.full(grid_shape, np.nan, dtype=np.float64)
    difference_map[rows, columns] = differences
    moran_i, moran_expected, moran_pairs = queen_morans_i(difference_map)

    difference_sd = float(np.std(differences, ddof=1))
    standardized_mean_difference = (
        float(np.mean(differences) / difference_sd)
        if difference_sd > 0
        else np.nan
    )
    relative = np.full(differences.shape, np.nan, dtype=np.float64)
    nonzero_fixed = fixed != 0
    relative[nonzero_fixed] = (
        100.0 * differences[nonzero_fixed] / np.abs(fixed[nonzero_fixed])
    )

    return {
        "metric": metric,
        "block_cells": int(block_cells),
        "block_side_km": float(block_cells * GRID_CELL_SIZE_KM),
        "n_paired_cells": int(differences.size),
        "fixed_mean": float(np.mean(fixed)),
        "variable_mean": float(np.mean(variable)),
        "fixed_median": float(np.median(fixed)),
        "variable_median": float(np.median(variable)),
        "mean_delta_variable_minus_fixed": float(np.mean(differences)),
        "median_delta_variable_minus_fixed": float(np.median(differences)),
        "delta_standard_deviation": difference_sd,
        "paired_standardized_mean_difference": standardized_mean_difference,
        "delta_q25": float(np.quantile(differences, 0.25)),
        "delta_q75": float(np.quantile(differences, 0.75)),
        "fraction_positive": float(np.mean(differences > 0)),
        "fraction_negative": float(np.mean(differences < 0)),
        "fraction_exactly_zero": float(np.mean(differences == 0)),
        "median_relative_change_percent": (
            float(np.nanmedian(relative)) if metric != "Resistance" else np.nan
        ),
        "delta_morans_I_queen": moran_i,
        "moran_expected_under_randomness": moran_expected,
        "n_queen_neighbor_pairs": int(moran_pairs),
        **uncertainty,
    }


def compact_number(value: float, metric: str) -> str:
    if metric == "NPP":
        return f"{value:.1f}"
    return f"{value:.3f}"


def create_paired_difference_figure(
    differences_by_metric: dict[str, np.ndarray],
    primary_rows: list[dict[str, float | int | str]],
    output_png: Path,
    output_pdf: Path,
) -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 12,
            "axes.labelsize": 15,
            "ytick.labelsize": 11.5,
            "axes.linewidth": 1.0,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    figure, axes = plt.subplots(1, 3, figsize=(14.6, 5.1))
    figure.subplots_adjust(
        left=0.075,
        right=0.985,
        top=0.92,
        bottom=0.16,
        wspace=0.34,
    )
    primary_by_metric = {str(row["metric"]): row for row in primary_rows}

    for panel, (metric, ylabel, _, color) in enumerate(METRICS):
        axis = axes[panel]
        differences = differences_by_metric[metric]
        row = primary_by_metric[metric]

        parts = axis.violinplot(
            [differences],
            positions=[0],
            widths=0.72,
            showmeans=False,
            showmedians=False,
            showextrema=False,
            points=250,
            bw_method="scott",
        )
        for body in parts["bodies"]:
            body.set_facecolor(color)
            body.set_edgecolor("#4A4A4A")
            body.set_alpha(0.65)
            body.set_linewidth(1.0)

        mean_delta = float(row["mean_delta_variable_minus_fixed"])
        ci_low = float(row["mean_delta_ci_low"])
        ci_high = float(row["mean_delta_ci_high"])
        # Draw the interval directly so the plot also remains valid in the
        # unusual case where a cluster-bootstrap percentile interval is not
        # centred on the raw cell-weighted mean.
        axis.vlines(0, ci_low, ci_high, color="#1F1F1F", linewidth=1.5, zorder=5)
        axis.hlines(
            [ci_low, ci_high],
            -0.035,
            0.035,
            color="#1F1F1F",
            linewidth=1.5,
            zorder=5,
        )
        axis.scatter(
            [0],
            [mean_delta],
            s=38,
            color="#1F1F1F",
            zorder=6,
        )
        axis.axhline(0, color="#8A8A8A", linewidth=1.0, zorder=0)
        axis.set_xlim(-0.7, 0.7)
        axis.set_xticks([0])
        axis.set_xticklabels(["Variable − Fixed"])
        axis.set_ylabel(ylabel)
        axis.grid(False)

        annotation = (
            "Mean Δ = "
            f"{compact_number(mean_delta, metric)}\n"
            "95% block CI ["
            f"{compact_number(ci_low, metric)}, "
            f"{compact_number(ci_high, metric)}]\n"
            f"n = {int(row['n_paired_cells']):,} cells"
        )
        axis.text(
            0.04,
            0.97,
            annotation,
            transform=axis.transAxes,
            ha="left",
            va="top",
            fontsize=10.5,
        )
        axis.text(
            -0.10,
            1.03,
            chr(ord("a") + panel),
            transform=axis.transAxes,
            fontsize=17,
            fontweight="bold",
            ha="left",
            va="bottom",
            clip_on=False,
        )

    figure.savefig(output_pdf, bbox_inches="tight", facecolor="white")
    figure.savefig(output_png, dpi=PNG_DPI, bbox_inches="tight", facecolor="white")
    plt.close(figure)


def write_cell_differences(
    path: Path,
    maps: dict[str, dict[str, np.ndarray]],
    gateway: np.ndarray,
    latitude: np.ndarray | None,
    longitude: np.ndarray | None,
) -> None:
    rows, columns = np.nonzero(gateway)
    frame: dict[str, np.ndarray] = {
        "row": rows,
        "column": columns,
    }
    if latitude is not None:
        frame["latitude"] = latitude[rows]
    if longitude is not None:
        frame["longitude"] = longitude[columns]
    for metric, _, _, _ in METRICS:
        fixed = maps[metric]["Fixed"][gateway]
        variable = maps[metric]["Variable"][gateway]
        frame[f"fixed_{metric.lower()}"] = fixed
        frame[f"variable_{metric.lower()}"] = variable
        frame[f"delta_{metric.lower()}_variable_minus_fixed"] = variable - fixed
    pd.DataFrame(frame).to_csv(path, index=False)


def write_methods_file(
    path: Path,
    data_dir: Path,
    output_dir: Path,
    n_bootstrap: int,
    seed: int,
    gateway_count: int,
    resistance_period_confirmed: bool,
    metadata: list[dict[str, str]],
) -> None:
    resistance_status = (
        "confirmed by user flag as 1960-2019"
        if resistance_period_confirmed
        else "NOT CONFIRMED; verify its generation script before reporting"
    )
    lines = [
        "Paired Fixed-versus-Variable trait analysis",
        "",
        f"Script version: {SCRIPT_VERSION}",
        f"Data directory: {data_dir}",
        f"Output directory: {output_dir}",
        "NPP period: ordered annual indices 0:60 (1960-2019)",
        "Raw NPP conversion: multiplied once by 365",
        f"Residual standard deviation ddof: {RESIDUAL_STD_DDOF}",
        "Constancy: annual mean NPP / residual standard deviation",
        f"Resistance period status: {resistance_status}",
        "Pairing: same grid cell in Fixed and Variable configurations",
        "Gateway mask: recalculated Fixed constancy > 0",
        f"Cells in gateway before metric-specific finite filtering: {gateway_count}",
        "Delta definition: Variable - Fixed",
        (
            "Primary spatial uncertainty: non-overlapping 15 x 15-cell block "
            "bootstrap (approximately 120 km per side)"
        ),
        "Block-size sensitivity: 15, 20 and 25 cells (120, 160 and 200 km)",
        f"Bootstrap replicates: {n_bootstrap}",
        f"Random seed: {seed}",
        (
            "Inference: use paired raw effect sizes and spatial-block 95% "
            "intervals; no naive pixel-level p-values"
        ),
        (
            "Important: a resistance value of 0 on the log10 scale is valid "
            "and was retained"
        ),
        "",
        "Input metadata",
    ]
    for item in metadata:
        lines.append(str(item))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_self_test() -> None:
    rng = np.random.default_rng(101)
    grid_shape = (48, 53)
    fixed = rng.normal(100.0, 12.0, size=grid_shape)
    spatial_pattern = np.repeat(
        rng.normal(3.0, 1.0, size=(8, 9)),
        6,
        axis=0,
    )[: grid_shape[0], :]
    spatial_pattern = np.repeat(spatial_pattern, 6, axis=1)[:, : grid_shape[1]]
    variable = fixed + spatial_pattern + rng.normal(0, 0.5, size=grid_shape)
    gateway = np.ones(grid_shape, dtype=bool)
    rows, columns = np.nonzero(gateway)
    delta = (variable - fixed)[gateway]
    block_ids = spatial_block_ids(rows, columns, grid_shape[1], 6)
    result = paired_spatial_block_bootstrap(delta, block_ids, 200, 44)
    if not (2.0 < np.mean(delta) < 4.0):
        raise AssertionError("Synthetic paired mean was not recovered")
    if result["successful_bootstraps"] != 200:
        raise AssertionError("Spatial bootstrap did not complete")
    if not (
        result["mean_delta_ci_low"]
        <= np.mean(delta)
        <= result["mean_delta_ci_high"]
    ):
        raise AssertionError("Synthetic mean lies outside its bootstrap interval")
    print("Self-test passed")
    print(f"Synthetic observed mean delta: {np.mean(delta):.4f}")
    print(
        "Synthetic block-bootstrap 95% CI: "
        f"[{result['mean_delta_ci_low']:.4f}, "
        f"{result['mean_delta_ci_high']:.4f}]"
    )


def main() -> None:
    arguments = parse_arguments()
    if arguments.self_test:
        run_self_test()
        return
    if arguments.bootstrap < 100:
        raise ValueError("Use at least 100 bootstrap replicates")

    data_dir = arguments.data_dir.resolve()
    output_dir = (
        arguments.output_dir.resolve()
        if arguments.output_dir is not None
        else data_dir / DEFAULT_OUTPUT_SUBDIR
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    maps, latitude, longitude, metadata = calculate_metric_maps(data_dir)
    grid_shape = maps["NPP"]["Fixed"].shape
    gateway = master_gateway_mask(maps)
    gateway_count = int(np.count_nonzero(gateway))
    if gateway_count < 20:
        raise ValueError(f"Only {gateway_count} cells passed the gateway mask")
    if gateway_count != 4624:
        warnings.warn(
            f"Gateway contains {gateway_count} cells rather than the expected "
            "4,624. Inspect the mask and alignment before manuscript use."
        )

    summary_rows: list[dict[str, float | int | str]] = []
    primary_rows: list[dict[str, float | int | str]] = []
    differences_by_metric: dict[str, np.ndarray] = {}

    for metric_index, (metric, _, units, _) in enumerate(METRICS):
        valid = metric_valid_mask(metric, maps, gateway)
        rows, columns = np.nonzero(valid)
        fixed = maps[metric]["Fixed"][valid]
        variable = maps[metric]["Variable"][valid]
        differences = variable - fixed
        differences_by_metric[metric] = differences

        for block_index, block_cells in enumerate(BLOCK_SENSITIVITY_CELLS):
            row = effect_summary(
                metric,
                fixed,
                variable,
                differences,
                rows,
                columns,
                grid_shape,
                block_cells,
                arguments.bootstrap,
                arguments.seed + metric_index * 1000 + block_index,
            )
            row["units"] = units
            row["resistance_period_confirmed"] = bool(
                arguments.confirm_resistance_period
            )
            summary_rows.append(row)
            if block_cells == PRIMARY_BLOCK_CELLS:
                primary_rows.append(row)

    summary_path = output_dir / "paired_fixed_variable_summary.csv"
    sensitivity_path = output_dir / "paired_fixed_variable_block_sensitivity.csv"
    cells_path = output_dir / "paired_cell_differences.csv"
    figure_png = output_dir / "Figure1_paired_differences_1960_2019.png"
    figure_pdf = output_dir / "Figure1_paired_differences_1960_2019.pdf"
    methods_path = output_dir / "analysis_methods_and_settings.txt"

    summary_frame = pd.DataFrame(summary_rows)
    summary_frame[summary_frame["block_cells"] == PRIMARY_BLOCK_CELLS].to_csv(
        summary_path,
        index=False,
    )
    summary_frame.to_csv(sensitivity_path, index=False)
    write_cell_differences(
        cells_path,
        maps,
        gateway,
        latitude,
        longitude,
    )
    create_paired_difference_figure(
        differences_by_metric,
        primary_rows,
        figure_png,
        figure_pdf,
    )
    write_methods_file(
        methods_path,
        data_dir,
        output_dir,
        arguments.bootstrap,
        arguments.seed,
        gateway_count,
        arguments.confirm_resistance_period,
        metadata,
    )

    print("\nPaired Fixed-versus-Variable comparison")
    print("=" * 76)
    print(f"Gateway cells: {gateway_count}")
    for row in primary_rows:
        metric = str(row["metric"])
        print(f"\n{metric}: n={int(row['n_paired_cells'])}")
        print(
            "  Mean delta (Variable - Fixed): "
            f"{float(row['mean_delta_variable_minus_fixed']):.6g} "
            f"[{float(row['mean_delta_ci_low']):.6g}, "
            f"{float(row['mean_delta_ci_high']):.6g}]"
        )
        print(
            "  Median delta (Variable - Fixed): "
            f"{float(row['median_delta_variable_minus_fixed']):.6g} "
            f"[{float(row['median_delta_ci_low']):.6g}, "
            f"{float(row['median_delta_ci_high']):.6g}]"
        )
        print(
            "  Fraction positive: "
            f"{float(row['fraction_positive']):.3f} "
            f"[{float(row['fraction_positive_ci_low']):.3f}, "
            f"{float(row['fraction_positive_ci_high']):.3f}]"
        )
        print(f"  Moran's I of delta map: {float(row['delta_morans_I_queen']):.3f}")

    if not arguments.confirm_resistance_period:
        print(
            "\nWARNING: the resistance period has not been confirmed. Verify that "
            "logresistance_all.nc represents 1960-2019 before reporting that panel."
        )
    print("\nNew outputs (the old Figure 1 is untouched):")
    for path in (
        summary_path,
        sensitivity_path,
        cells_path,
        figure_png,
        figure_pdf,
        methods_path,
    ):
        print(f"  {path}")


if __name__ == "__main__":
    main()
